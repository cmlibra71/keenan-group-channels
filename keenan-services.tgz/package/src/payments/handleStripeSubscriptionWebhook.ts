import Stripe from "stripe";
import { subscriptionService } from "../services/subscriptions/SubscriptionService";
import { subscriptionEventService } from "../services/subscriptions/SubscriptionEventService";
import { drawEntryService } from "../services/draws/DrawEntryService";
import { customerService } from "../services/customers/CustomerService";
import { subscriptionPlanService } from "../services/subscriptions/SubscriptionPlanService";
import { eq, and, sql } from "drizzle-orm";
import { draws } from "../schema";
import { getCommerceDb } from "../db";
import {
  sendMembershipWelcomeEmail,
  sendPaymentReceiptEmail,
  sendPaymentFailedEmail,
  sendCancellationConfirmEmail,
} from "../utils/email";

/**
 * Extract subscription ID from a Stripe Invoice's parent field (Stripe v20+).
 */
function getSubscriptionIdFromInvoice(invoice: Stripe.Invoice): string | null {
  const subDetails = invoice.parent?.subscription_details;
  if (!subDetails) return null;
  const sub = subDetails.subscription;
  return typeof sub === "string" ? sub : sub?.id ?? null;
}

/**
 * Handle Stripe subscription webhook events.
 * Processes events idempotently using stripeEventId dedup.
 */
export async function handleStripeSubscriptionWebhook(event: Stripe.Event): Promise<void> {
  const stripeEventId = event.id;

  // Idempotency check
  const alreadyProcessed = await subscriptionEventService.existsByStripeEventId(stripeEventId);
  if (alreadyProcessed) {
    return;
  }

  switch (event.type) {
    case "customer.subscription.created":
    case "customer.subscription.updated": {
      const stripeSub = event.data.object as Stripe.Subscription;
      await handleSubscriptionUpdate(stripeSub, stripeEventId);
      break;
    }

    case "customer.subscription.deleted": {
      const stripeSub = event.data.object as Stripe.Subscription;
      await handleSubscriptionDeleted(stripeSub, stripeEventId);
      break;
    }

    case "invoice.payment_succeeded": {
      const invoice = event.data.object as Stripe.Invoice;
      const subId = getSubscriptionIdFromInvoice(invoice);
      if (subId) {
        await handlePaymentSucceeded(invoice, subId, stripeEventId);
      }
      break;
    }

    case "invoice.payment_failed": {
      const invoice = event.data.object as Stripe.Invoice;
      const subId = getSubscriptionIdFromInvoice(invoice);
      if (subId) {
        await handlePaymentFailed(invoice, subId, stripeEventId);
      }
      break;
    }
  }
}

async function handleSubscriptionUpdate(
  stripeSub: Stripe.Subscription,
  stripeEventId: string
) {
  const sub = await subscriptionService.getByStripeId(stripeSub.id);
  if (!sub) return;

  const statusMap: Record<string, string> = {
    active: "active",
    past_due: "past_due",
    canceled: "cancelled",
    unpaid: "past_due",
    incomplete: "pending",
    incomplete_expired: "ended",
    trialing: "active",
    paused: "cancelled",
  };

  const newStatus = statusMap[stripeSub.status] || sub.status;
  const previousStatus = sub.status;

  // Stripe v20: use start_date and billing_cycle_anchor for period tracking
  const updateData: Record<string, unknown> = {
    status: newStatus,
    cancelAtPeriodEnd: stripeSub.cancel_at_period_end,
    cancelledAt: stripeSub.canceled_at
      ? new Date(stripeSub.canceled_at * 1000)
      : null,
  };

  // Use start_date as period start reference
  if (stripeSub.start_date) {
    updateData.currentPeriodStart = new Date(stripeSub.start_date * 1000);
  }

  // Track current period end from Stripe (for billing date display & cancellation)
  if ((stripeSub as unknown as { current_period_end?: number }).current_period_end) {
    updateData.currentPeriodEnd = new Date(
      (stripeSub as unknown as { current_period_end: number }).current_period_end * 1000
    );
  }

  await subscriptionService.update(sub.id, updateData);

  // If becoming active, activate (assign to member group) + send welcome email
  if (newStatus === "active" && previousStatus !== "active") {
    await subscriptionService.activate(sub.id);

    // Send welcome email for new activations
    try {
      const customer = await customerService.getById(sub.customerId);
      const plan = await subscriptionPlanService.getById(sub.planId);
      if (customer && plan) {
        const email = (customer as { email: string }).email;
        const name = `${(customer as { first_name: string }).first_name || ""}`.trim() || "Member";
        // Use channel metadata or env for site URL
        const siteUrl = process.env.SITE_URL || "https://chefsdepot.com.au";
        await sendMembershipWelcomeEmail({
          to: email,
          memberName: name,
          planName: (plan as { name: string }).name,
          siteUrl,
        });
      }
    } catch (emailErr) {
      console.error("Failed to send welcome email:", emailErr);
    }
  }

  // If being cancelled (cancel_at_period_end), send cancellation email
  if (stripeSub.cancel_at_period_end && !sub.cancelAtPeriodEnd) {
    try {
      const customer = await customerService.getById(sub.customerId);
      const plan = await subscriptionPlanService.getById(sub.planId);
      if (customer && plan) {
        const email = (customer as { email: string }).email;
        const name = `${(customer as { first_name: string }).first_name || ""}`.trim() || "Member";
        const siteUrl = process.env.SITE_URL || "https://chefsdepot.com.au";
        const periodEnd = stripeSub.cancel_at
          ? new Date(stripeSub.cancel_at * 1000).toLocaleDateString()
          : "the end of your billing period";
        await sendCancellationConfirmEmail({
          to: email,
          memberName: name,
          planName: (plan as { name: string }).name,
          periodEnd,
          siteUrl,
        });
      }
    } catch (emailErr) {
      console.error("Failed to send cancellation email:", emailErr);
    }
  }

  // Log event
  await subscriptionEventService.createForParent(sub.id, {
    eventType: "subscription.updated",
    previousStatus,
    newStatus,
    stripeEventId,
    metadata: { stripeStatus: stripeSub.status },
  });
}

async function handleSubscriptionDeleted(
  stripeSub: Stripe.Subscription,
  stripeEventId: string
) {
  const sub = await subscriptionService.getByStripeId(stripeSub.id);
  if (!sub) return;

  const previousStatus = sub.status;
  await subscriptionService.handleEnded(sub.id);

  await subscriptionEventService.createForParent(sub.id, {
    eventType: "subscription.ended",
    previousStatus,
    newStatus: "ended",
    stripeEventId,
  });
}

async function handlePaymentSucceeded(
  invoice: Stripe.Invoice,
  stripeSubId: string,
  stripeEventId: string
) {
  const sub = await subscriptionService.getByStripeId(stripeSubId);
  if (!sub) return;

  const amount = invoice.amount_paid
    ? String(invoice.amount_paid / 100)
    : "0";

  // Increment consecutive months
  await subscriptionService.update(sub.id, {
    consecutiveMonths: (sub.consecutiveMonths ?? 0) + 1,
  });

  // Log payment event
  await subscriptionEventService.createForParent(sub.id, {
    eventType: "payment.succeeded",
    newStatus: "active",
    stripeEventId,
    amount,
    currencyCode: (invoice.currency || "aud").toUpperCase(),
    metadata: { invoiceId: invoice.id },
  });

  // Send payment receipt email
  try {
    const customer = await customerService.getById(sub.customerId);
    const plan = await subscriptionPlanService.getById(sub.planId);
    if (customer && plan) {
      const email = (customer as { email: string }).email;
      const name = `${(customer as { first_name: string }).first_name || ""}`.trim() || "Member";
      const siteUrl = process.env.SITE_URL || "https://chefsdepot.com.au";
      await sendPaymentReceiptEmail({
        to: email,
        memberName: name,
        planName: (plan as { name: string }).name,
        amount: `$${parseFloat(amount).toFixed(2)}`,
        currency: (invoice.currency || "aud").toUpperCase(),
        periodEnd: sub.currentPeriodEnd
          ? new Date(sub.currentPeriodEnd).toLocaleDateString()
          : "next month",
        siteUrl,
      });
    }
  } catch (emailErr) {
    console.error("Failed to send payment receipt email:", emailErr);
  }

  // Accumulate draw entries for open draws in this channel
  const db = getCommerceDb();
  const openDraws = await db
    .select()
    .from(draws)
    .where(
      and(
        eq(draws.channelId, sub.channelId),
        sql`${draws.status} IN ('scheduled', 'open')`
      )
    );

  for (const draw of openDraws) {
    await drawEntryService.accumulateEntries(
      draw.id,
      sub.id,
      sub.customerId,
      1
    );
  }
}

async function handlePaymentFailed(
  invoice: Stripe.Invoice,
  stripeSubId: string,
  stripeEventId: string
) {
  const sub = await subscriptionService.getByStripeId(stripeSubId);
  if (!sub) return;

  const previousStatus = sub.status;

  await subscriptionService.update(sub.id, {
    status: "past_due",
  });

  await subscriptionEventService.createForParent(sub.id, {
    eventType: "payment.failed",
    previousStatus,
    newStatus: "past_due",
    stripeEventId,
    amount: invoice.amount_due ? String(invoice.amount_due / 100) : "0",
    currencyCode: (invoice.currency || "aud").toUpperCase(),
    metadata: { invoiceId: invoice.id },
  });

  // Send payment failed email
  try {
    const customer = await customerService.getById(sub.customerId);
    const plan = await subscriptionPlanService.getById(sub.planId);
    if (customer && plan) {
      const email = (customer as { email: string }).email;
      const name = `${(customer as { first_name: string }).first_name || ""}`.trim() || "Member";
      const siteUrl = process.env.SITE_URL || "https://chefsdepot.com.au";
      await sendPaymentFailedEmail({
        to: email,
        memberName: name,
        planName: (plan as { name: string }).name,
        siteUrl,
      });
    }
  } catch (emailErr) {
    console.error("Failed to send payment failed email:", emailErr);
  }
}
