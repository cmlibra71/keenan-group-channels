-- Enable pgvector extension (requires pgvector-enabled PostgreSQL image)
CREATE EXTENSION IF NOT EXISTS vector;

-- HNSW index for fast approximate nearest-neighbor search on product embeddings
-- Cosine distance operator: vector_cosine_ops (<=>)
CREATE INDEX IF NOT EXISTS idx_products_embedding_hnsw
  ON products USING hnsw (embedding vector_cosine_ops)
  WITH (m = 16, ef_construction = 64);
