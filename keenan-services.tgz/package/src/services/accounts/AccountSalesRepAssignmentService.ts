import { eq, and, inArray } from "drizzle-orm";
import { getCommerceDb } from "../../db";
import {
  accountSalesRepAssignments,
  accounts,
  salesReps,
} from "../../schema";
import { NotFoundError, ConflictError } from "../../errors";
import { transformRow, transformRows } from "../../transforms";

interface AssignOptions {
  isPrimary?: boolean;
  commissionRateOverride?: string;
  notes?: string;
  assigned_at?: string;
}

/**
 * Service for managing account-sales rep assignments.
 */
class AccountSalesRepAssignmentServiceClass {
  private get db() {
    return getCommerceDb();
  }

  /**
   * Get all sales rep assignments for an account
   */
  async getSalesRepsForAccount(accountId: number): Promise<Record<string, unknown>[]> {
    await this.validateAccount(accountId);

    const results = await this.db
      .select({
        id: accountSalesRepAssignments.id,
        accountId: accountSalesRepAssignments.accountId,
        salesRepId: accountSalesRepAssignments.salesRepId,
        repEmail: salesReps.email,
        repFirstName: salesReps.firstName,
        repLastName: salesReps.lastName,
        isPrimary: accountSalesRepAssignments.isPrimary,
        commissionRateOverride: accountSalesRepAssignments.commissionRateOverride,
        notes: accountSalesRepAssignments.notes,
        assignedAt: accountSalesRepAssignments.assignedAt,
      })
      .from(accountSalesRepAssignments)
      .innerJoin(salesReps, eq(accountSalesRepAssignments.salesRepId, salesReps.id))
      .where(eq(accountSalesRepAssignments.accountId, accountId));

    return transformRows(results as unknown as Record<string, unknown>[]);
  }

  /**
   * Get all account assignments for a sales rep
   */
  async getAccountsForSalesRep(salesRepId: number): Promise<Record<string, unknown>[]> {
    await this.validateSalesRep(salesRepId);

    const results = await this.db
      .select({
        id: accountSalesRepAssignments.id,
        accountId: accountSalesRepAssignments.accountId,
        salesRepId: accountSalesRepAssignments.salesRepId,
        accountName: accounts.name,
        isPrimary: accountSalesRepAssignments.isPrimary,
        commissionRateOverride: accountSalesRepAssignments.commissionRateOverride,
        notes: accountSalesRepAssignments.notes,
        assignedAt: accountSalesRepAssignments.assignedAt,
      })
      .from(accountSalesRepAssignments)
      .innerJoin(accounts, eq(accountSalesRepAssignments.accountId, accounts.id))
      .where(eq(accountSalesRepAssignments.salesRepId, salesRepId));

    return transformRows(results as unknown as Record<string, unknown>[]);
  }

  /**
   * Get assignments for an account filtered by sales rep IDs
   */
  async getAssignmentsForAccount(
    accountId: number,
    salesRepIds: number[]
  ): Promise<Record<string, unknown>[]> {
    if (salesRepIds.length === 0) return [];

    const results = await this.db
      .select({ salesRepId: accountSalesRepAssignments.salesRepId })
      .from(accountSalesRepAssignments)
      .where(
        and(
          eq(accountSalesRepAssignments.accountId, accountId),
          inArray(accountSalesRepAssignments.salesRepId, salesRepIds)
        )
      );

    return results as unknown as Record<string, unknown>[];
  }

  /**
   * Assign a sales rep to an account
   */
  async assign(
    accountId: number,
    salesRepId: number,
    options: AssignOptions = {}
  ): Promise<Record<string, unknown>> {
    await this.validateAccount(accountId);
    await this.validateSalesRep(salesRepId);

    const existing = await this.getAssignment(accountId, salesRepId);
    if (existing) {
      throw new ConflictError(`Sales rep ${salesRepId} is already assigned to account ${accountId}.`);
    }

    const [result] = await this.db
      .insert(accountSalesRepAssignments)
      .values({
        accountId,
        salesRepId,
        isPrimary: options.isPrimary ?? false,
        commissionRateOverride: options.commissionRateOverride,
        notes: options.notes,
        assignedAt: options.assigned_at ? new Date(options.assigned_at) : undefined,
      })
      .returning();

    return transformRow(result as Record<string, unknown>);
  }

  /**
   * Update an assignment
   */
  async updateAssignment(
    accountId: number,
    salesRepId: number,
    data: AssignOptions
  ): Promise<Record<string, unknown>> {
    const existing = await this.getAssignment(accountId, salesRepId);
    if (!existing) {
      throw new NotFoundError("Assignment", `${accountId}-${salesRepId}`);
    }

    const updateData: Record<string, unknown> = {};
    if (data.isPrimary !== undefined) updateData.isPrimary = data.isPrimary;
    if (data.commissionRateOverride !== undefined)
      updateData.commissionRateOverride = data.commissionRateOverride;
    if (data.notes !== undefined) updateData.notes = data.notes;

    const [result] = await this.db
      .update(accountSalesRepAssignments)
      .set(updateData)
      .where(
        and(
          eq(accountSalesRepAssignments.accountId, accountId),
          eq(accountSalesRepAssignments.salesRepId, salesRepId)
        )
      )
      .returning();

    return transformRow(result as Record<string, unknown>);
  }

  /**
   * Remove a sales rep from an account
   */
  async remove(accountId: number, salesRepId: number): Promise<void> {
    const existing = await this.getAssignment(accountId, salesRepId);
    if (!existing) {
      throw new NotFoundError("Assignment", `${accountId}-${salesRepId}`);
    }

    await this.db
      .delete(accountSalesRepAssignments)
      .where(
        and(
          eq(accountSalesRepAssignments.accountId, accountId),
          eq(accountSalesRepAssignments.salesRepId, salesRepId)
        )
      );
  }

  private async getAssignment(accountId: number, salesRepId: number) {
    const [result] = await this.db
      .select()
      .from(accountSalesRepAssignments)
      .where(
        and(
          eq(accountSalesRepAssignments.accountId, accountId),
          eq(accountSalesRepAssignments.salesRepId, salesRepId)
        )
      )
      .limit(1);

    return result || null;
  }

  private async validateAccount(accountId: number): Promise<void> {
    const [account] = await this.db
      .select({ id: accounts.id })
      .from(accounts)
      .where(eq(accounts.id, accountId))
      .limit(1);

    if (!account) {
      throw new NotFoundError("Account", accountId);
    }
  }

  private async validateSalesRep(salesRepId: number): Promise<void> {
    const [rep] = await this.db
      .select({ id: salesReps.id })
      .from(salesReps)
      .where(eq(salesReps.id, salesRepId))
      .limit(1);

    if (!rep) {
      throw new NotFoundError("Sales Rep", salesRepId);
    }
  }
}

export const accountSalesRepAssignmentService = new AccountSalesRepAssignmentServiceClass();
