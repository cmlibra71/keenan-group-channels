const EMBEDDING_MODEL = "gemini-embedding-001";
const EMBEDDING_DIMS = 768;
const API_BASE = "https://generativelanguage.googleapis.com/v1beta";

/**
 * Compose the text used to generate an embedding for a product.
 * Combines name + brand + categories + SKU, deduplicating fields
 * that already appear in the product name to avoid wasting token budget.
 */
export function composeProductEmbeddingText(product: {
  name: string;
  sku?: string | null;
  brandName?: string | null;
  categoryNames?: string[] | null;
}): string {
  const nameLower = product.name.toLowerCase();
  const parts: string[] = [product.name];

  // Brand: skip if already in name (e.g. "Goldstein GPGDB48 800 Series Griddle Plate" already has "Goldstein")
  if (product.brandName && !nameLower.includes(product.brandName.toLowerCase())) {
    parts.push(product.brandName);
  }

  // Categories: include only those not already in the name
  if (product.categoryNames && product.categoryNames.length > 0) {
    const newCats = product.categoryNames.filter(
      (cat) => !nameLower.includes(cat.toLowerCase())
    );
    if (newCats.length > 0) {
      parts.push(`Categories: ${newCats.join(", ")}`);
    }
  }

  // SKU: skip if already in name
  if (product.sku && !nameLower.includes(product.sku.toLowerCase())) {
    parts.push(`SKU: ${product.sku}`);
  }

  return parts.join(". ").trim();
}

/**
 * Generate a single embedding vector using Gemini embedding API.
 * Returns null if API key isn't configured or the call fails.
 */
export async function generateEmbedding(text: string): Promise<number[] | null> {
  const apiKey = process.env.GOOGLE_API_KEY;
  if (!apiKey) return null;

  try {
    const res = await fetch(
      `${API_BASE}/models/${EMBEDDING_MODEL}:embedContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: `models/${EMBEDDING_MODEL}`,
          content: { parts: [{ text }] },
          outputDimensionality: EMBEDDING_DIMS,
        }),
      }
    );

    if (!res.ok) {
      console.error("[embeddings] API error:", res.status, await res.text());
      return null;
    }

    const data = (await res.json()) as { embedding?: { values?: number[] } };
    return data.embedding?.values ?? null;
  } catch (err) {
    console.error("[embeddings] Failed to generate embedding:", (err as Error).message);
    return null;
  }
}

/**
 * Generate embeddings for a batch of texts (up to 100 per call).
 * Returns an array of embeddings in the same order as the input texts.
 * Individual failures return null for that position.
 */
export async function generateEmbeddingsBatch(
  texts: string[]
): Promise<(number[] | null)[]> {
  const apiKey = process.env.GOOGLE_API_KEY;
  if (!apiKey) return texts.map(() => null);

  try {
    const res = await fetch(
      `${API_BASE}/models/${EMBEDDING_MODEL}:batchEmbedContents?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requests: texts.map((text) => ({
            model: `models/${EMBEDDING_MODEL}`,
            content: { parts: [{ text }] },
            outputDimensionality: EMBEDDING_DIMS,
          })),
        }),
      }
    );

    if (!res.ok) {
      console.error("[embeddings] Batch API error:", res.status, await res.text());
      return texts.map(() => null);
    }

    const data = (await res.json()) as { embeddings?: { values?: number[] }[] };
    if (!data.embeddings) return texts.map(() => null);

    return data.embeddings.map((emb) => emb.values ?? null);
  } catch (err) {
    console.error("[embeddings] Batch embedding failed:", (err as Error).message);
    return texts.map(() => null);
  }
}
