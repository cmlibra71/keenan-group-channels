import { PgColumn } from "drizzle-orm/pg-core";
import { accounts, approvalRules } from "../../schema";
import { NestedService } from "../../base/NestedService";

/**
 * Service for managing approval rules within accounts.
 */
class ApprovalRuleServiceClass extends NestedService<typeof accounts, typeof approvalRules> {
  constructor() {
    super(accounts, approvalRules, {
      resourceName: "Approval Rule",
      parentResourceName: "Account",
      defaultSort: "id",
      sortColumns: {
        id: approvalRules.id,
        name: approvalRules.name,
        priority: approvalRules.priority,
      },
      filterColumns: {
        rule_type: approvalRules.ruleType,
        is_active: approvalRules.isActive,
      },
      allowedFilters: ["rule_type", "is_active"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return accounts.id;
  }

  protected getParentForeignKey(): PgColumn {
    return approvalRules.accountId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "accountId";
  }
}

export const approvalRuleService = new ApprovalRuleServiceClass();
