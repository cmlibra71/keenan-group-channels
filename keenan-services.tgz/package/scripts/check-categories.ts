import "dotenv/config";
import postgres from "postgres";

const sql = postgres(process.env.COMMERCE_DATABASE_URL!);

async function main() {
  const rows = await sql`
    SELECT c.id, c.name, c.depth, c.is_active, c.include_in_menu,
           c.include_in_search, c.include_in_filters, c.parent_id
    FROM categories c
    JOIN category_trees t ON t.id = c.tree_id
    WHERE t.channel_id = 1
    ORDER BY c.sort_order, c.name
  `;

  console.log("Total categories:", rows.length);
  console.log("Active + InMenu:", rows.filter(r => r.is_active && r.include_in_menu).length);
  console.log("Active but NOT InMenu:", rows.filter(r => r.is_active && r.include_in_menu === false).length);
  console.log("Inactive:", rows.filter(r => r.is_active === false).length);
  console.log("");

  console.log("=== ALL categories with visibility flags ===");
  for (const r of rows) {
    const indent = "  ".repeat(r.depth || 0);
    const flags = [
      r.is_active ? "active" : "INACTIVE",
      r.include_in_menu ? "menu" : "NO-MENU",
      r.include_in_search ? "search" : "NO-SEARCH",
      r.include_in_filters ? "filters" : "NO-FILTERS",
    ].join(", ");
    console.log(`${indent}${r.name} (id:${r.id}, depth:${r.depth}, parent:${r.parent_id}) [${flags}]`);
  }

  await sql.end();
}

main();
