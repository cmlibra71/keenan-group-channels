import { PgColumn } from "drizzle-orm/pg-core";
import { customers, wishlists, wishlistItems } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { DependencyCheck, IncludeConfig } from "../../base/types";

/**
 * Service for managing customer wishlists.
 */
class WishlistServiceClass extends NestedService<typeof customers, typeof wishlists> {
  constructor() {
    super(customers, wishlists, {
      resourceName: "Wishlist",
      parentResourceName: "Customer",
      defaultSort: "id",
      sortColumns: {
        id: wishlists.id,
        name: wishlists.name,
        created_at: wishlists.createdAt,
      },
      filterColumns: {
        name: wishlists.name,
        is_public: wishlists.isPublic,
      },
      allowedFilters: ["name", "is_public"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return customers.id;
  }

  protected getParentForeignKey(): PgColumn {
    return wishlists.customerId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "customerId";
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "items",
        table: wishlistItems,
        foreignKey: wishlistItems.wishlistId,
      },
    ];
  }
}

export const wishlistService = new WishlistServiceClass();
