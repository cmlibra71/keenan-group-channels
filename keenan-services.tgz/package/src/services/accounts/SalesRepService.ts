import { salesReps, accountSalesRepAssignments } from "../../schema";
import { BaseService } from "../../base/BaseService";
import { UniqueConstraint, DependencyCheck } from "../../base/types";

/**
 * Service for managing sales representatives.
 */
class SalesRepServiceClass extends BaseService<typeof salesReps> {
  constructor() {
    super(salesReps, {
      resourceName: "Sales Rep",
      defaultSort: "id",
      sortColumns: {
        id: salesReps.id,
        email: salesReps.email,
        first_name: salesReps.firstName,
        last_name: salesReps.lastName,
      },
      filterColumns: {
        email: salesReps.email,
        first_name: salesReps.firstName,
        last_name: salesReps.lastName,
        is_active: salesReps.isActive,
      },
      allowedFilters: ["email", "first_name", "last_name", "is_active"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [{ column: salesReps.email, fieldName: "email" }],
        message: "A sales rep with this email already exists.",
      },
    ];
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: accountSalesRepAssignments,
        foreignKeyColumn: accountSalesRepAssignments.salesRepId,
        resourceName: "account assignment",
        message: "Cannot delete sales rep because they have {count} account assignment(s).",
      },
    ];
  }
}

export const salesRepService = new SalesRepServiceClass();
