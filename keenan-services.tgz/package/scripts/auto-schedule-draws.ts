/**
 * Auto-schedule monthly/quarterly draws based on draw types.
 * Run with: npx tsx scripts/auto-schedule-draws.ts
 *
 * For each active draw type with frequency "monthly" or "quarterly",
 * checks if a draw already exists for the current period and creates
 * one with status "scheduled" if not.
 *
 * Requires:
 *   COMMERCE_DATABASE_URL - PostgreSQL connection string
 */
import "dotenv/config";
import { initCommerceDb, closeCommerceDb } from "../src/db";
import { drawTypeService } from "../src/services/draws/DrawTypeService";
import { drawService } from "../src/services/draws/DrawService";

const DB_URL = process.env.COMMERCE_DATABASE_URL;
if (!DB_URL) {
  console.error("COMMERCE_DATABASE_URL is required");
  process.exit(1);
}

initCommerceDb(DB_URL, { max: 3 });

async function main() {
  console.log("Auto-scheduling draws...");

  // Get all active draw types
  const result = await drawTypeService.list({
    page: 1,
    limit: 100,
    sort: "id",
    direction: "asc",
    filters: {
      is_active: { type: "eq", value: true },
    },
  });

  const drawTypes = result.data;
  console.log(`Found ${drawTypes.length} active draw type(s)`);

  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();
  const currentQuarter = Math.floor(currentMonth / 3);

  let created = 0;
  let skipped = 0;

  for (const dt of drawTypes) {
    const frequency = dt.frequency as string;
    const channelId = dt.channel_id as number;
    const dtId = dt.id as number;
    const dtName = dt.name as string;

    if (frequency !== "monthly" && frequency !== "quarterly") {
      console.log(`  Skip: "${dtName}" has frequency "${frequency}" (not monthly/quarterly)`);
      skipped++;
      continue;
    }

    // Determine period name and dates
    let periodName: string;
    let scheduledAt: Date;
    let entryDeadline: Date;

    if (frequency === "monthly") {
      const monthNames = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December",
      ];
      periodName = `${monthNames[currentMonth]} ${currentYear}`;
      // Schedule for last day of current month at 5pm
      scheduledAt = new Date(currentYear, currentMonth + 1, 0, 17, 0, 0);
      // Entry deadline: last day of current month at noon
      entryDeadline = new Date(currentYear, currentMonth + 1, 0, 12, 0, 0);
    } else {
      // quarterly
      const quarterNames = ["Q1", "Q2", "Q3", "Q4"];
      periodName = `${quarterNames[currentQuarter]} ${currentYear}`;
      // Schedule for last day of quarter at 5pm
      const lastMonthOfQuarter = (currentQuarter + 1) * 3;
      scheduledAt = new Date(currentYear, lastMonthOfQuarter, 0, 17, 0, 0);
      // Entry deadline: last day of quarter at noon
      entryDeadline = new Date(currentYear, lastMonthOfQuarter, 0, 12, 0, 0);
    }

    const drawName = `${dtName} — ${periodName}`;

    // Check if a draw already exists for this draw type in the current period
    const existing = await drawService.list({
      page: 1,
      limit: 10,
      sort: "id",
      direction: "desc",
      filters: {
        draw_type_id: { type: "eq", value: dtId },
      },
    });

    const alreadyExists = existing.data.some(
      (d: Record<string, unknown>) => (d.name as string).includes(periodName)
    );

    if (alreadyExists) {
      console.log(`  Skip: "${drawName}" already exists`);
      skipped++;
      continue;
    }

    // Create the draw
    await drawService.create({
      channel_id: channelId,
      draw_type_id: dtId,
      name: drawName,
      description: `Auto-scheduled ${frequency} draw`,
      status: "scheduled",
      scheduled_at: scheduledAt.toISOString(),
      entry_deadline: entryDeadline.toISOString(),
    });

    console.log(`  Created: "${drawName}" (channel ${channelId})`);
    created++;
  }

  console.log(`\nDone. Created ${created} draw(s), skipped ${skipped}.`);
  await closeCommerceDb();
}

main().catch(async (err) => {
  console.error("Failed:", err);
  await closeCommerceDb();
  process.exit(1);
});
