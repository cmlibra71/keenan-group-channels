/**
 * Backfill embeddings for ALL products (re-generates with brand + category context).
 * Run with: npx tsx scripts/backfill-embeddings.ts
 */
import "dotenv/config";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { eq, sql } from "drizzle-orm";
import { products, brands, productCategories, categories } from "../src/schema";
import { generateEmbeddingsBatch, composeProductEmbeddingText } from "../src/utils/embeddings";

const BATCH_SIZE = 100;
const DELAY_BETWEEN_BATCHES_MS = 500;

async function main() {
  const connectionString = process.env.COMMERCE_DATABASE_URL;
  if (!connectionString) {
    console.error("COMMERCE_DATABASE_URL is not set");
    process.exit(1);
  }

  if (!process.env.GOOGLE_API_KEY) {
    console.error("GOOGLE_API_KEY must be set");
    process.exit(1);
  }

  const client = postgres(connectionString, { prepare: false, max: 2 });
  const db = drizzle(client);

  // Count ALL products (re-embedding everything)
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(products);

  console.log(`Re-embedding all ${count} products with brand + category context`);

  if (count === 0) {
    console.log("Nothing to do!");
    await client.end();
    return;
  }

  let processed = 0;
  let embedded = 0;
  let failed = 0;
  let lastId = 0;

  while (processed < count) {
    // Fetch next batch by ID cursor (avoids offset performance issues)
    const batch = await db
      .select({
        id: products.id,
        name: products.name,
        sku: products.sku,
        brandId: products.brandId,
      })
      .from(products)
      .where(sql`${products.id} > ${lastId}`)
      .orderBy(products.id)
      .limit(BATCH_SIZE);

    if (batch.length === 0) break;
    lastId = batch[batch.length - 1].id;

    // Fetch brand names for products that have a brandId
    const brandIds = [...new Set(batch.map((p) => p.brandId).filter(Boolean))] as number[];
    const brandMap = new Map<number, string>();
    if (brandIds.length > 0) {
      const brandRows = await db
        .select({ id: brands.id, name: brands.name })
        .from(brands)
        .where(sql`${brands.id} IN ${brandIds}`);
      for (const b of brandRows) brandMap.set(b.id, b.name);
    }

    // Fetch category names for all products in batch
    const batchIds = batch.map((p) => p.id);
    const catRows = await db
      .selectDistinct({
        productId: productCategories.productId,
        categoryName: categories.name,
      })
      .from(productCategories)
      .innerJoin(categories, eq(categories.id, productCategories.categoryId))
      .where(sql`${productCategories.productId} IN ${batchIds}`);

    const catMap = new Map<number, string[]>();
    for (const row of catRows) {
      const existing = catMap.get(row.productId) || [];
      existing.push(row.categoryName);
      catMap.set(row.productId, existing);
    }

    // Compose texts for batch
    const texts = batch.map((p) =>
      composeProductEmbeddingText({
        name: p.name,
        sku: p.sku,
        brandName: p.brandId ? brandMap.get(p.brandId) ?? null : null,
        categoryNames: catMap.get(p.id) ?? null,
      })
    );

    // Generate embeddings in batch
    const embeddings = await generateEmbeddingsBatch(texts);

    // Update each product with its embedding
    for (let i = 0; i < batch.length; i++) {
      const embedding = embeddings[i];
      if (embedding) {
        await db
          .update(products)
          .set({ embedding })
          .where(eq(products.id, batch[i].id));
        embedded++;
      } else {
        failed++;
      }
    }

    processed += batch.length;
    console.log(
      `Progress: ${processed}/${count} processed, ${embedded} embedded, ${failed} failed`
    );

    // Rate limit delay
    if (processed < count) {
      await new Promise((resolve) => setTimeout(resolve, DELAY_BETWEEN_BATCHES_MS));
    }
  }

  console.log(`\nDone! ${embedded} products embedded, ${failed} failed out of ${processed} total.`);
  await client.end();
}

main().catch((err) => {
  console.error("Backfill failed:", err);
  process.exit(1);
});
