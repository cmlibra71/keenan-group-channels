import { eq, sql, asc, desc } from "drizzle-orm";
import { getCommerceDb } from "../../db";
import { storeSettings } from "../../schema";
import { NotFoundError, BadRequestError } from "../../errors";
import { transformRow, transformRows } from "../../transforms";
import { ListOptions, PaginatedResult } from "../../base/types";

/**
 * Service for managing store settings (global key-value store).
 *
 * This is a specialized service that doesn't extend BaseService because
 * settings use a key-based lookup instead of numeric ID.
 */
class StoreSettingsServiceClass {
  protected get db() {
    return getCommerceDb();
  }

  /**
   * List all store settings
   */
  async list(options: ListOptions): Promise<PaginatedResult<Record<string, unknown>>> {
    const { page, limit, direction } = options;

    // Get total count
    const [countResult] = await this.db
      .select({ count: sql<number>`count(*)::int` })
      .from(storeSettings);

    const total = countResult?.count ?? 0;

    // Get paginated results (sorted by key)
    const results = await this.db
      .select()
      .from(storeSettings)
      .orderBy(direction === "desc" ? desc(storeSettings.settingKey) : asc(storeSettings.settingKey))
      .limit(limit)
      .offset((page - 1) * limit);

    const data = transformRows(results as Record<string, unknown>[]);

    return {
      data,
      pagination: { page, limit, total },
    };
  }

  /**
   * Get a single setting by key
   */
  async getByKey(key: string): Promise<Record<string, unknown>> {
    if (!key) {
      throw new BadRequestError("Setting key is required.");
    }

    const [result] = await this.db
      .select()
      .from(storeSettings)
      .where(eq(storeSettings.settingKey, key))
      .limit(1);

    if (!result) {
      throw new NotFoundError("Store Setting", key);
    }

    return transformRow(result as Record<string, unknown>);
  }

  /**
   * Create or update a setting (upsert)
   */
  async upsert(
    key: string,
    value: unknown,
    options?: { description?: string; isSensitive?: boolean }
  ): Promise<Record<string, unknown>> {
    if (!key) {
      throw new BadRequestError("Setting key is required.");
    }

    // Check if setting exists
    const [existing] = await this.db
      .select({ id: storeSettings.id })
      .from(storeSettings)
      .where(eq(storeSettings.settingKey, key))
      .limit(1);

    let result;

    if (existing) {
      // Update existing setting
      const updateData: Record<string, unknown> = {
        settingValue: value,
        updatedAt: new Date(),
      };
      if (options?.description !== undefined) {
        updateData.description = options.description;
      }
      if (options?.isSensitive !== undefined) {
        updateData.isSensitive = options.isSensitive;
      }

      [result] = await this.db
        .update(storeSettings)
        .set(updateData)
        .where(eq(storeSettings.id, existing.id))
        .returning();
    } else {
      // Insert new setting
      [result] = await this.db
        .insert(storeSettings)
        .values({
          settingKey: key,
          settingValue: value,
          description: options?.description,
          isSensitive: options?.isSensitive ?? false,
        })
        .returning();
    }

    return transformRow(result as Record<string, unknown>);
  }

  /**
   * Delete a setting by key
   */
  async deleteByKey(key: string): Promise<void> {
    if (!key) {
      throw new BadRequestError("Setting key is required.");
    }

    // Check setting exists
    const [setting] = await this.db
      .select({ id: storeSettings.id })
      .from(storeSettings)
      .where(eq(storeSettings.settingKey, key))
      .limit(1);

    if (!setting) {
      throw new NotFoundError("Store Setting", key);
    }

    await this.db.delete(storeSettings).where(eq(storeSettings.id, setting.id));
  }
}

export const storeSettingsService = new StoreSettingsServiceClass();
