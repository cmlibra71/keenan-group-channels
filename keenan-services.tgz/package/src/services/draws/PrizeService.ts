import { eq, and, sql } from "drizzle-orm";
import { prizes, channels, products, productImages } from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation } from "../../base/types";

/**
 * Service for managing prize catalog per channel.
 */
class PrizeServiceClass extends BaseService<typeof prizes> {
  constructor() {
    super(prizes, {
      resourceName: "Prize",
      defaultSort: "id",
      sortColumns: {
        id: prizes.id,
        name: prizes.name,
        value: prizes.value,
        created_at: prizes.createdAt,
      },
      filterColumns: {
        channel_id: prizes.channelId,
        is_active: prizes.isActive,
      },
      allowedFilters: ["channel_id", "is_active"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: channels,
        column: channels.id,
        resourceName: "Channel",
        fieldName: "channelId",
      },
      {
        table: products,
        column: products.id,
        resourceName: "Product",
        fieldName: "productId",
        optional: true,
      },
    ];
  }

  /**
   * Auto-fill name and imageUrl from linked product when not explicitly set.
   */
  private async autoFillFromProduct(data: Record<string, unknown>): Promise<Record<string, unknown>> {
    const productId = data.productId as number | null | undefined;
    if (!productId) return data;

    const [product] = await this.db
      .select({
        name: products.name,
        price: products.price,
        imageUrl: sql<string | null>`(
          SELECT ${productImages.urlStandard}
          FROM ${productImages}
          WHERE ${productImages.productId} = ${products.id}
          ORDER BY ${productImages.sortOrder} ASC
          LIMIT 1
        )`.as("image_url"),
      })
      .from(products)
      .where(eq(products.id, productId))
      .limit(1);

    if (!product) return data;

    if (!data.name) {
      data.name = product.name;
    }
    if (!data.imageUrl && product.imageUrl) {
      data.imageUrl = product.imageUrl;
    }
    if (!data.value && product.price) {
      data.value = product.price;
    }

    return data;
  }

  protected async beforeCreate(data: Record<string, unknown>): Promise<Record<string, unknown>> {
    return this.autoFillFromProduct(data);
  }

  protected async beforeUpdate(data: Record<string, unknown>, _existing: Record<string, unknown>): Promise<Record<string, unknown>> {
    return this.autoFillFromProduct(data);
  }

  /**
   * List active prizes for a channel, resolving product image/value as fallbacks.
   */
  async listActiveForChannel(channelId: number) {
    const rows = await this.db
      .select({
        id: prizes.id,
        uuid: prizes.uuid,
        channelId: prizes.channelId,
        productId: prizes.productId,
        name: prizes.name,
        description: prizes.description,
        imageUrl: prizes.imageUrl,
        value: prizes.value,
        currencyCode: prizes.currencyCode,
        isActive: prizes.isActive,
        metafields: prizes.metafields,
        createdAt: prizes.createdAt,
        updatedAt: prizes.updatedAt,
        productImageUrl: sql<string | null>`(
          SELECT ${productImages.urlStandard}
          FROM ${productImages}
          WHERE ${productImages.productId} = ${prizes.productId}
          ORDER BY ${productImages.sortOrder} ASC
          LIMIT 1
        )`.as("product_image_url"),
        productPrice: products.price,
      })
      .from(prizes)
      .leftJoin(products, eq(products.id, prizes.productId))
      .where(
        and(
          eq(prizes.channelId, channelId),
          eq(prizes.isActive, true)
        )
      )
      .orderBy(prizes.name);

    // Resolve fallbacks: prize fields take precedence, product fields are fallback
    return rows.map(({ productImageUrl, productPrice, ...prize }) => ({
      ...prize,
      imageUrl: prize.imageUrl ?? productImageUrl,
      value: prize.value ?? productPrice,
    }));
  }
}

export const prizeService = new PrizeServiceClass();
