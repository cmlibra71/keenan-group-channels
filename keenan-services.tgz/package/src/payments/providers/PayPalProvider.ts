import type {
  PaymentProvider,
  PaymentResult,
  PaymentDetails,
  CredentialValidationResult,
} from "../types";

/**
 * PayPal payment provider using REST API v2.
 *
 * Flow: client creates PayPal order -> user approves -> server captures via paypal_order_id.
 * Credentials: { client_id, client_secret }
 */
export class PayPalProvider implements PaymentProvider {
  readonly providerName = "paypal";
  private clientId: string;
  private clientSecret: string;
  private baseUrl: string;

  constructor(clientId: string, clientSecret: string, testMode: boolean) {
    this.clientId = clientId;
    this.clientSecret = clientSecret;
    this.baseUrl = testMode
      ? "https://api-m.sandbox.paypal.com"
      : "https://api-m.paypal.com";
  }

  private async getAccessToken(): Promise<string> {
    const auth = Buffer.from(`${this.clientId}:${this.clientSecret}`).toString("base64");
    const response = await fetch(`${this.baseUrl}/v1/oauth2/token`, {
      method: "POST",
      headers: {
        Authorization: `Basic ${auth}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: "grant_type=client_credentials",
    });

    if (!response.ok) {
      throw new Error(`PayPal auth failed: ${response.status}`);
    }

    const data = await response.json() as { access_token: string };
    return data.access_token;
  }

  private async apiRequest(
    method: string,
    path: string,
    body?: Record<string, unknown>
  ): Promise<Record<string, unknown>> {
    const token = await this.getAccessToken();
    const response = await fetch(`${this.baseUrl}${path}`, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(
        (error as Record<string, unknown>).message as string ||
          `PayPal API error: ${response.status}`
      );
    }

    return response.json() as Promise<Record<string, unknown>>;
  }

  async validateCredentials(
    credentials: Record<string, string>,
    testMode: boolean
  ): Promise<CredentialValidationResult> {
    try {
      const baseUrl = testMode
        ? "https://api-m.sandbox.paypal.com"
        : "https://api-m.paypal.com";
      const auth = Buffer.from(
        `${credentials.client_id}:${credentials.client_secret}`
      ).toString("base64");

      const response = await fetch(`${baseUrl}/v1/oauth2/token`, {
        method: "POST",
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: "grant_type=client_credentials",
      });

      if (!response.ok) {
        return { valid: false, message: "Invalid PayPal credentials" };
      }

      const data = await response.json() as { app_id?: string; scope?: string };
      return {
        valid: true,
        message: testMode
          ? "Connected to PayPal (sandbox)"
          : "Connected to PayPal (live)",
        details: { app_id: data.app_id, scope: data.scope },
      };
    } catch (err) {
      return {
        valid: false,
        message: err instanceof Error ? err.message : "Failed to connect to PayPal",
      };
    }
  }

  async authorize(
    amount: string,
    currencyCode: string,
    details: PaymentDetails
  ): Promise<PaymentResult> {
    try {
      const order = (await this.apiRequest("POST", "/v2/checkout/orders", {
        intent: "AUTHORIZE",
        purchase_units: [
          {
            amount: { currency_code: currencyCode, value: amount },
            description: details.description,
            ...(details.order_number
              ? { invoice_id: details.order_number }
              : {}),
          },
        ],
      })) as { id: string; status: string };

      return {
        success: true,
        gateway_transaction_id: order.id,
        status: order.status === "COMPLETED" ? "authorized" : "pending",
        amount,
        currency_code: currencyCode,
        gateway_response: order,
      };
    } catch (err) {
      return this.handleError(err, amount, currencyCode);
    }
  }

  async capture(transactionId: string, amount?: string): Promise<PaymentResult> {
    try {
      const result = (await this.apiRequest(
        "POST",
        `/v2/checkout/orders/${transactionId}/capture`
      )) as { id: string; status: string; purchase_units?: Array<{ payments?: { captures?: Array<{ amount?: { value: string; currency_code: string } }> } }> };

      const capturedAmount =
        amount ||
        result.purchase_units?.[0]?.payments?.captures?.[0]?.amount?.value ||
        "0";
      const currency =
        result.purchase_units?.[0]?.payments?.captures?.[0]?.amount?.currency_code || "";

      return {
        success: result.status === "COMPLETED",
        gateway_transaction_id: result.id,
        status: "captured",
        amount: capturedAmount,
        currency_code: currency,
        gateway_response: result,
      };
    } catch (err) {
      return this.handleError(err, amount || "0", "");
    }
  }

  async charge(
    amount: string,
    currencyCode: string,
    details: PaymentDetails
  ): Promise<PaymentResult> {
    // If a PayPal order ID was provided (client already approved), capture it
    if (details.payment_token) {
      return this.capture(details.payment_token, amount);
    }

    // Otherwise create an order with CAPTURE intent
    try {
      const order = (await this.apiRequest("POST", "/v2/checkout/orders", {
        intent: "CAPTURE",
        purchase_units: [
          {
            amount: { currency_code: currencyCode, value: amount },
            description: details.description,
            ...(details.order_number
              ? { invoice_id: details.order_number }
              : {}),
          },
        ],
      })) as { id: string; status: string };

      return {
        success: true,
        gateway_transaction_id: order.id,
        status: "pending",
        amount,
        currency_code: currencyCode,
        gateway_response: {
          ...order,
          note: "Order created. Client must approve before capture.",
        },
      };
    } catch (err) {
      return this.handleError(err, amount, currencyCode);
    }
  }

  async refund(transactionId: string, amount?: string): Promise<PaymentResult> {
    try {
      const body: Record<string, unknown> = {};
      if (amount) {
        body.amount = { value: amount, currency_code: "USD" };
      }

      const result = (await this.apiRequest(
        "POST",
        `/v2/payments/captures/${transactionId}/refund`,
        Object.keys(body).length > 0 ? body : undefined
      )) as { id: string; status: string; amount?: { value: string; currency_code: string } };

      return {
        success: result.status === "COMPLETED",
        gateway_transaction_id: result.id,
        status: "refunded",
        amount: amount || result.amount?.value || "0",
        currency_code: result.amount?.currency_code || "",
        gateway_response: result,
      };
    } catch (err) {
      return this.handleError(err, amount || "0", "");
    }
  }

  async void(transactionId: string): Promise<PaymentResult> {
    try {
      await this.apiRequest(
        "POST",
        `/v2/payments/authorizations/${transactionId}/void`
      );

      return {
        success: true,
        gateway_transaction_id: transactionId,
        status: "voided",
        amount: "0",
        currency_code: "",
        gateway_response: { voided: true },
      };
    } catch (err) {
      return this.handleError(err, "0", "");
    }
  }

  private handleError(
    err: unknown,
    amount: string,
    currencyCode: string
  ): PaymentResult {
    const message =
      err instanceof Error ? err.message : "Unknown PayPal error";
    return {
      success: false,
      gateway_transaction_id: null,
      status: "failed",
      amount,
      currency_code: currencyCode,
      gateway_response: { error: message },
      error_message: message,
    };
  }
}
