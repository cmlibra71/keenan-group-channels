import { PgColumn } from "drizzle-orm/pg-core";
import { orders, orderItems, products, productVariants } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { ForeignKeyValidation } from "../../base/types";

/**
 * Service for managing order items.
 */
class OrderItemServiceClass extends NestedService<typeof orders, typeof orderItems> {
  constructor() {
    super(orders, orderItems, {
      resourceName: "Order Item",
      parentResourceName: "Order",
      defaultSort: "id",
      sortColumns: {
        id: orderItems.id,
        name: orderItems.name,
        quantity: orderItems.quantity,
        created_at: orderItems.createdAt,
      },
      filterColumns: {
        product_id: orderItems.productId,
        variant_id: orderItems.variantId,
        sku: orderItems.sku,
        type: orderItems.type,
        is_refunded: orderItems.isRefunded,
      },
      allowedFilters: ["product_id", "variant_id", "sku", "type", "is_refunded"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return orders.id;
  }

  protected getParentForeignKey(): PgColumn {
    return orderItems.orderId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "orderId";
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: products,
        column: products.id,
        resourceName: "Product",
        fieldName: "productId",
        optional: true,
      },
      {
        table: productVariants,
        column: productVariants.id,
        resourceName: "Product Variant",
        fieldName: "variantId",
        optional: true,
      },
    ];
  }

  async createManyForParent(orderId: number, items: Array<Record<string, unknown>>) {
    if (items.length === 0) return [];

    const rows = items.map((item) => ({
      ...item,
      orderId,
      createdAt: new Date(),
      updatedAt: new Date(),
    }));

    return this.db
      .insert(orderItems)
      .values(rows as any)
      .returning();
  }
}

export const orderItemService = new OrderItemServiceClass();
