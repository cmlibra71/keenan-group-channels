/**
 * Backfill Meilisearch indexes with all products, grouped by channel.
 * Run with: npx tsx scripts/backfill-meilisearch.ts
 *
 * Requires:
 *   COMMERCE_DATABASE_URL - PostgreSQL connection string
 *   MEILI_URL            - Meilisearch URL (e.g. http://localhost:7700)
 *   MEILI_API_KEY        - Meilisearch master/admin key
 */
import "dotenv/config";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { eq, and, gt, sql, inArray } from "drizzle-orm";
import {
  products,
  brands,
  categories,
  productCategories,
  productImages,
  productChannelAssignments,
  productVariants,
} from "../src/schema";
import type { MeilisearchProductDocument } from "../src/search/meilisearch";
import { MeiliSearch } from "meilisearch";

const BATCH_SIZE = 500;
const MEILI_BATCH_SIZE = 1000;

const INDEX_SETTINGS = {
  searchableAttributes: [
    "name",
    "sku",
    "brandName",
    "categoryNames",
    "searchKeywords",
    "description",
  ],
  filterableAttributes: [
    "brandName",
    "categoryNames",
    "categoryIds",
    "price",
    "salePrice",
    "isFeatured",
    "isOnSale",
  ],
  sortableAttributes: ["name", "price", "createdAt"],
  rankingRules: [
    "words",
    "typo",
    "exactness",
    "proximity",
    "attribute",
    "sort",
  ],
  typoTolerance: {
    minWordSizeForTypos: {
      oneTypo: 4,
      twoTypos: 8,
    },
  },
};

async function main() {
  const connectionString = process.env.COMMERCE_DATABASE_URL;
  if (!connectionString) {
    console.error("COMMERCE_DATABASE_URL is not set");
    process.exit(1);
  }

  const meiliUrl = process.env.MEILI_URL;
  if (!meiliUrl) {
    console.error("MEILI_URL is not set (e.g. http://localhost:7700)");
    process.exit(1);
  }

  const meiliKey = process.env.MEILI_API_KEY;
  const meili = new MeiliSearch({ host: meiliUrl, apiKey: meiliKey || undefined });

  // Verify connection
  try {
    const health = await meili.health();
    console.log(`Meilisearch status: ${health.status}`);
  } catch (err) {
    console.error("Cannot connect to Meilisearch:", (err as Error).message);
    process.exit(1);
  }

  const client = postgres(connectionString, { prepare: false, max: 3 });
  const db = drizzle(client);

  // Count visible, non-deleted products
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(products)
    .where(eq(products.isDeleted, false));

  console.log(`Found ${count} products to index`);

  if (count === 0) {
    console.log("Nothing to do!");
    await client.end();
    return;
  }

  // Discover all channels with product assignments
  const channelRows = await db
    .selectDistinct({ channelId: productChannelAssignments.channelId })
    .from(productChannelAssignments);
  const channelIds = channelRows.map((r) => r.channelId);
  console.log(`Channels with assignments: ${channelIds.join(", ")}`);

  // Ensure indexes exist for all channels
  for (const channelId of channelIds) {
    const indexName = `products_channel_${channelId}`;
    console.log(`Ensuring index: ${indexName}`);
    await meili.createIndex(indexName, { primaryKey: "id" });
    const index = meili.index(indexName);
    await index.updateSettings(INDEX_SETTINGS);
  }

  // Pre-fetch all channel assignments into a map: productId -> channelId[]
  console.log("Loading channel assignments...");
  const allAssignments = await db
    .select({
      productId: productChannelAssignments.productId,
      channelId: productChannelAssignments.channelId,
    })
    .from(productChannelAssignments)
    .where(eq(productChannelAssignments.isVisible, true));

  const assignmentMap = new Map<number, number[]>();
  for (const a of allAssignments) {
    const existing = assignmentMap.get(a.productId) || [];
    existing.push(a.channelId);
    assignmentMap.set(a.productId, existing);
  }
  console.log(`Loaded ${allAssignments.length} assignments for ${assignmentMap.size} products`);

  let processed = 0;
  let indexed = 0;
  let lastId = 0;

  // Per-channel document buffers for batch flushing
  const channelBuffers = new Map<number, MeilisearchProductDocument[]>();
  for (const cid of channelIds) channelBuffers.set(cid, []);

  async function flushChannel(channelId: number, force = false) {
    const buffer = channelBuffers.get(channelId)!;
    if (buffer.length === 0) return;
    if (!force && buffer.length < MEILI_BATCH_SIZE) return;

    const index = meili.index(`products_channel_${channelId}`);
    await index.addDocuments(buffer);
    indexed += buffer.length;
    channelBuffers.set(channelId, []);
  }

  while (true) {
    // Fetch next batch of products
    const batch = await db
      .select()
      .from(products)
      .where(
        and(
          sql`${products.id} > ${lastId}`,
          eq(products.isDeleted, false)
        )
      )
      .orderBy(products.id)
      .limit(BATCH_SIZE);

    if (batch.length === 0) break;
    lastId = batch[batch.length - 1].id;
    const batchIds = batch.map((p) => p.id);

    // Batch-fetch brands
    const brandIds = [...new Set(batch.map((p) => p.brandId).filter(Boolean))] as number[];
    const brandMap = new Map<number, string>();
    if (brandIds.length > 0) {
      const brandRows = await db
        .select({ id: brands.id, name: brands.name })
        .from(brands)
        .where(inArray(brands.id, brandIds));
      for (const b of brandRows) brandMap.set(b.id, b.name);
    }

    // Batch-fetch categories
    const catRows = await db
      .selectDistinct({
        productId: productCategories.productId,
        categoryId: categories.id,
        categoryName: categories.name,
      })
      .from(productCategories)
      .innerJoin(categories, eq(categories.id, productCategories.categoryId))
      .where(inArray(productCategories.productId, batchIds));

    const catMap = new Map<number, { ids: number[]; names: string[] }>();
    for (const row of catRows) {
      const existing = catMap.get(row.productId) || { ids: [], names: [] };
      existing.ids.push(row.categoryId);
      existing.names.push(row.categoryName);
      catMap.set(row.productId, existing);
    }

    // Batch-fetch thumbnails
    const thumbnailRows = await db
      .select({
        productId: productImages.productId,
        urlThumbnail: productImages.urlThumbnail,
        urlStandard: productImages.urlStandard,
      })
      .from(productImages)
      .where(
        and(
          inArray(productImages.productId, batchIds),
          eq(productImages.isThumbnail, true)
        )
      );

    const thumbnailMap = new Map(
      thumbnailRows.map((t) => [t.productId, t.urlThumbnail || t.urlStandard])
    );

    // Fetch min variant prices for $0-price products in this batch
    const zeroPriceIds = batch.filter((p) => !parseFloat(p.price)).map((p) => p.id);
    const minVariantPriceMap = new Map<number, number>();
    if (zeroPriceIds.length > 0) {
      const minRows = await db
        .select({
          productId: productVariants.productId,
          minPrice: sql<string>`MIN(${productVariants.price})`,
        })
        .from(productVariants)
        .where(and(inArray(productVariants.productId, zeroPriceIds), gt(productVariants.price, "0")))
        .groupBy(productVariants.productId);
      for (const row of minRows) {
        minVariantPriceMap.set(row.productId, parseFloat(row.minPrice));
      }
    }

    // Build documents and distribute to channel buffers
    for (const product of batch) {
      const channels = assignmentMap.get(product.id);
      if (!channels || channels.length === 0) continue;

      let price = parseFloat(product.price) || 0;
      if (price === 0) price = minVariantPriceMap.get(product.id) ?? 0;
      const salePrice = product.salePrice ? parseFloat(product.salePrice) : null;
      const cats = catMap.get(product.id) || { ids: [], names: [] };

      const doc: MeilisearchProductDocument = {
        id: product.id,
        name: product.name,
        sku: product.sku,
        urlPath: product.urlPath,
        description: product.description,
        descriptionShort: product.descriptionShort,
        price,
        salePrice,
        costPrice: product.costPrice ? parseFloat(product.costPrice) : null,
        brandId: product.brandId,
        brandName: product.brandId ? brandMap.get(product.brandId) ?? null : null,
        categoryIds: cats.ids,
        categoryNames: cats.names,
        searchKeywords: product.searchKeywords,
        isFeatured: product.isFeatured ?? false,
        isOnSale: salePrice !== null && salePrice > 0 && salePrice < price,
        thumbnailUrl: thumbnailMap.get(product.id) || null,
        createdAt: product.createdAt
          ? Math.floor(new Date(product.createdAt).getTime() / 1000)
          : 0,
      };

      for (const channelId of channels) {
        const buffer = channelBuffers.get(channelId);
        if (buffer) {
          buffer.push(doc);
        }
      }
    }

    // Flush any full buffers
    for (const channelId of channelIds) {
      await flushChannel(channelId);
    }

    processed += batch.length;
    console.log(`Progress: ${processed}/${count} products processed, ${indexed} documents indexed`);
  }

  // Flush remaining buffers
  for (const channelId of channelIds) {
    await flushChannel(channelId, true);
  }

  console.log(`\nDone! ${processed} products processed, ${indexed} total documents indexed across ${channelIds.length} channel(s).`);
  await client.end();
}

main().catch((err) => {
  console.error("Backfill failed:", err);
  process.exit(1);
});
