import { eq } from "drizzle-orm";
import { PgColumn } from "drizzle-orm/pg-core";
import { products, productVariants, productVariantOptions, inventoryLevels, priceListRecords } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { UniqueConstraint, DependencyCheck } from "../../base/types";

/**
 * Service for managing product variants.
 */
class ProductVariantServiceClass extends NestedService<typeof products, typeof productVariants> {
  constructor() {
    super(products, productVariants, {
      resourceName: "Variant",
      parentResourceName: "Product",
      defaultSort: "id",
      sortColumns: {
        id: productVariants.id,
        sku: productVariants.sku,
        sort_order: productVariants.sortOrder,
        created_at: productVariants.createdAt,
      },
      filterColumns: {
        sku: productVariants.sku,
        purchasing_disabled: productVariants.purchasingDisabled,
      },
      allowedFilters: ["sku", "purchasing_disabled"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return products.id;
  }

  protected getParentForeignKey(): PgColumn {
    return productVariants.productId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "productId";
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [{ column: productVariants.sku, fieldName: "sku" }],
        message: "Variant SKU is already in use.",
      },
    ];
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: inventoryLevels,
        foreignKeyColumn: inventoryLevels.variantId,
        resourceName: "inventory level",
        message: "Cannot delete variant because it has {count} inventory level(s). Delete inventory levels first.",
      },
      {
        table: priceListRecords,
        foreignKeyColumn: priceListRecords.variantId,
        resourceName: "price list record",
        message: "Cannot delete variant because it has {count} price list record(s).",
      },
    ];
  }

  // ── Storefront methods ────────────────────────────────────────────

  /**
   * Get all variants for a product, ordered by sort order.
   */
  async getForProduct(productId: number) {
    return this.db
      .select()
      .from(productVariants)
      .where(eq(productVariants.productId, productId))
      .orderBy(productVariants.sortOrder);
  }

  /**
   * Replace all option-value linkages for a variant.
   * Deletes existing linkages and inserts the new ones.
   */
  async syncOptionValues(
    variantId: number,
    optionValues: { optionId: number; optionValueId: number }[]
  ): Promise<void> {
    await this.db
      .delete(productVariantOptions)
      .where(eq(productVariantOptions.variantId, variantId));

    if (optionValues.length > 0) {
      await this.db.insert(productVariantOptions).values(
        optionValues.map((ov) => ({
          variantId,
          optionId: ov.optionId,
          optionValueId: ov.optionValueId,
        }))
      );
    }
  }

  /**
   * Insert option-value linkages for a variant (no delete).
   */
  async addOptionValues(
    variantId: number,
    optionValues: { optionId: number; optionValueId: number }[]
  ): Promise<void> {
    if (optionValues.length === 0) return;
    await this.db.insert(productVariantOptions).values(
      optionValues.map((ov) => ({
        variantId,
        optionId: ov.optionId,
        optionValueId: ov.optionValueId,
      }))
    );
  }
}

export const productVariantService = new ProductVariantServiceClass();
