import { and, eq } from "drizzle-orm";
import {
  customers,
  channels,
  customerGroups,
  customerAddresses,
  wishlists,
  orders,
  carts,
} from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation, UniqueConstraint, IncludeConfig } from "../../base/types";

/**
 * Service for managing customers.
 */
class CustomerServiceClass extends BaseService<typeof customers> {
  constructor() {
    super(customers, {
      resourceName: "Customer",
      defaultSort: "id",
      sortColumns: {
        id: customers.id,
        email: customers.email,
        first_name: customers.firstName,
        last_name: customers.lastName,
        created_at: customers.createdAt,
        updated_at: customers.updatedAt,
      },
      filterColumns: {
        email: customers.email,
        first_name: customers.firstName,
        last_name: customers.lastName,
        origin_channel_id: customers.originChannelId,
        customer_group_id: customers.customerGroupId,
        is_active: customers.isActive,
        company: customers.company,
      },
      allowedFilters: [
        "email",
        "first_name",
        "last_name",
        "origin_channel_id",
        "customer_group_id",
        "is_active",
        "company",
      ],
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: channels,
        column: channels.id,
        resourceName: "Channel",
        fieldName: "originChannelId",
        optional: true,
      },
      {
        table: customerGroups,
        column: customerGroups.id,
        resourceName: "Customer Group",
        fieldName: "customerGroupId",
        optional: true,
      },
    ];
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [
          { column: customers.originChannelId, fieldName: "originChannelId" },
          { column: customers.email, fieldName: "email" },
        ],
        message: "Customer with this email already exists for this channel.",
        composite: true,
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "addresses",
        table: customerAddresses,
        foreignKey: customerAddresses.customerId,
      },
    ];
  }

  async findByEmailAndChannel(email: string, channelId: number) {
    const [customer] = await this.db
      .select()
      .from(customers)
      .where(
        and(
          eq(customers.email, email),
          eq(customers.originChannelId, channelId),
          eq(customers.isActive, true)
        )
      )
      .limit(1);
    return customer || null;
  }
}

export const customerService = new CustomerServiceClass();
