import { eq } from "drizzle-orm";
import { giftCertificates } from "../../schema";
import { BaseService } from "../../base/BaseService";
import { NotFoundError, ValidationError } from "../../errors";
import { transformRow } from "../../transforms";
import { UniqueConstraint } from "../../base/types";

/**
 * Service for managing gift certificates.
 */
class GiftCertificateServiceClass extends BaseService<typeof giftCertificates> {
  constructor() {
    super(giftCertificates, {
      resourceName: "Gift Certificate",
      defaultSort: "id",
      sortColumns: {
        id: giftCertificates.id,
        code: giftCertificates.code,
        balance: giftCertificates.balance,
        created_at: giftCertificates.createdAt,
      },
      filterColumns: {
        status: giftCertificates.status,
        code: giftCertificates.code,
        contact_id: giftCertificates.contactId,
      },
      allowedFilters: ["status", "code", "contact_id"],
      timestamps: {
        created: "createdAt",
      },
    });
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [{ column: giftCertificates.code, fieldName: "code" }],
        message: "Gift certificate code already exists.",
      },
    ];
  }

  /**
   * Adjust the balance of a gift certificate.
   * Positive amount increases balance, negative decreases.
   * Balance cannot go below 0. Auto-marks as "redeemed" when balance hits 0.
   */
  async adjustBalance(
    id: number,
    amount: string
  ): Promise<{
    giftCertificate: Record<string, unknown>;
    adjustment: {
      amount: string;
      previousBalance: string;
      newBalance: string;
    };
  }> {
    const [record] = await this.db
      .select()
      .from(giftCertificates)
      .where(eq(giftCertificates.id, id))
      .limit(1);

    if (!record) {
      throw new NotFoundError("Gift Certificate", id);
    }

    if (record.status !== "active") {
      throw new ValidationError(
        "Cannot adjust balance of a gift certificate that is not active.",
        { status: `Current status is '${record.status}'` }
      );
    }

    const adjustmentAmount = parseFloat(amount);
    if (isNaN(adjustmentAmount)) {
      throw new ValidationError("Invalid adjustment amount.", {
        amount: "Amount must be a valid number",
      });
    }

    const currentBalance = parseFloat(record.balance);
    const newBalance = currentBalance + adjustmentAmount;

    if (newBalance < 0) {
      throw new ValidationError(
        "Insufficient balance. The adjustment would result in a negative balance.",
        {
          current_balance: currentBalance.toFixed(4),
          adjustment: adjustmentAmount.toFixed(4),
          resulting_balance: newBalance.toFixed(4),
        }
      );
    }

    const newStatus = newBalance === 0 ? "redeemed" : record.status;

    const [updated] = await this.db
      .update(giftCertificates)
      .set({
        balance: newBalance.toFixed(4),
        status: newStatus,
      })
      .where(eq(giftCertificates.id, id))
      .returning();

    return {
      giftCertificate: transformRow(updated as Record<string, unknown>),
      adjustment: {
        amount: adjustmentAmount.toFixed(4),
        previousBalance: currentBalance.toFixed(4),
        newBalance: newBalance.toFixed(4),
      },
    };
  }
}

export const giftCertificateService = new GiftCertificateServiceClass();
