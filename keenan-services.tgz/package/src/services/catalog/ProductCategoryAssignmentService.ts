import { eq, and, count, sql } from "drizzle-orm";
import { getCommerceDb } from "../../db";
import {
  productCategories,
  products,
  categories,
} from "../../schema";
import { NotFoundError, ConflictError } from "../../errors";
import { transformRow, transformRows } from "../../transforms";

interface AssignmentOptions {
  sortOrder?: number;
  isPrimary?: boolean;
}

/**
 * Service for managing product-category assignments.
 * Handles the join table between products and categories.
 */
class ProductCategoryAssignmentServiceClass {
  private get db() {
    return getCommerceDb();
  }

  /**
   * Get all category assignments for a product
   */
  async getCategoriesForProduct(productId: number): Promise<Record<string, unknown>[]> {
    await this.validateProduct(productId);

    const results = await this.db
      .select({
        id: productCategories.id,
        productId: productCategories.productId,
        categoryId: productCategories.categoryId,
        categoryName: categories.name,
        sortOrder: productCategories.sortOrder,
        isPrimary: productCategories.isPrimary,
      })
      .from(productCategories)
      .innerJoin(categories, eq(productCategories.categoryId, categories.id))
      .where(eq(productCategories.productId, productId));

    return transformRows(results as unknown as Record<string, unknown>[]);
  }

  /**
   * Get a single assignment
   */
  async getAssignment(productId: number, categoryId: number): Promise<Record<string, unknown> | null> {
    const [result] = await this.db
      .select()
      .from(productCategories)
      .where(
        and(
          eq(productCategories.productId, productId),
          eq(productCategories.categoryId, categoryId)
        )
      )
      .limit(1);

    return result ? transformRow(result as Record<string, unknown>) : null;
  }

  /**
   * Assign a product to a category
   */
  async assign(
    productId: number,
    categoryId: number,
    options: AssignmentOptions = {}
  ): Promise<Record<string, unknown>> {
    await this.validateProduct(productId);
    await this.validateCategory(categoryId);

    const existing = await this.getAssignment(productId, categoryId);
    if (existing) {
      throw new ConflictError(`Product ${productId} is already assigned to category ${categoryId}.`);
    }

    const [result] = await this.db
      .insert(productCategories)
      .values({
        productId,
        categoryId,
        sortOrder: options.sortOrder ?? 0,
        isPrimary: options.isPrimary ?? false,
      })
      .returning();

    return transformRow(result as Record<string, unknown>);
  }

  /**
   * Remove a product from a category
   */
  async remove(productId: number, categoryId: number): Promise<void> {
    const existing = await this.getAssignment(productId, categoryId);
    if (!existing) {
      throw new NotFoundError("Assignment", `${productId}-${categoryId}`);
    }

    await this.db
      .delete(productCategories)
      .where(
        and(
          eq(productCategories.productId, productId),
          eq(productCategories.categoryId, categoryId)
        )
      );
  }

  /**
   * Get product counts grouped by category.
   * Returns a map of categoryId → count.
   */
  async countByCategory(): Promise<Record<number, number>> {
    const rows = await this.db
      .select({
        categoryId: productCategories.categoryId,
        count: count(),
      })
      .from(productCategories)
      .groupBy(productCategories.categoryId);

    const result: Record<number, number> = {};
    for (const row of rows) {
      result[row.categoryId] = row.count;
    }
    return result;
  }

  private async validateProduct(productId: number): Promise<void> {
    const [product] = await this.db
      .select({ id: products.id })
      .from(products)
      .where(and(eq(products.id, productId), eq(products.isDeleted, false)))
      .limit(1);

    if (!product) {
      throw new NotFoundError("Product", productId);
    }
  }

  private async validateCategory(categoryId: number): Promise<void> {
    const [category] = await this.db
      .select({ id: categories.id })
      .from(categories)
      .where(eq(categories.id, categoryId))
      .limit(1);

    if (!category) {
      throw new NotFoundError("Category", categoryId);
    }
  }
}

export const productCategoryAssignmentService = new ProductCategoryAssignmentServiceClass();
