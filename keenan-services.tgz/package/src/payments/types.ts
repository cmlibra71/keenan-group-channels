/**
 * Payment gateway types and interfaces.
 *
 * Every provider implements PaymentProvider. The PaymentService orchestrator
 * loads the correct provider based on gateway config and delegates calls.
 */

// ============================================================================
// Provider Interface
// ============================================================================

export interface PaymentProvider {
  readonly providerName: string;

  /** Test that credentials are valid (e.g. Stripe balance.retrieve) */
  validateCredentials(
    credentials: Record<string, string>,
    testMode: boolean
  ): Promise<CredentialValidationResult>;

  /** Authorize only — hold funds without capturing */
  authorize(
    amount: string,
    currencyCode: string,
    details: PaymentDetails
  ): Promise<PaymentResult>;

  /** Capture a previous authorization */
  capture(transactionId: string, amount?: string): Promise<PaymentResult>;

  /** Authorize + capture in one step */
  charge(
    amount: string,
    currencyCode: string,
    details: PaymentDetails
  ): Promise<PaymentResult>;

  /** Refund a captured payment */
  refund(transactionId: string, amount?: string): Promise<PaymentResult>;

  /** Void an authorization (before capture) */
  void(transactionId: string): Promise<PaymentResult>;
}

// ============================================================================
// Result Types
// ============================================================================

export type PaymentStatus =
  | "authorized"
  | "captured"
  | "refunded"
  | "voided"
  | "declined"
  | "failed"
  | "pending";

export interface PaymentResult {
  success: boolean;
  gateway_transaction_id: string | null;
  status: PaymentStatus;
  amount: string;
  currency_code: string;
  /** Raw provider response — stored in order_transactions.gateway_response JSONB */
  gateway_response: Record<string, unknown>;
  error_message?: string;
}

export interface CredentialValidationResult {
  valid: boolean;
  message: string;
  /** Additional info from provider (e.g. account name, merchant ID) */
  details?: Record<string, unknown>;
}

// ============================================================================
// Payment Details (input from caller)
// ============================================================================

export interface PaymentDetails {
  /** Stripe: payment method ID; Square: source_id nonce; PayPal: paypal_order_id */
  payment_token?: string;
  /** Optional customer email for receipts */
  customer_email?: string;
  /** Optional description shown on statements */
  description?: string;
  /** Optional order reference */
  order_id?: number;
  order_number?: string;
  /** Extra metadata to pass through to the gateway */
  metadata?: Record<string, string>;
}

// ============================================================================
// Gateway Config (stored in store_settings as payment_gateways)
// ============================================================================

export interface PaymentGatewayConfig {
  id: string;
  name: string;
  provider: "stripe" | "paypal" | "square" | "manual";
  enabled: boolean;
  testMode: boolean;
  credentials: Record<string, string>;
}
