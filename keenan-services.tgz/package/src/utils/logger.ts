type LogLevel = "debug" | "info" | "warn" | "error";

interface LogEntry {
  level: LogLevel;
  message: string;
  timestamp: string;
  requestId?: string;
  userId?: string;
  path?: string;
  method?: string;
  duration?: number;
  statusCode?: number;
  error?: { message: string; stack?: string };
  [key: string]: unknown;
}

/**
 * Create a structured log entry
 */
function log(level: LogLevel, message: string, meta?: Partial<LogEntry>) {
  const entry: LogEntry = {
    level,
    message,
    timestamp: new Date().toISOString(),
    ...meta,
  };

  // In development, use readable format
  if (process.env.NODE_ENV === "development") {
    const prefix = `[${entry.timestamp}] [${level.toUpperCase()}]`;
    const details = meta ? ` ${JSON.stringify(meta)}` : "";
    console.log(`${prefix} ${message}${details}`);
    return;
  }

  // In production, use JSON format for log aggregation services
  console.log(JSON.stringify(entry));
}

/**
 * Structured logger for consistent logging across the application
 */
export const logger = {
  debug: (msg: string, meta?: Partial<LogEntry>) => log("debug", msg, meta),
  info: (msg: string, meta?: Partial<LogEntry>) => log("info", msg, meta),
  warn: (msg: string, meta?: Partial<LogEntry>) => log("warn", msg, meta),
  error: (msg: string, meta?: Partial<LogEntry>) => log("error", msg, meta),
};

/**
 * Create a logger instance with pre-bound context (e.g., requestId)
 */
export function createLogger(context: Partial<LogEntry>) {
  return {
    debug: (msg: string, meta?: Partial<LogEntry>) =>
      log("debug", msg, { ...context, ...meta }),
    info: (msg: string, meta?: Partial<LogEntry>) =>
      log("info", msg, { ...context, ...meta }),
    warn: (msg: string, meta?: Partial<LogEntry>) =>
      log("warn", msg, { ...context, ...meta }),
    error: (msg: string, meta?: Partial<LogEntry>) =>
      log("error", msg, { ...context, ...meta }),
  };
}
