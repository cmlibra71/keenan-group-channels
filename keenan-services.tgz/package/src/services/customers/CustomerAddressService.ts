import { eq } from "drizzle-orm";
import { PgColumn } from "drizzle-orm/pg-core";
import { customers, customerAddresses } from "../../schema";
import { NestedService } from "../../base/NestedService";

/**
 * Service for managing customer addresses.
 */
class CustomerAddressServiceClass extends NestedService<typeof customers, typeof customerAddresses> {
  constructor() {
    super(customers, customerAddresses, {
      resourceName: "Address",
      parentResourceName: "Customer",
      defaultSort: "id",
      sortColumns: {
        id: customerAddresses.id,
        city: customerAddresses.city,
        country: customerAddresses.country,
        created_at: customerAddresses.createdAt,
      },
      filterColumns: {
        address_type: customerAddresses.addressType,
        is_default_billing: customerAddresses.isDefaultBilling,
        is_default_shipping: customerAddresses.isDefaultShipping,
        country: customerAddresses.country,
        city: customerAddresses.city,
      },
      allowedFilters: ["address_type", "is_default_billing", "is_default_shipping", "country", "city"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return customers.id;
  }

  protected getParentForeignKey(): PgColumn {
    return customerAddresses.customerId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "customerId";
  }

  /**
   * Handle default billing/shipping flags
   */
  protected async beforeCreate(data: Record<string, unknown>): Promise<Record<string, unknown>> {
    const customerId = data.customerId as number;

    if (data.isDefaultBilling) {
      await this.db
        .update(customerAddresses)
        .set({ isDefaultBilling: false })
        .where(eq(customerAddresses.customerId, customerId));
    }

    if (data.isDefaultShipping) {
      await this.db
        .update(customerAddresses)
        .set({ isDefaultShipping: false })
        .where(eq(customerAddresses.customerId, customerId));
    }

    return data;
  }

  /**
   * Handle default billing/shipping flags on update
   */
  protected async beforeUpdate(
    data: Record<string, unknown>,
    existing: Record<string, unknown>
  ): Promise<Record<string, unknown>> {
    const customerId = existing.customerId as number;

    if (data.isDefaultBilling === true) {
      await this.db
        .update(customerAddresses)
        .set({ isDefaultBilling: false })
        .where(eq(customerAddresses.customerId, customerId));
    }

    if (data.isDefaultShipping === true) {
      await this.db
        .update(customerAddresses)
        .set({ isDefaultShipping: false })
        .where(eq(customerAddresses.customerId, customerId));
    }

    return data;
  }
}

export const customerAddressService = new CustomerAddressServiceClass();
