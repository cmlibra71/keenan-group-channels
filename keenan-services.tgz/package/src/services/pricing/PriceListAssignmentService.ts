import { priceLists, priceListAssignments, channels, customerGroups } from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation, UniqueConstraint } from "../../base/types";

/**
 * Service for managing price list assignments to channels and customer groups.
 */
class PriceListAssignmentServiceClass extends BaseService<typeof priceListAssignments> {
  constructor() {
    super(priceListAssignments, {
      resourceName: "Price List Assignment",
      defaultSort: "id",
      sortColumns: {
        id: priceListAssignments.id,
        price_list_id: priceListAssignments.priceListId,
        channel_id: priceListAssignments.channelId,
        priority: priceListAssignments.priority,
        created_at: priceListAssignments.createdAt,
      },
      filterColumns: {
        price_list_id: priceListAssignments.priceListId,
        channel_id: priceListAssignments.channelId,
        customer_group_id: priceListAssignments.customerGroupId,
      },
      allowedFilters: ["price_list_id", "channel_id", "customer_group_id"],
      timestamps: {
        created: "createdAt",
      },
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: priceLists,
        column: priceLists.id,
        resourceName: "Price List",
        fieldName: "priceListId",
        optional: false,
      },
      {
        table: channels,
        column: channels.id,
        resourceName: "Channel",
        fieldName: "channelId",
        optional: true,
      },
      {
        table: customerGroups,
        column: customerGroups.id,
        resourceName: "Customer Group",
        fieldName: "customerGroupId",
        optional: true,
      },
    ];
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [
          { column: priceListAssignments.priceListId, fieldName: "priceListId" },
          { column: priceListAssignments.channelId, fieldName: "channelId" },
          { column: priceListAssignments.customerGroupId, fieldName: "customerGroupId" },
        ],
        message:
          "This price list is already assigned to this channel/customer group combination.",
        composite: true,
      },
    ];
  }
}

export const priceListAssignmentService = new PriceListAssignmentServiceClass();
