import { PgColumn } from "drizzle-orm/pg-core";
import { shippingZones, shippingMethods } from "../../schema";
import { NestedService } from "../../base/NestedService";

/**
 * Service for managing shipping methods within shipping zones.
 *
 * Shipping methods define how items are shipped (flat rate, carrier-calculated, etc.)
 * and their associated costs.
 */
class ShippingMethodServiceClass extends NestedService<
  typeof shippingZones,
  typeof shippingMethods
> {
  constructor() {
    super(shippingZones, shippingMethods, {
      resourceName: "Shipping Method",
      parentResourceName: "Shipping Zone",
      defaultSort: "id",
      sortColumns: {
        id: shippingMethods.id,
        name: shippingMethods.name,
        sort_order: shippingMethods.sortOrder,
      },
      filterColumns: {
        type: shippingMethods.type,
        enabled: shippingMethods.enabled,
        carrier: shippingMethods.carrier,
      },
      allowedFilters: ["type", "enabled", "carrier"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return shippingZones.id;
  }

  protected getParentForeignKey(): PgColumn {
    return shippingMethods.shippingZoneId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "shippingZoneId";
  }
}

export const shippingMethodService = new ShippingMethodServiceClass();
