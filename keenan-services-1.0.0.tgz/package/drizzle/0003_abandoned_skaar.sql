ALTER TABLE "product_attachments" ADD COLUMN "channel_id" integer;--> statement-breakpoint
ALTER TABLE "products" ADD COLUMN "purchasing_disabled" boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE "products" ADD COLUMN "purchasing_disabled_message" text;--> statement-breakpoint
ALTER TABLE "product_attachments" ADD CONSTRAINT "product_attachments_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_product_attachments_product_channel" ON "product_attachments" USING btree ("product_id","channel_id");