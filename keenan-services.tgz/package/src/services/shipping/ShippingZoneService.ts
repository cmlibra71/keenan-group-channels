import { shippingZones, shippingMethods } from "../../schema";
import { BaseService } from "../../base/BaseService";
import { DependencyCheck, IncludeConfig } from "../../base/types";

/**
 * Service for managing shipping zones.
 *
 * Shipping zones define geographic regions and their associated shipping methods.
 */
class ShippingZoneServiceClass extends BaseService<typeof shippingZones> {
  constructor() {
    super(shippingZones, {
      resourceName: "Shipping Zone",
      defaultSort: "id",
      sortColumns: {
        id: shippingZones.id,
        name: shippingZones.name,
        created_at: shippingZones.createdAt,
      },
      filterColumns: {
        name: shippingZones.name,
        type: shippingZones.type,
        enabled: shippingZones.enabled,
      },
      allowedFilters: ["name", "type", "enabled"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  /**
   * Prevent deletion if shipping methods are associated with this zone.
   */
  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: shippingMethods,
        foreignKeyColumn: shippingMethods.shippingZoneId,
        resourceName: "shipping method",
        message:
          "Cannot delete shipping zone because it has {count} shipping method(s) associated. Remove or reassign shipping methods first.",
      },
    ];
  }

  /**
   * Include shipping methods when requested.
   */
  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "methods",
        table: shippingMethods,
        foreignKey: shippingMethods.shippingZoneId,
      },
    ];
  }
}

export const shippingZoneService = new ShippingZoneServiceClass();
