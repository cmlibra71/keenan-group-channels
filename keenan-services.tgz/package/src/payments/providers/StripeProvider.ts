import Stripe from "stripe";
import type {
  PaymentProvider,
  PaymentResult,
  PaymentDetails,
  CredentialValidationResult,
} from "../types";

/**
 * Stripe payment provider using PaymentIntents API.
 *
 * Amounts are converted to cents (smallest currency unit).
 * Credentials: { secret_key, publishable_key }
 */
export class StripeProvider implements PaymentProvider {
  readonly providerName = "stripe";
  private stripe: Stripe;

  constructor(secretKey: string) {
    this.stripe = new Stripe(secretKey);
  }

  /** Convert decimal string to cents */
  private toCents(amount: string): number {
    return Math.round(parseFloat(amount) * 100);
  }

  async validateCredentials(
    credentials: Record<string, string>,
    testMode: boolean
  ): Promise<CredentialValidationResult> {
    try {
      const client = new Stripe(credentials.secret_key);
      const balance = await client.balance.retrieve();
      return {
        valid: true,
        message: testMode
          ? "Connected to Stripe (test mode)"
          : "Connected to Stripe (live mode)",
        details: {
          available: balance.available,
          livemode: balance.livemode,
        },
      };
    } catch (err) {
      const message =
        err instanceof Stripe.errors.StripeAuthenticationError
          ? "Invalid Stripe secret key"
          : err instanceof Error
            ? err.message
            : "Failed to connect to Stripe";
      return { valid: false, message };
    }
  }

  async authorize(
    amount: string,
    currencyCode: string,
    details: PaymentDetails
  ): Promise<PaymentResult> {
    try {
      const params: Stripe.PaymentIntentCreateParams = {
        amount: this.toCents(amount),
        currency: currencyCode.toLowerCase(),
        capture_method: "manual",
        description: details.description,
        metadata: {
          ...details.metadata,
          ...(details.order_id ? { order_id: String(details.order_id) } : {}),
          ...(details.order_number ? { order_number: details.order_number } : {}),
        },
      };

      if (details.payment_token) {
        params.payment_method = details.payment_token;
        params.confirm = true;
        params.automatic_payment_methods = { enabled: true, allow_redirects: "never" };
      }

      if (details.customer_email) {
        params.receipt_email = details.customer_email;
      }

      const intent = await this.stripe.paymentIntents.create(params);

      return {
        success: intent.status === "requires_capture",
        gateway_transaction_id: intent.id,
        status: intent.status === "requires_capture" ? "authorized" : "pending",
        amount,
        currency_code: currencyCode,
        gateway_response: { id: intent.id, status: intent.status },
      };
    } catch (err) {
      return this.handleError(err, amount, currencyCode);
    }
  }

  async capture(transactionId: string, amount?: string): Promise<PaymentResult> {
    try {
      const params: Stripe.PaymentIntentCaptureParams = {};
      if (amount) {
        params.amount_to_capture = this.toCents(amount);
      }

      const intent = await this.stripe.paymentIntents.capture(transactionId, params);

      const captured = String(intent.amount_received / 100);
      return {
        success: intent.status === "succeeded",
        gateway_transaction_id: intent.id,
        status: "captured",
        amount: amount || captured,
        currency_code: intent.currency.toUpperCase(),
        gateway_response: { id: intent.id, status: intent.status },
      };
    } catch (err) {
      return this.handleError(err, amount || "0", "");
    }
  }

  async charge(
    amount: string,
    currencyCode: string,
    details: PaymentDetails
  ): Promise<PaymentResult> {
    try {
      const params: Stripe.PaymentIntentCreateParams = {
        amount: this.toCents(amount),
        currency: currencyCode.toLowerCase(),
        description: details.description,
        metadata: {
          ...details.metadata,
          ...(details.order_id ? { order_id: String(details.order_id) } : {}),
          ...(details.order_number ? { order_number: details.order_number } : {}),
        },
      };

      if (details.payment_token) {
        params.payment_method = details.payment_token;
        params.confirm = true;
        params.automatic_payment_methods = { enabled: true, allow_redirects: "never" };
      }

      if (details.customer_email) {
        params.receipt_email = details.customer_email;
      }

      const intent = await this.stripe.paymentIntents.create(params);

      return {
        success: intent.status === "succeeded",
        gateway_transaction_id: intent.id,
        status: intent.status === "succeeded" ? "captured" : "pending",
        amount,
        currency_code: currencyCode,
        gateway_response: { id: intent.id, status: intent.status },
      };
    } catch (err) {
      return this.handleError(err, amount, currencyCode);
    }
  }

  async refund(transactionId: string, amount?: string): Promise<PaymentResult> {
    try {
      const params: Stripe.RefundCreateParams = {
        payment_intent: transactionId,
      };
      if (amount) {
        params.amount = this.toCents(amount);
      }

      const refund = await this.stripe.refunds.create(params);

      const refundedAmount = String((refund.amount ?? 0) / 100);
      return {
        success: refund.status === "succeeded",
        gateway_transaction_id: refund.id,
        status: "refunded",
        amount: amount || refundedAmount,
        currency_code: (refund.currency || "").toUpperCase(),
        gateway_response: { id: refund.id, status: refund.status },
      };
    } catch (err) {
      return this.handleError(err, amount || "0", "");
    }
  }

  async void(transactionId: string): Promise<PaymentResult> {
    try {
      const intent = await this.stripe.paymentIntents.cancel(transactionId);

      return {
        success: intent.status === "canceled",
        gateway_transaction_id: intent.id,
        status: "voided",
        amount: String(intent.amount / 100),
        currency_code: intent.currency.toUpperCase(),
        gateway_response: { id: intent.id, status: intent.status },
      };
    } catch (err) {
      return this.handleError(err, "0", "");
    }
  }

  private handleError(
    err: unknown,
    amount: string,
    currencyCode: string
  ): PaymentResult {
    const message =
      err instanceof Stripe.errors.StripeError
        ? err.message
        : err instanceof Error
          ? err.message
          : "Unknown Stripe error";

    const isDecline =
      err instanceof Stripe.errors.StripeCardError;

    return {
      success: false,
      gateway_transaction_id: null,
      status: isDecline ? "declined" : "failed",
      amount,
      currency_code: currencyCode,
      gateway_response: {
        error: message,
        type: err instanceof Stripe.errors.StripeError ? err.type : "unknown",
      },
      error_message: message,
    };
  }
}
