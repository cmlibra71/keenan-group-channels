import { storeSettingsService } from "../services/settings/StoreSettingsService";
import { orderTransactionService } from "../services/orders/OrderTransactionService";
import { orderService } from "../services/orders/OrderService";
import { BadRequestError, NotFoundError } from "../errors";
import type {
  PaymentProvider,
  PaymentResult,
  PaymentDetails,
  PaymentGatewayConfig,
  CredentialValidationResult,
} from "./types";
import { ManualProvider } from "./providers/ManualProvider";
import { StripeProvider } from "./providers/StripeProvider";
import { PayPalProvider } from "./providers/PayPalProvider";
import { SquareProvider } from "./providers/SquareProvider";

/**
 * Payment orchestrator.
 *
 * Loads gateway config from store_settings -> creates the correct provider ->
 * delegates payment calls -> records transactions -> updates order payment_status.
 */
class PaymentServiceClass {
  // ============================================================================
  // Provider Factory
  // ============================================================================

  private createProvider(gateway: PaymentGatewayConfig): PaymentProvider {
    switch (gateway.provider) {
      case "stripe":
        return new StripeProvider(gateway.credentials.secret_key);
      case "paypal":
        return new PayPalProvider(
          gateway.credentials.client_id,
          gateway.credentials.client_secret,
          gateway.testMode
        );
      case "square":
        return new SquareProvider(
          gateway.credentials.access_token,
          gateway.credentials.location_id,
          gateway.testMode
        );
      case "manual":
        return new ManualProvider();
      default:
        throw new BadRequestError(`Unsupported payment provider: ${gateway.provider}`);
    }
  }

  // ============================================================================
  // Gateway Config Loader
  // ============================================================================

  private async getGateways(): Promise<PaymentGatewayConfig[]> {
    try {
      const setting = await storeSettingsService.getByKey("payment_gateways");
      return (setting.setting_value as PaymentGatewayConfig[]) || [];
    } catch {
      return [];
    }
  }

  private async getGateway(gatewayId: string): Promise<PaymentGatewayConfig> {
    const gateways = await this.getGateways();
    const gateway = gateways.find((g) => g.id === gatewayId);
    if (!gateway) {
      throw new NotFoundError("Payment Gateway", gatewayId);
    }
    if (!gateway.enabled) {
      throw new BadRequestError(`Payment gateway "${gateway.name}" is disabled.`);
    }
    return gateway;
  }

  private async getDefaultGateway(): Promise<PaymentGatewayConfig> {
    const gateways = await this.getGateways();
    const enabled = gateways.filter((g) => g.enabled);
    if (enabled.length === 0) {
      throw new BadRequestError("No enabled payment gateway configured.");
    }
    return enabled[0];
  }

  // ============================================================================
  // Transaction Recording
  // ============================================================================

  private async recordTransaction(
    orderId: number,
    event: string,
    result: PaymentResult,
    gateway: PaymentGatewayConfig
  ): Promise<void> {
    await orderTransactionService.createForParent(orderId, {
      event,
      method: gateway.provider,
      amount: result.amount,
      currency_code: result.currency_code,
      status: result.success ? "completed" : "failed",
      gateway: gateway.name,
      gateway_transaction_id: result.gateway_transaction_id,
      gateway_response: result.gateway_response,
    });
  }

  private async updateOrderPaymentStatus(
    orderId: number,
    status: string
  ): Promise<void> {
    await orderService.update(orderId, { payment_status: status });
  }

  // ============================================================================
  // Payment Operations
  // ============================================================================

  async charge(
    orderId: number,
    options: {
      gateway_id?: string;
      payment_token?: string;
      amount?: string;
      description?: string;
    }
  ): Promise<PaymentResult> {
    const order = await orderService.getById(orderId);
    const gateway = options.gateway_id
      ? await this.getGateway(options.gateway_id)
      : await this.getDefaultGateway();
    const provider = this.createProvider(gateway);

    const amount = options.amount || (order.total_inc_tax as string);
    const currencyCode = order.currency_code as string;

    const details: PaymentDetails = {
      payment_token: options.payment_token,
      description: options.description || `Order ${order.order_number || order.id}`,
      order_id: order.id as number,
      order_number: (order.order_number as string) || undefined,
    };

    const result = await provider.charge(amount, currencyCode, details);

    await this.recordTransaction(orderId, "purchase", result, gateway);

    if (result.success) {
      await this.updateOrderPaymentStatus(orderId, "paid");
    }

    return result;
  }

  async authorize(
    orderId: number,
    options: {
      gateway_id?: string;
      payment_token?: string;
      amount?: string;
      description?: string;
    }
  ): Promise<PaymentResult> {
    const order = await orderService.getById(orderId);
    const gateway = options.gateway_id
      ? await this.getGateway(options.gateway_id)
      : await this.getDefaultGateway();
    const provider = this.createProvider(gateway);

    const amount = options.amount || (order.total_inc_tax as string);
    const currencyCode = order.currency_code as string;

    const details: PaymentDetails = {
      payment_token: options.payment_token,
      description: options.description || `Order ${order.order_number || order.id}`,
      order_id: order.id as number,
      order_number: (order.order_number as string) || undefined,
    };

    const result = await provider.authorize(amount, currencyCode, details);

    await this.recordTransaction(orderId, "authorization", result, gateway);

    if (result.success) {
      await this.updateOrderPaymentStatus(orderId, "authorized");
    }

    return result;
  }

  async capture(
    orderId: number,
    options: {
      gateway_id?: string;
      transaction_id: string;
      amount?: string;
    }
  ): Promise<PaymentResult> {
    const gateway = options.gateway_id
      ? await this.getGateway(options.gateway_id)
      : await this.getDefaultGateway();
    const provider = this.createProvider(gateway);

    const result = await provider.capture(options.transaction_id, options.amount);

    await this.recordTransaction(orderId, "capture", result, gateway);

    if (result.success) {
      await this.updateOrderPaymentStatus(orderId, "paid");
    }

    return result;
  }

  async refund(
    orderId: number,
    options: {
      gateway_id?: string;
      transaction_id: string;
      amount?: string;
    }
  ): Promise<PaymentResult> {
    const gateway = options.gateway_id
      ? await this.getGateway(options.gateway_id)
      : await this.getDefaultGateway();
    const provider = this.createProvider(gateway);

    const result = await provider.refund(options.transaction_id, options.amount);

    await this.recordTransaction(orderId, "refund", result, gateway);

    if (result.success) {
      // Check if full or partial refund
      const order = await orderService.getById(orderId);
      const totalIncTax = parseFloat(order.total_inc_tax as string);
      const refundedAmount = parseFloat(order.refunded_amount as string || "0");
      const thisRefund = parseFloat(result.amount);
      const newRefunded = refundedAmount + thisRefund;

      await orderService.update(orderId, {
        refunded_amount: String(newRefunded),
      });

      if (newRefunded >= totalIncTax) {
        await this.updateOrderPaymentStatus(orderId, "refunded");
      } else {
        await this.updateOrderPaymentStatus(orderId, "partially_refunded");
      }
    }

    return result;
  }

  async voidPayment(
    orderId: number,
    options: {
      gateway_id?: string;
      transaction_id: string;
    }
  ): Promise<PaymentResult> {
    const gateway = options.gateway_id
      ? await this.getGateway(options.gateway_id)
      : await this.getDefaultGateway();
    const provider = this.createProvider(gateway);

    const result = await provider.void(options.transaction_id);

    await this.recordTransaction(orderId, "void", result, gateway);

    if (result.success) {
      await this.updateOrderPaymentStatus(orderId, "voided");
    }

    return result;
  }

  // ============================================================================
  // Credential Validation
  // ============================================================================

  async testGatewayCredentials(
    provider: string,
    credentials: Record<string, string>,
    testMode: boolean
  ): Promise<CredentialValidationResult> {
    const config: PaymentGatewayConfig = {
      id: "test",
      name: "Test",
      provider: provider as PaymentGatewayConfig["provider"],
      enabled: true,
      testMode,
      credentials,
    };

    const paymentProvider = this.createProvider(config);
    return paymentProvider.validateCredentials(credentials, testMode);
  }
}

export const paymentService = new PaymentServiceClass();
