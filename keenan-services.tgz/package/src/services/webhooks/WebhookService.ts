import { channels, webhooks, webhookEvents } from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation, DependencyCheck } from "../../base/types";

/**
 * Service for managing webhooks.
 */
class WebhookServiceClass extends BaseService<typeof webhooks> {
  constructor() {
    super(webhooks, {
      resourceName: "Webhook",
      defaultSort: "id",
      sortColumns: {
        id: webhooks.id,
        scope: webhooks.scope,
        created_at: webhooks.createdAt,
      },
      filterColumns: {
        scope: webhooks.scope,
        is_active: webhooks.isActive,
        channel_id: webhooks.channelId,
      },
      allowedFilters: ["scope", "is_active", "channel_id"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: channels,
        column: channels.id,
        resourceName: "Channel",
        fieldName: "channelId",
        optional: true,
      },
    ];
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: webhookEvents,
        foreignKeyColumn: webhookEvents.webhookId,
        resourceName: "webhook event",
        message: "Cannot delete webhook because it has {count} event(s) associated with it.",
      },
    ];
  }
}

export const webhookService = new WebhookServiceClass();
