import { priceLists, priceListRecords, priceListAssignments } from "../../schema";
import { BaseService } from "../../base/BaseService";
import { DependencyCheck, IncludeConfig } from "../../base/types";

/**
 * Service for managing price lists.
 */
class PriceListServiceClass extends BaseService<typeof priceLists> {
  constructor() {
    super(priceLists, {
      resourceName: "Price List",
      defaultSort: "id",
      sortColumns: {
        id: priceLists.id,
        name: priceLists.name,
        created_at: priceLists.createdAt,
      },
      filterColumns: {
        name: priceLists.name,
        currency_code: priceLists.currencyCode,
        is_active: priceLists.isActive,
      },
      allowedFilters: ["name", "currency_code", "is_active"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: priceListRecords,
        foreignKeyColumn: priceListRecords.priceListId,
        resourceName: "price list record",
        message:
          "Cannot delete price list because it has {count} price record(s). Delete the records first.",
      },
      {
        table: priceListAssignments,
        foreignKeyColumn: priceListAssignments.priceListId,
        resourceName: "price list assignment",
        message:
          "Cannot delete price list because it has {count} assignment(s). Remove assignments first.",
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "records",
        table: priceListRecords,
        foreignKey: priceListRecords.priceListId,
      },
    ];
  }
}

export const priceListService = new PriceListServiceClass();
