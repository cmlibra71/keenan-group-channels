CREATE TABLE "order_freight_flags" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"order_id" integer NOT NULL,
	"code" varchar(50) NOT NULL,
	"tier" varchar(20) NOT NULL,
	"note" text,
	"resolved_at" timestamp with time zone,
	"resolved_by" integer,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "order_freight_flags_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "order_freight_quotes" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"order_id" integer NOT NULL,
	"run_id" uuid NOT NULL,
	"carrier_code" varchar(50) NOT NULL,
	"lane" varchar(20) NOT NULL,
	"service_name" varchar(100),
	"price_ex_tax" numeric(19, 4),
	"price_inc_tax" numeric(19, 4),
	"eta_business_days" integer,
	"tailgate_applied" boolean DEFAULT false,
	"tailgate_surcharge" numeric(19, 4),
	"insurance_included" boolean DEFAULT false,
	"insurance_amount" numeric(19, 4),
	"status" varchar(20) DEFAULT 'quoted' NOT NULL,
	"error_message" text,
	"raw_response" jsonb,
	"selected_at" timestamp with time zone,
	"selected_by" integer,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "order_freight_quotes_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "site_access_profiles" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"account_id" integer,
	"address_hash" varchar(64) NOT NULL,
	"address1" varchar(255) NOT NULL,
	"address2" varchar(255),
	"city" varchar(100) NOT NULL,
	"state" varchar(100),
	"postal_code" varchar(20),
	"country_code" char(2) DEFAULT 'AU' NOT NULL,
	"delivery_type" varchar(50),
	"truck_access_ok" boolean,
	"narrowest_width_mm" integer,
	"narrowest_height_mm" integer,
	"delivery_window_start" varchar(5),
	"delivery_window_end" varchar(5),
	"power_hookup" boolean DEFAULT false,
	"water_hookup" boolean DEFAULT false,
	"waste_hookup" boolean DEFAULT false,
	"qu_pf_reference" varchar(50),
	"comments" text,
	"forklift_at_delivery" boolean DEFAULT false,
	"loading_dock_available" boolean DEFAULT false,
	"two_person_delivery_required" boolean DEFAULT false,
	"uncrated" boolean DEFAULT false,
	"source" varchar(20) DEFAULT 'manual' NOT NULL,
	"monday_item_id" varchar(50),
	"last_verified_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "site_access_profiles_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "site_access_profile_account_address" UNIQUE("account_id","address_hash")
);
--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "customer_po" varchar(100);--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "site_contact_name" varchar(200);--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "site_contact_phone" varchar(50);--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "required_delivery_date" date;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "order_source" varchar(50);--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "internal_memo" text;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "delivery_notes" text;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "site_access_profile_id" integer;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "selected_freight_quote_id" integer;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "declared_value" numeric(19, 4);--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "total_weight_kg" numeric(10, 3);--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "pickup_only" boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE "order_freight_flags" ADD CONSTRAINT "order_freight_flags_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_freight_flags" ADD CONSTRAINT "order_freight_flags_resolved_by_admin_users_id_fk" FOREIGN KEY ("resolved_by") REFERENCES "public"."admin_users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_freight_quotes" ADD CONSTRAINT "order_freight_quotes_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_freight_quotes" ADD CONSTRAINT "order_freight_quotes_selected_by_admin_users_id_fk" FOREIGN KEY ("selected_by") REFERENCES "public"."admin_users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "site_access_profiles" ADD CONSTRAINT "site_access_profiles_account_id_accounts_id_fk" FOREIGN KEY ("account_id") REFERENCES "public"."accounts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_order_freight_flags_order" ON "order_freight_flags" USING btree ("order_id");--> statement-breakpoint
CREATE INDEX "idx_order_freight_flags_open" ON "order_freight_flags" USING btree ("order_id","resolved_at");--> statement-breakpoint
CREATE INDEX "idx_order_freight_flags_code" ON "order_freight_flags" USING btree ("code");--> statement-breakpoint
CREATE INDEX "idx_order_freight_quotes_order" ON "order_freight_quotes" USING btree ("order_id");--> statement-breakpoint
CREATE INDEX "idx_order_freight_quotes_run" ON "order_freight_quotes" USING btree ("run_id");--> statement-breakpoint
CREATE INDEX "idx_order_freight_quotes_order_run" ON "order_freight_quotes" USING btree ("order_id","run_id");--> statement-breakpoint
CREATE INDEX "idx_site_access_profiles_account" ON "site_access_profiles" USING btree ("account_id");--> statement-breakpoint
CREATE INDEX "idx_site_access_profiles_hash" ON "site_access_profiles" USING btree ("address_hash");--> statement-breakpoint
CREATE INDEX "idx_orders_site_access_profile" ON "orders" USING btree ("site_access_profile_id");--> statement-breakpoint
CREATE INDEX "idx_orders_selected_freight_quote" ON "orders" USING btree ("selected_freight_quote_id");