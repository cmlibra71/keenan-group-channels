import { eq, and, or, isNull, desc } from "drizzle-orm";
import {
  priceListAssignments,
  priceListRecords,
  priceLists,
  productVariants,
} from "../../schema";
import { getCommerceDb } from "../../db";

export interface EffectivePrice {
  /** The standard price for this variant */
  price: string | null;
  /** Sale price if applicable */
  salePrice: string | null;
  /** Member-specific price (from customer group price list) */
  memberPrice: string | null;
  /** Whether the customer is a member */
  isMember: boolean;
}

/**
 * Get the effective price for a variant, considering channel and customer group
 * price list assignments. Returns member pricing info when applicable.
 */
export async function getEffectivePrice(
  variantId: number,
  channelId: number,
  customerGroupId?: number | null
): Promise<EffectivePrice> {
  const db = getCommerceDb();

  // Get base variant price
  const [variant] = await db
    .select({
      price: productVariants.price,
      salePrice: productVariants.salePrice,
    })
    .from(productVariants)
    .where(eq(productVariants.id, variantId))
    .limit(1);

  const result: EffectivePrice = {
    price: variant?.price ?? null,
    salePrice: variant?.salePrice ?? null,
    memberPrice: null,
    isMember: !!customerGroupId,
  };

  if (!variant) return result;

  // Find applicable price list assignments for this channel,
  // ordered by priority (higher priority = applied first)
  const assignments = await db
    .select({
      priceListId: priceListAssignments.priceListId,
      customerGroupId: priceListAssignments.customerGroupId,
      priority: priceListAssignments.priority,
    })
    .from(priceListAssignments)
    .innerJoin(priceLists, eq(priceListAssignments.priceListId, priceLists.id))
    .where(
      and(
        eq(priceListAssignments.channelId, channelId),
        eq(priceLists.isActive, true),
        or(
          isNull(priceListAssignments.customerGroupId),
          customerGroupId
            ? eq(priceListAssignments.customerGroupId, customerGroupId)
            : isNull(priceListAssignments.customerGroupId)
        )
      )
    )
    .orderBy(desc(priceListAssignments.priority));

  if (assignments.length === 0) return result;

  // For each assignment, check if there's a price record for this variant
  for (const assignment of assignments) {
    const [record] = await db
      .select({
        price: priceListRecords.price,
        salePrice: priceListRecords.salePrice,
      })
      .from(priceListRecords)
      .where(
        and(
          eq(priceListRecords.priceListId, assignment.priceListId),
          eq(priceListRecords.variantId, variantId)
        )
      )
      .limit(1);

    if (record) {
      if (assignment.customerGroupId && customerGroupId === assignment.customerGroupId) {
        // This is a member-specific price list
        result.memberPrice = record.salePrice ?? record.price ?? null;
      } else if (!assignment.customerGroupId) {
        // Channel-wide price list (applies to all)
        if (record.price) result.price = record.price;
        if (record.salePrice) result.salePrice = record.salePrice;
      }
    }
  }

  return result;
}
