// Database
export { initCommerceDb, getCommerceDb, getCommerceClient, closeCommerceDb } from "./db";

// Schema
export * from "./schema";

// Errors
export * from "./errors";

// Transforms
export * from "./transforms";

// Base classes
export * from "./base";

// All services
export * from "./services";

// Payments (re-export selectively to avoid PaymentStatus name conflict with schema)
export {
  paymentService,
  ManualProvider,
  StripeProvider,
  PayPalProvider,
  SquareProvider,
  StripeSubscriptionProvider,
  handleStripeSubscriptionWebhook,
} from "./payments";
export type {
  PaymentProvider,
  PaymentResult,
  PaymentDetails,
  PaymentGatewayConfig,
  CredentialValidationResult,
  PaymentStatus as PaymentGatewayStatus,
} from "./payments";

// Search
export * from "./search";
