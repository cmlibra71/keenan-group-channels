import { products, customers, contacts, orders, productReviews } from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation } from "../../base/types";

/**
 * Service for managing product reviews.
 */
class ReviewServiceClass extends BaseService<typeof productReviews> {
  constructor() {
    super(productReviews, {
      resourceName: "Review",
      defaultSort: "id",
      sortColumns: {
        id: productReviews.id,
        rating: productReviews.rating,
        created_at: productReviews.createdAt,
        updated_at: productReviews.updatedAt,
      },
      filterColumns: {
        product_id: productReviews.productId,
        customer_id: productReviews.customerId,
        contact_id: productReviews.contactId,
        status: productReviews.status,
        rating: productReviews.rating,
      },
      allowedFilters: ["product_id", "customer_id", "contact_id", "status", "rating"],
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: products,
        column: products.id,
        resourceName: "Product",
        fieldName: "productId",
      },
      {
        table: customers,
        column: customers.id,
        resourceName: "Customer",
        fieldName: "customerId",
        optional: true,
      },
      {
        table: orders,
        column: orders.id,
        resourceName: "Order",
        fieldName: "orderId",
        optional: true,
      },
      {
        table: contacts,
        column: contacts.id,
        resourceName: "Contact",
        fieldName: "contactId",
        optional: true,
      },
    ];
  }
}

export const reviewService = new ReviewServiceClass();
