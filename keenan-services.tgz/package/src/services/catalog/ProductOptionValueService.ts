import { PgColumn } from "drizzle-orm/pg-core";
import { productOptions, productOptionValues } from "../../schema";
import { NestedService } from "../../base/NestedService";

/**
 * Service for managing product option values.
 */
class ProductOptionValueServiceClass extends NestedService<typeof productOptions, typeof productOptionValues> {
  constructor() {
    super(productOptions, productOptionValues, {
      resourceName: "Option Value",
      parentResourceName: "Option",
      defaultSort: "id",
      sortColumns: {
        id: productOptionValues.id,
        sort_order: productOptionValues.sortOrder,
      },
      filterColumns: {
        label: productOptionValues.label,
      },
      allowedFilters: ["label"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return productOptions.id;
  }

  protected getParentForeignKey(): PgColumn {
    return productOptionValues.optionId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "optionId";
  }
}

export const productOptionValueService = new ProductOptionValueServiceClass();
