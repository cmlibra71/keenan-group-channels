import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";

const sesClient = new SESClient({
  region: process.env.AWS_SES_REGION || "ap-southeast-2",
});

const FROM_EMAIL = process.env.AWS_SES_FROM_EMAIL || "noreply@keenan-group.com.au";
const LOGO_URL = "https://keenan-group.com.au/logo/keenan_group_logo_dark.png";
const SITE_URL = "https://keenan-group.com.au";

function brandedButton(text: string, href: string): string {
  return `<a href="${href}" style="display: inline-block; background-color: #C73629; color: #ffffff; text-decoration: none; padding: 14px 36px; border-radius: 6px; font-weight: 600; font-size: 16px; mso-padding-alt: 0; text-underline-color: #C73629;">
    <!--[if mso]><i style="mso-font-width: -100%; mso-text-raise: 21pt;">&nbsp;</i><![endif]-->
    <span style="mso-text-raise: 10pt;">${text}</span>
    <!--[if mso]><i style="mso-font-width: -100%;">&nbsp;</i><![endif]-->
  </a>`;
}

function brandedEmailLayout(title: string, content: string, footerText?: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>${title}</title>
  <!--[if mso]>
  <noscript>
    <xml>
      <o:OfficeDocumentSettings>
        <o:PixelsPerInch>96</o:PixelsPerInch>
      </o:OfficeDocumentSettings>
    </xml>
  </noscript>
  <![endif]-->
</head>
<body style="margin: 0; padding: 0; background-color: #f4f4f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; -webkit-font-smoothing: antialiased;">
  <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background-color: #f4f4f5;">
    <tr>
      <td align="center" style="padding: 24px 16px;">
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="600" style="max-width: 600px; width: 100%;">

          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border-radius: 12px 12px 0 0; padding: 32px 40px; text-align: center;">
              <!--[if mso]>
              <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:600px;height:90px;">
                <v:fill type="gradient" color="#1e293b" color2="#0f172a" angle="135"/>
                <v:textbox inset="0,0,0,0">
              <![endif]-->
              <a href="${SITE_URL}" target="_blank" style="text-decoration: none;">
                <img src="${LOGO_URL}" alt="Keenan Group" width="220" style="display: block; margin: 0 auto; max-width: 220px; height: auto;" />
              </a>
              <!--[if mso]>
                </v:textbox>
              </v:rect>
              <![endif]-->
            </td>
          </tr>

          <!-- Content Card -->
          <tr>
            <td style="background-color: #ffffff; padding: 40px; border-left: 1px solid #e4e4e7; border-right: 1px solid #e4e4e7;">
              ${content}
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background-color: #fafafa; border-radius: 0 0 12px 12px; padding: 24px 40px; text-align: center; border-left: 1px solid #e4e4e7; border-right: 1px solid #e4e4e7; border-bottom: 1px solid #e4e4e7;">
              <p style="margin: 0 0 4px 0; color: #64748b; font-size: 13px; line-height: 1.5;">
                ${footerText || "Keenan Group &mdash; Commercial Kitchen Equipment Specialists"}
              </p>
              <p style="margin: 0; color: #94a3b8; font-size: 12px;">
                <a href="${SITE_URL}" style="color: #94a3b8; text-decoration: underline;">keenan-group.com.au</a>
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

interface SendInvitationEmailParams {
  to: string;
  orgName: string;
  inviterName?: string;
  signUpUrl: string;
}

export async function sendInvitationEmail({
  to,
  orgName,
  inviterName,
  signUpUrl,
}: SendInvitationEmailParams): Promise<boolean> {
  const subject = `You've been invited to join ${orgName} on Keenan Group Portal`;

  const content = `
    <h1 style="margin: 0 0 8px 0; color: #1e293b; font-size: 24px; font-weight: 700; text-align: center;">
      You're Invited!
    </h1>
    <p style="margin: 0 0 24px 0; color: #64748b; font-size: 15px; text-align: center; line-height: 1.6;">
      ${inviterName ? `<strong>${inviterName}</strong> has invited you` : "You've been invited"} to join <strong style="color: #1e293b;">${orgName}</strong> on the Keenan Group Portal.
    </p>
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
      <tr>
        <td align="center" style="padding: 8px 0 24px 0;">
          ${brandedButton("Accept Invitation", signUpUrl)}
        </td>
      </tr>
    </table>
    <p style="margin: 0; color: #94a3b8; font-size: 13px; text-align: center;">
      This invitation will expire in 7 days.
    </p>
  `;

  const htmlBody = brandedEmailLayout("You're Invited!", content);

  const textBody = `You're Invited!

${inviterName ? `${inviterName} has invited you` : "You've been invited"} to join ${orgName} on the Keenan Group Portal.

Accept your invitation by visiting:
${signUpUrl}

This invitation will expire in 7 days.

Keenan Group - Commercial Kitchen Equipment Specialists`;

  try {
    const command = new SendEmailCommand({
      Source: FROM_EMAIL,
      Destination: {
        ToAddresses: [to],
      },
      Message: {
        Subject: {
          Data: subject,
          Charset: "UTF-8",
        },
        Body: {
          Html: {
            Data: htmlBody,
            Charset: "UTF-8",
          },
          Text: {
            Data: textBody,
            Charset: "UTF-8",
          },
        },
      },
    });

    await sesClient.send(command);
    console.log(`Invitation email sent to ${to}`);
    return true;
  } catch (error) {
    console.error("Failed to send invitation email:", error);
    return false;
  }
}

interface SendAddedToOrgEmailParams {
  to: string;
  orgName: string;
  role: string;
  dashboardUrl: string;
  inviterName?: string;
}

export async function sendAddedToOrgEmail({
  to,
  orgName,
  role,
  dashboardUrl,
  inviterName,
}: SendAddedToOrgEmailParams): Promise<boolean> {
  const subject = `You've been added to ${orgName} on Keenan Group Portal`;

  const roleDisplay = {
    super_admin: "Super Admin",
    org_admin: "Admin",
    org_member: "Member",
    org_viewer: "Viewer",
  }[role] || role;

  const content = `
    <h1 style="margin: 0 0 8px 0; color: #1e293b; font-size: 24px; font-weight: 700; text-align: center;">
      You've Been Added!
    </h1>
    <p style="margin: 0 0 24px 0; color: #64748b; font-size: 15px; text-align: center; line-height: 1.6;">
      ${inviterName ? `<strong>${inviterName}</strong> has added you` : "You've been added"} to <strong style="color: #1e293b;">${orgName}</strong> as a <strong style="color: #1e293b;">${roleDisplay}</strong>.
    </p>
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
      <tr>
        <td align="center" style="padding: 8px 0;">
          ${brandedButton("Go to Dashboard", dashboardUrl)}
        </td>
      </tr>
    </table>
  `;

  const htmlBody = brandedEmailLayout("You've Been Added!", content);

  const textBody = `You've Been Added!

${inviterName ? `${inviterName} has added you` : "You've been added"} to ${orgName} as a ${roleDisplay}.

Go to your dashboard:
${dashboardUrl}

Keenan Group - Commercial Kitchen Equipment Specialists`;

  try {
    const command = new SendEmailCommand({
      Source: FROM_EMAIL,
      Destination: {
        ToAddresses: [to],
      },
      Message: {
        Subject: {
          Data: subject,
          Charset: "UTF-8",
        },
        Body: {
          Html: {
            Data: htmlBody,
            Charset: "UTF-8",
          },
          Text: {
            Data: textBody,
            Charset: "UTF-8",
          },
        },
      },
    });

    await sesClient.send(command);
    console.log(`Added-to-org email sent to ${to}`);
    return true;
  } catch (error) {
    console.error("Failed to send added-to-org email:", error);
    return false;
  }
}

// --- Membership Subscription Emails ---

interface MembershipWelcomeEmailParams {
  to: string;
  memberName: string;
  planName: string;
  siteUrl: string;
}

export async function sendMembershipWelcomeEmail({
  to,
  memberName,
  planName,
  siteUrl,
}: MembershipWelcomeEmailParams): Promise<boolean> {
  const subject = `Welcome to ${planName}!`;

  const content = `
    <h1 style="margin: 0 0 8px 0; color: #1e293b; font-size: 24px; font-weight: 700; text-align: center;">
      Welcome, ${memberName}!
    </h1>
    <p style="margin: 0 0 24px 0; color: #64748b; font-size: 15px; text-align: center; line-height: 1.6;">
      Congratulations! Your <strong style="color: #1e293b;">${planName}</strong> membership is now active.
    </p>
    <p style="margin: 0 0 8px 0; color: #1e293b; font-size: 15px; font-weight: 600;">
      Your membership benefits:
    </p>
    <ul style="margin: 0 0 24px 0; padding-left: 20px; color: #64748b; font-size: 15px; line-height: 2;">
      <li>Exclusive member pricing on all products</li>
      <li>Automatic entries into member prize draws</li>
      <li>Partner discounts and offers</li>
      <li>Free delivery on orders over $500</li>
    </ul>
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
      <tr>
        <td align="center" style="padding: 8px 0;">
          ${brandedButton("Start Shopping", siteUrl)}
        </td>
      </tr>
    </table>
  `;

  const htmlBody = brandedEmailLayout(`Welcome to ${planName}!`, content);

  const textBody = `Welcome, ${memberName}!

Congratulations! Your ${planName} membership is now active.

Your membership benefits:
- Exclusive member pricing on all products
- Automatic entries into member prize draws
- Partner discounts and offers
- Free delivery on orders over $500

Start shopping: ${siteUrl}

Keenan Group - Commercial Kitchen Equipment Specialists`;

  try {
    const command = new SendEmailCommand({
      Source: FROM_EMAIL,
      Destination: {
        ToAddresses: [to],
      },
      Message: {
        Subject: {
          Data: subject,
          Charset: "UTF-8",
        },
        Body: {
          Html: {
            Data: htmlBody,
            Charset: "UTF-8",
          },
          Text: {
            Data: textBody,
            Charset: "UTF-8",
          },
        },
      },
    });

    await sesClient.send(command);
    console.log(`Membership welcome email sent to ${to}`);
    return true;
  } catch (error) {
    console.error("Failed to send membership welcome email:", error);
    return false;
  }
}

interface PaymentReceiptEmailParams {
  to: string;
  memberName: string;
  planName: string;
  amount: string;
  currency: string;
  periodEnd: string;
  siteUrl: string;
}

export async function sendPaymentReceiptEmail({
  to,
  memberName,
  planName,
  amount,
  currency,
  periodEnd,
  siteUrl,
}: PaymentReceiptEmailParams): Promise<boolean> {
  const subject = `Payment confirmed — ${planName}`;

  const content = `
    <h1 style="margin: 0 0 8px 0; color: #1e293b; font-size: 24px; font-weight: 700; text-align: center;">
      Payment Confirmed
    </h1>
    <p style="margin: 0 0 24px 0; color: #64748b; font-size: 15px; text-align: center; line-height: 1.6;">
      Hi ${memberName}, your payment for <strong style="color: #1e293b;">${planName}</strong> has been received.
    </p>
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom: 24px;">
      <tr>
        <td style="padding: 16px 20px; background-color: #f8fafc; border-radius: 8px; border: 1px solid #e4e4e7;">
          <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
            <tr>
              <td style="color: #64748b; font-size: 14px; padding-bottom: 8px;">Amount paid</td>
              <td style="color: #1e293b; font-size: 14px; font-weight: 600; text-align: right; padding-bottom: 8px;">${currency} ${amount}</td>
            </tr>
            <tr>
              <td style="color: #64748b; font-size: 14px;">Next billing date</td>
              <td style="color: #1e293b; font-size: 14px; font-weight: 600; text-align: right;">${periodEnd}</td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
      <tr>
        <td align="center" style="padding: 8px 0;">
          ${brandedButton("Manage Membership", `${siteUrl}/account/membership`)}
        </td>
      </tr>
    </table>
  `;

  const htmlBody = brandedEmailLayout("Payment Confirmed", content);

  const textBody = `Payment Confirmed

Hi ${memberName}, your payment for ${planName} has been received.

Amount paid: ${currency} ${amount}
Next billing date: ${periodEnd}

Manage your membership: ${siteUrl}/account/membership

Keenan Group - Commercial Kitchen Equipment Specialists`;

  try {
    const command = new SendEmailCommand({
      Source: FROM_EMAIL,
      Destination: {
        ToAddresses: [to],
      },
      Message: {
        Subject: {
          Data: subject,
          Charset: "UTF-8",
        },
        Body: {
          Html: {
            Data: htmlBody,
            Charset: "UTF-8",
          },
          Text: {
            Data: textBody,
            Charset: "UTF-8",
          },
        },
      },
    });

    await sesClient.send(command);
    console.log(`Payment receipt email sent to ${to}`);
    return true;
  } catch (error) {
    console.error("Failed to send payment receipt email:", error);
    return false;
  }
}

interface PaymentFailedEmailParams {
  to: string;
  memberName: string;
  planName: string;
  siteUrl: string;
}

export async function sendPaymentFailedEmail({
  to,
  memberName,
  planName,
  siteUrl,
}: PaymentFailedEmailParams): Promise<boolean> {
  const subject = `Action needed — payment failed for ${planName}`;

  const content = `
    <h1 style="margin: 0 0 8px 0; color: #1e293b; font-size: 24px; font-weight: 700; text-align: center;">
      Payment Failed
    </h1>
    <p style="margin: 0 0 16px 0; color: #64748b; font-size: 15px; text-align: center; line-height: 1.6;">
      Hi ${memberName}, we were unable to process your payment for <strong style="color: #1e293b;">${planName}</strong>.
    </p>
    <p style="margin: 0 0 24px 0; color: #64748b; font-size: 15px; text-align: center; line-height: 1.6;">
      Stripe will automatically retry the payment, but to avoid any interruption to your membership benefits, please update your payment method.
    </p>
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
      <tr>
        <td align="center" style="padding: 8px 0;">
          ${brandedButton("Update Payment Method", `${siteUrl}/account/membership`)}
        </td>
      </tr>
    </table>
  `;

  const htmlBody = brandedEmailLayout("Payment Failed", content);

  const textBody = `Payment Failed

Hi ${memberName}, we were unable to process your payment for ${planName}.

Stripe will automatically retry the payment, but to avoid any interruption to your membership benefits, please update your payment method.

Update your payment method: ${siteUrl}/account/membership

Keenan Group - Commercial Kitchen Equipment Specialists`;

  try {
    const command = new SendEmailCommand({
      Source: FROM_EMAIL,
      Destination: {
        ToAddresses: [to],
      },
      Message: {
        Subject: {
          Data: subject,
          Charset: "UTF-8",
        },
        Body: {
          Html: {
            Data: htmlBody,
            Charset: "UTF-8",
          },
          Text: {
            Data: textBody,
            Charset: "UTF-8",
          },
        },
      },
    });

    await sesClient.send(command);
    console.log(`Payment failed email sent to ${to}`);
    return true;
  } catch (error) {
    console.error("Failed to send payment failed email:", error);
    return false;
  }
}

interface CancellationConfirmEmailParams {
  to: string;
  memberName: string;
  planName: string;
  periodEnd: string;
  siteUrl: string;
}

export async function sendCancellationConfirmEmail({
  to,
  memberName,
  planName,
  periodEnd,
  siteUrl,
}: CancellationConfirmEmailParams): Promise<boolean> {
  const subject = `Your ${planName} membership has been cancelled`;

  const content = `
    <h1 style="margin: 0 0 8px 0; color: #1e293b; font-size: 24px; font-weight: 700; text-align: center;">
      Membership Cancelled
    </h1>
    <p style="margin: 0 0 16px 0; color: #64748b; font-size: 15px; text-align: center; line-height: 1.6;">
      Hi ${memberName}, your <strong style="color: #1e293b;">${planName}</strong> membership has been cancelled.
    </p>
    <p style="margin: 0 0 24px 0; color: #64748b; font-size: 15px; text-align: center; line-height: 1.6;">
      You will continue to enjoy your membership benefits until <strong style="color: #1e293b;">${periodEnd}</strong>.
    </p>
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
      <tr>
        <td align="center" style="padding: 8px 0;">
          ${brandedButton("Rejoin", `${siteUrl}/membership`)}
        </td>
      </tr>
    </table>
  `;

  const htmlBody = brandedEmailLayout("Membership Cancelled", content);

  const textBody = `Membership Cancelled

Hi ${memberName}, your ${planName} membership has been cancelled.

You will continue to enjoy your membership benefits until ${periodEnd}.

Rejoin: ${siteUrl}/membership

Keenan Group - Commercial Kitchen Equipment Specialists`;

  try {
    const command = new SendEmailCommand({
      Source: FROM_EMAIL,
      Destination: {
        ToAddresses: [to],
      },
      Message: {
        Subject: {
          Data: subject,
          Charset: "UTF-8",
        },
        Body: {
          Html: {
            Data: htmlBody,
            Charset: "UTF-8",
          },
          Text: {
            Data: textBody,
            Charset: "UTF-8",
          },
        },
      },
    });

    await sesClient.send(command);
    console.log(`Cancellation confirmation email sent to ${to}`);
    return true;
  } catch (error) {
    console.error("Failed to send cancellation confirmation email:", error);
    return false;
  }
}

interface DrawWinnerEmailParams {
  to: string;
  memberName: string;
  drawName: string;
  prizeName: string;
  claimUrl: string;
}

export async function sendDrawWinnerEmail({
  to,
  memberName,
  drawName,
  prizeName,
  claimUrl,
}: DrawWinnerEmailParams): Promise<boolean> {
  const subject = `You won the ${drawName}!`;

  const content = `
    <h1 style="margin: 0 0 8px 0; color: #1e293b; font-size: 24px; font-weight: 700; text-align: center;">
      Congratulations, ${memberName}!
    </h1>
    <p style="margin: 0 0 24px 0; color: #64748b; font-size: 15px; text-align: center; line-height: 1.6;">
      You've won the <strong style="color: #1e293b;">${drawName}</strong>!
    </p>
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom: 24px;">
      <tr>
        <td style="padding: 16px 20px; background-color: #f8fafc; border-radius: 8px; border: 1px solid #e4e4e7; text-align: center;">
          <p style="margin: 0 0 4px 0; color: #64748b; font-size: 13px;">Your prize</p>
          <p style="margin: 0; color: #1e293b; font-size: 18px; font-weight: 700;">${prizeName}</p>
        </td>
      </tr>
    </table>
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
      <tr>
        <td align="center" style="padding: 8px 0 24px 0;">
          ${brandedButton("Claim Your Prize", claimUrl)}
        </td>
      </tr>
    </table>
    <p style="margin: 0; color: #94a3b8; font-size: 13px; text-align: center;">
      Please claim your prize within 14 days.
    </p>
  `;

  const htmlBody = brandedEmailLayout(`You won the ${drawName}!`, content);

  const textBody = `Congratulations, ${memberName}!

You've won the ${drawName}!

Your prize: ${prizeName}

Claim your prize: ${claimUrl}

Please claim your prize within 14 days.

Keenan Group - Commercial Kitchen Equipment Specialists`;

  try {
    const command = new SendEmailCommand({
      Source: FROM_EMAIL,
      Destination: {
        ToAddresses: [to],
      },
      Message: {
        Subject: {
          Data: subject,
          Charset: "UTF-8",
        },
        Body: {
          Html: {
            Data: htmlBody,
            Charset: "UTF-8",
          },
          Text: {
            Data: textBody,
            Charset: "UTF-8",
          },
        },
      },
    });

    await sesClient.send(command);
    console.log(`Draw winner email sent to ${to}`);
    return true;
  } catch (error) {
    console.error("Failed to send draw winner email:", error);
    return false;
  }
}

interface DrawClaimReminderEmailParams {
  to: string;
  memberName: string;
  drawName: string;
  prizeName: string;
  claimUrl: string;
  daysRemaining: number;
}

export async function sendDrawClaimReminderEmail({
  to,
  memberName,
  drawName,
  prizeName,
  claimUrl,
  daysRemaining,
}: DrawClaimReminderEmailParams): Promise<boolean> {
  const subject = `Reminder: Claim your ${drawName} prize`;

  const content = `
    <h1 style="margin: 0 0 8px 0; color: #1e293b; font-size: 24px; font-weight: 700; text-align: center;">
      Don't Forget Your Prize!
    </h1>
    <p style="margin: 0 0 16px 0; color: #64748b; font-size: 15px; text-align: center; line-height: 1.6;">
      Hi ${memberName}, you have <strong style="color: #C73629;">${daysRemaining} day${daysRemaining === 1 ? "" : "s"}</strong> remaining to claim your <strong style="color: #1e293b;">${drawName}</strong> prize.
    </p>
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-bottom: 24px;">
      <tr>
        <td style="padding: 16px 20px; background-color: #f8fafc; border-radius: 8px; border: 1px solid #e4e4e7; text-align: center;">
          <p style="margin: 0 0 4px 0; color: #64748b; font-size: 13px;">Your prize</p>
          <p style="margin: 0; color: #1e293b; font-size: 18px; font-weight: 700;">${prizeName}</p>
        </td>
      </tr>
    </table>
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
      <tr>
        <td align="center" style="padding: 8px 0;">
          ${brandedButton("Claim Now", claimUrl)}
        </td>
      </tr>
    </table>
  `;

  const htmlBody = brandedEmailLayout("Claim Your Prize", content);

  const textBody = `Don't Forget Your Prize!

Hi ${memberName}, you have ${daysRemaining} day${daysRemaining === 1 ? "" : "s"} remaining to claim your ${drawName} prize.

Your prize: ${prizeName}

Claim now: ${claimUrl}

Keenan Group - Commercial Kitchen Equipment Specialists`;

  try {
    const command = new SendEmailCommand({
      Source: FROM_EMAIL,
      Destination: {
        ToAddresses: [to],
      },
      Message: {
        Subject: {
          Data: subject,
          Charset: "UTF-8",
        },
        Body: {
          Html: {
            Data: htmlBody,
            Charset: "UTF-8",
          },
          Text: {
            Data: textBody,
            Charset: "UTF-8",
          },
        },
      },
    });

    await sesClient.send(command);
    console.log(`Draw claim reminder email sent to ${to}`);
    return true;
  } catch (error) {
    console.error("Failed to send draw claim reminder email:", error);
    return false;
  }
}
