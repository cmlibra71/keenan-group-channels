CREATE TABLE "account_addresses" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"account_id" integer NOT NULL,
	"location_id" integer,
	"label" varchar(100),
	"first_name" varchar(100),
	"last_name" varchar(100),
	"company" varchar(255),
	"address1" varchar(255) NOT NULL,
	"address2" varchar(255),
	"city" varchar(100) NOT NULL,
	"state_or_province" varchar(100),
	"state_or_province_code" varchar(10),
	"postal_code" varchar(20),
	"country" varchar(100) NOT NULL,
	"country_code" char(2),
	"phone" varchar(50),
	"address_type" varchar(20) DEFAULT 'shipping',
	"is_default_billing" boolean DEFAULT false,
	"is_default_shipping" boolean DEFAULT false,
	"form_fields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "account_addresses_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "account_locations" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"account_id" integer NOT NULL,
	"name" varchar(255) NOT NULL,
	"code" varchar(50),
	"is_default" boolean DEFAULT false,
	"is_active" boolean DEFAULT true,
	"allowed_shipping_method_ids" jsonb DEFAULT '[]'::jsonb,
	"allowed_payment_methods" jsonb DEFAULT '[]'::jsonb,
	"address1" varchar(255),
	"address2" varchar(255),
	"city" varchar(100),
	"state_or_province" varchar(100),
	"state_or_province_code" varchar(10),
	"postal_code" varchar(20),
	"country" varchar(100),
	"country_code" char(2),
	"phone" varchar(50),
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "account_locations_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "account_locations_account_code" UNIQUE("account_id","code")
);
--> statement-breakpoint
CREATE TABLE "account_roles" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(255) NOT NULL,
	"description" text,
	"permissions" jsonb DEFAULT '[]'::jsonb,
	"is_system" boolean DEFAULT false,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "account_roles_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "account_roles_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE "account_sales_rep_assignments" (
	"id" serial PRIMARY KEY NOT NULL,
	"account_id" integer NOT NULL,
	"sales_rep_id" integer NOT NULL,
	"is_primary" boolean DEFAULT false,
	"commission_rate_override" numeric(5, 2),
	"notes" text,
	"assigned_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "account_sales_rep_unique" UNIQUE("account_id","sales_rep_id")
);
--> statement-breakpoint
CREATE TABLE "accounts" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(255) NOT NULL,
	"legal_name" varchar(255),
	"tax_id" varchar(100),
	"customer_group_id" integer,
	"origin_channel_id" integer,
	"status" varchar(20) DEFAULT 'active' NOT NULL,
	"tax_exempt_category" varchar(100),
	"store_credit" numeric(19, 4) DEFAULT '0',
	"accepts_marketing" boolean DEFAULT false,
	"phone" varchar(50),
	"website" varchar(500),
	"industry" varchar(100),
	"notes" text,
	"attributes" jsonb DEFAULT '{}'::jsonb,
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"net_terms_days" integer DEFAULT 0,
	"credit_limit" numeric(19, 4),
	"current_balance" numeric(19, 4) DEFAULT '0',
	"past_due_amount" numeric(19, 4) DEFAULT '0',
	"past_due_action" varchar(30) DEFAULT 'warn',
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "accounts_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "admin_users" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"email" varchar(255) NOT NULL,
	"password_hash" varchar(255) NOT NULL,
	"first_name" varchar(100),
	"last_name" varchar(100),
	"role" varchar(50) DEFAULT 'staff' NOT NULL,
	"permissions" jsonb DEFAULT '{}'::jsonb,
	"channel_ids" integer[],
	"is_active" boolean DEFAULT true,
	"two_factor_enabled" boolean DEFAULT false,
	"two_factor_secret" varchar(255),
	"last_login_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "admin_users_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "admin_users_email_unique" UNIQUE("email")
);
--> statement-breakpoint
CREATE TABLE "approval_rules" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"account_id" integer NOT NULL,
	"name" varchar(255) NOT NULL,
	"rule_type" varchar(30) NOT NULL,
	"threshold" numeric(19, 4),
	"applies_to_roles" jsonb DEFAULT '[]'::jsonb,
	"approver_role_id" integer,
	"is_active" boolean DEFAULT true,
	"priority" integer DEFAULT 0,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "approval_rules_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "audit_log" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"admin_user_id" integer,
	"customer_id" integer,
	"account_id" integer,
	"contact_id" integer,
	"action" varchar(100) NOT NULL,
	"entity_type" varchar(100) NOT NULL,
	"entity_id" integer,
	"old_values" jsonb,
	"new_values" jsonb,
	"ip_address" "inet",
	"user_agent" text,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "brands" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(255) NOT NULL,
	"slug" varchar(255) NOT NULL,
	"page_title" varchar(255),
	"meta_description" text,
	"meta_keywords" text,
	"search_keywords" text,
	"image_url" varchar(500),
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "brands_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "brands_name_unique" UNIQUE("name"),
	CONSTRAINT "brands_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
CREATE TABLE "bulk_pricing_rules" (
	"id" serial PRIMARY KEY NOT NULL,
	"product_id" integer NOT NULL,
	"quantity_min" integer NOT NULL,
	"quantity_max" integer,
	"type" varchar(20) NOT NULL,
	"amount" numeric(19, 4) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "cart_items" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"cart_id" integer NOT NULL,
	"product_id" integer NOT NULL,
	"variant_id" integer,
	"quantity" integer DEFAULT 1 NOT NULL,
	"list_price" numeric(19, 4) NOT NULL,
	"sale_price" numeric(19, 4),
	"extended_list_price" numeric(19, 4),
	"extended_sale_price" numeric(19, 4),
	"discount_amount" numeric(19, 4) DEFAULT '0',
	"applied_coupons" jsonb DEFAULT '[]'::jsonb,
	"modifier_selections" jsonb DEFAULT '[]'::jsonb,
	"gift_wrapping_option_id" integer,
	"gift_message" text,
	"recipient_email" varchar(255),
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "cart_items_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "carts" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"channel_id" integer NOT NULL,
	"customer_id" integer,
	"account_id" integer,
	"contact_id" integer,
	"currency_code" char(3) DEFAULT 'USD' NOT NULL,
	"base_amount" numeric(19, 4) DEFAULT '0',
	"discount_amount" numeric(19, 4) DEFAULT '0',
	"tax_amount" numeric(19, 4) DEFAULT '0',
	"cart_amount" numeric(19, 4) DEFAULT '0',
	"coupon_codes" text[] DEFAULT '{}',
	"gift_certificate_codes" text[] DEFAULT '{}',
	"email" varchar(255),
	"locale" varchar(10),
	"status" varchar(20) DEFAULT 'active',
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"expires_at" timestamp with time zone,
	CONSTRAINT "carts_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "categories" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"tree_id" integer NOT NULL,
	"parent_id" integer,
	"name" varchar(255) NOT NULL,
	"slug" varchar(255) NOT NULL,
	"description" text,
	"path_ids" integer[] DEFAULT '{}',
	"path_names" text[] DEFAULT '{}',
	"depth" integer DEFAULT 0,
	"sort_order" integer DEFAULT 0,
	"is_active" boolean DEFAULT true,
	"include_in_menu" boolean DEFAULT true,
	"include_in_search" boolean DEFAULT true,
	"include_in_filters" boolean DEFAULT true,
	"include_products" varchar(10) DEFAULT 'products',
	"page_title" varchar(255),
	"meta_description" text,
	"meta_keywords" text,
	"image_url" varchar(500),
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "categories_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "categories_tree_slug" UNIQUE("tree_id","slug")
);
--> statement-breakpoint
CREATE TABLE "category_trees" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(255) NOT NULL,
	"channel_id" integer,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "category_trees_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "channel_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"channel_id" integer NOT NULL,
	"setting_key" varchar(100) NOT NULL,
	"setting_value" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "channel_settings_unique" UNIQUE("channel_id","setting_key")
);
--> statement-breakpoint
CREATE TABLE "channels" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(255) NOT NULL,
	"type" varchar(50) DEFAULT 'storefront' NOT NULL,
	"platform" varchar(100),
	"status" varchar(20) DEFAULT 'active' NOT NULL,
	"is_default" boolean DEFAULT false,
	"default_currency_code" char(3) DEFAULT 'USD',
	"default_locale" varchar(10) DEFAULT 'en-US',
	"config_meta" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "channels_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "contact_location_assignments" (
	"id" serial PRIMARY KEY NOT NULL,
	"contact_id" integer NOT NULL,
	"location_id" integer NOT NULL,
	"is_default" boolean DEFAULT false,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "contact_location_unique" UNIQUE("contact_id","location_id")
);
--> statement-breakpoint
CREATE TABLE "contacts" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"account_id" integer NOT NULL,
	"email" varchar(255) NOT NULL,
	"password_hash" varchar(255),
	"first_name" varchar(100),
	"last_name" varchar(100),
	"phone" varchar(50),
	"job_title" varchar(100),
	"role_id" integer,
	"is_primary" boolean DEFAULT false,
	"is_active" boolean DEFAULT true,
	"accepts_marketing" boolean DEFAULT false,
	"registration_ip_address" "inet",
	"last_login_at" timestamp with time zone,
	"form_fields" jsonb DEFAULT '{}'::jsonb,
	"attributes" jsonb DEFAULT '{}'::jsonb,
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "contacts_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "contacts_account_email" UNIQUE("account_id","email")
);
--> statement-breakpoint
CREATE TABLE "coupon_redemptions" (
	"id" serial PRIMARY KEY NOT NULL,
	"coupon_id" integer NOT NULL,
	"order_id" integer NOT NULL,
	"customer_id" integer,
	"contact_id" integer,
	"discount_amount" numeric(19, 4) NOT NULL,
	"redeemed_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "coupons" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"promotion_id" integer NOT NULL,
	"code" varchar(100) NOT NULL,
	"max_uses" integer,
	"max_uses_per_customer" integer,
	"current_uses" integer DEFAULT 0,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "coupons_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "coupons_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "customer_addresses" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"customer_id" integer NOT NULL,
	"first_name" varchar(100),
	"last_name" varchar(100),
	"company" varchar(255),
	"address1" varchar(255) NOT NULL,
	"address2" varchar(255),
	"city" varchar(100) NOT NULL,
	"state_or_province" varchar(100),
	"state_or_province_code" varchar(10),
	"postal_code" varchar(20),
	"country" varchar(100) NOT NULL,
	"country_code" char(2),
	"phone" varchar(50),
	"address_type" varchar(20) DEFAULT 'residential',
	"is_default_billing" boolean DEFAULT false,
	"is_default_shipping" boolean DEFAULT false,
	"form_fields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "customer_addresses_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "customer_groups" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(255) NOT NULL,
	"discount_type" varchar(20),
	"discount_amount" numeric(19, 4),
	"category_access_type" varchar(20) DEFAULT 'all',
	"is_default" boolean DEFAULT false,
	"is_group_for_guests" boolean DEFAULT false,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "customer_groups_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "customers" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"origin_channel_id" integer,
	"email" varchar(255) NOT NULL,
	"password_hash" varchar(255),
	"customer_group_id" integer,
	"first_name" varchar(100),
	"last_name" varchar(100),
	"company" varchar(255),
	"phone" varchar(50),
	"tax_exempt_category" varchar(100),
	"store_credit" numeric(19, 4) DEFAULT '0',
	"is_active" boolean DEFAULT true,
	"accepts_marketing" boolean DEFAULT false,
	"notes" text,
	"form_fields" jsonb DEFAULT '{}'::jsonb,
	"attributes" jsonb DEFAULT '{}'::jsonb,
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"registration_ip_address" "inet",
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "customers_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "customer_channel_email" UNIQUE("origin_channel_id","email")
);
--> statement-breakpoint
CREATE TABLE "gift_certificates" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"code" varchar(100) NOT NULL,
	"original_balance" numeric(19, 4) NOT NULL,
	"balance" numeric(19, 4) NOT NULL,
	"currency_code" char(3) DEFAULT 'USD' NOT NULL,
	"to_name" varchar(255),
	"to_email" varchar(255),
	"from_name" varchar(255),
	"from_email" varchar(255),
	"message" text,
	"order_id" integer,
	"customer_id" integer,
	"contact_id" integer,
	"template" varchar(100) DEFAULT 'default',
	"status" varchar(20) DEFAULT 'active' NOT NULL,
	"expiry_date" date,
	"created_at" timestamp with time zone DEFAULT now(),
	"purchased_at" timestamp with time zone,
	CONSTRAINT "gift_certificates_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "gift_certificates_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "inventory_levels" (
	"id" serial PRIMARY KEY NOT NULL,
	"variant_id" integer NOT NULL,
	"location_id" integer NOT NULL,
	"available" integer DEFAULT 0 NOT NULL,
	"reserved" integer DEFAULT 0 NOT NULL,
	"incoming" integer DEFAULT 0 NOT NULL,
	"warning_level" integer DEFAULT 0,
	"bin_location" varchar(100),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "inventory_variant_location" UNIQUE("variant_id","location_id")
);
--> statement-breakpoint
CREATE TABLE "inventory_locations" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(255) NOT NULL,
	"code" varchar(50),
	"type" varchar(50) DEFAULT 'warehouse',
	"address" jsonb,
	"is_active" boolean DEFAULT true,
	"is_shipping_enabled" boolean DEFAULT true,
	"is_pickup_enabled" boolean DEFAULT false,
	"fulfillment_priority" integer DEFAULT 0,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "inventory_locations_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "inventory_locations_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "order_items" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"order_id" integer NOT NULL,
	"product_id" integer,
	"variant_id" integer,
	"name" varchar(255) NOT NULL,
	"sku" varchar(100),
	"quantity" integer DEFAULT 1 NOT NULL,
	"quantity_shipped" integer DEFAULT 0,
	"quantity_refunded" integer DEFAULT 0,
	"base_price" numeric(19, 4) NOT NULL,
	"price_ex_tax" numeric(19, 4) NOT NULL,
	"price_inc_tax" numeric(19, 4) NOT NULL,
	"price_tax" numeric(19, 4) DEFAULT '0',
	"base_total" numeric(19, 4) NOT NULL,
	"total_ex_tax" numeric(19, 4) NOT NULL,
	"total_inc_tax" numeric(19, 4) NOT NULL,
	"total_tax" numeric(19, 4) DEFAULT '0',
	"base_cost_price" numeric(19, 4),
	"cost_price_ex_tax" numeric(19, 4),
	"cost_price_inc_tax" numeric(19, 4),
	"cost_price_tax" numeric(19, 4),
	"discount_amount" numeric(19, 4) DEFAULT '0',
	"coupon_amount" numeric(19, 4) DEFAULT '0',
	"weight" numeric(10, 4),
	"type" varchar(20) DEFAULT 'physical',
	"download_url" varchar(500),
	"download_expiry" timestamp with time zone,
	"download_count" integer DEFAULT 0,
	"download_limit" integer,
	"gift_certificate_id" integer,
	"product_options" jsonb DEFAULT '[]'::jsonb,
	"wrapping_id" integer,
	"wrapping_name" varchar(255),
	"wrapping_message" text,
	"wrapping_cost_ex_tax" numeric(19, 4),
	"wrapping_cost_inc_tax" numeric(19, 4),
	"is_refunded" boolean DEFAULT false,
	"refund_amount" numeric(19, 4) DEFAULT '0',
	"external_id" varchar(255),
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "order_items_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "order_refund_items" (
	"id" serial PRIMARY KEY NOT NULL,
	"refund_id" integer NOT NULL,
	"order_item_id" integer NOT NULL,
	"quantity" integer NOT NULL,
	"item_type" varchar(50),
	"requested_amount" numeric(19, 4),
	"reason" text
);
--> statement-breakpoint
CREATE TABLE "order_refunds" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"order_id" integer NOT NULL,
	"reason" text,
	"total_amount" numeric(19, 4) NOT NULL,
	"tax_adjustment_amount" numeric(19, 4) DEFAULT '0',
	"created_by_user_id" integer,
	"transaction_id" integer,
	"payment_method" varchar(100),
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "order_refunds_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "order_shipping_addresses" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"order_id" integer NOT NULL,
	"first_name" varchar(100),
	"last_name" varchar(100),
	"company" varchar(255),
	"address1" varchar(255) NOT NULL,
	"address2" varchar(255),
	"city" varchar(100) NOT NULL,
	"state_or_province" varchar(100),
	"state_or_province_code" varchar(10),
	"postal_code" varchar(20),
	"country" varchar(100) NOT NULL,
	"country_code" char(2),
	"phone" varchar(50),
	"email" varchar(255),
	"shipping_method" varchar(255),
	"shipping_zone_id" integer,
	"shipping_zone_name" varchar(255),
	"base_cost" numeric(19, 4),
	"cost_ex_tax" numeric(19, 4),
	"cost_inc_tax" numeric(19, 4),
	"cost_tax" numeric(19, 4),
	"base_handling_cost" numeric(19, 4),
	"handling_cost_ex_tax" numeric(19, 4),
	"handling_cost_inc_tax" numeric(19, 4),
	"handling_cost_tax" numeric(19, 4),
	"items_total" integer DEFAULT 0,
	"items_shipped" integer DEFAULT 0,
	"form_fields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "order_shipping_addresses_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "order_statuses" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"value" varchar(50) NOT NULL,
	"label" varchar(255) NOT NULL,
	"description" text,
	"color" varchar(100) DEFAULT 'bg-zinc-100 text-zinc-600' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"is_system" boolean DEFAULT false NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "order_statuses_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "order_statuses_value_unique" UNIQUE("value")
);
--> statement-breakpoint
CREATE TABLE "order_transactions" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"order_id" integer NOT NULL,
	"event" varchar(50) NOT NULL,
	"method" varchar(50),
	"amount" numeric(19, 4) NOT NULL,
	"currency_code" char(3) NOT NULL,
	"status" varchar(50) NOT NULL,
	"gateway" varchar(100),
	"gateway_transaction_id" varchar(255),
	"fraud_review" boolean DEFAULT false,
	"avs_result" jsonb,
	"cvv_result" jsonb,
	"gateway_response" jsonb,
	"reference_transaction_id" integer,
	"offline_reason" varchar(50),
	"custom_provider_field" text,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "order_transactions_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "orders" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"channel_id" integer NOT NULL,
	"account_id" integer,
	"contact_id" integer,
	"sales_rep_id" integer,
	"approval_status" varchar(20) DEFAULT 'none',
	"order_number" varchar(50),
	"status" varchar(50) DEFAULT 'pending' NOT NULL,
	"payment_status" varchar(50) DEFAULT 'pending',
	"currency_code" char(3) DEFAULT 'USD' NOT NULL,
	"currency_exchange_rate" numeric(19, 10) DEFAULT '1',
	"subtotal_ex_tax" numeric(19, 4) DEFAULT '0' NOT NULL,
	"subtotal_inc_tax" numeric(19, 4) DEFAULT '0' NOT NULL,
	"shipping_cost_ex_tax" numeric(19, 4) DEFAULT '0',
	"shipping_cost_inc_tax" numeric(19, 4) DEFAULT '0',
	"handling_cost_ex_tax" numeric(19, 4) DEFAULT '0',
	"handling_cost_inc_tax" numeric(19, 4) DEFAULT '0',
	"wrapping_cost_ex_tax" numeric(19, 4) DEFAULT '0',
	"wrapping_cost_inc_tax" numeric(19, 4) DEFAULT '0',
	"discount_amount" numeric(19, 4) DEFAULT '0',
	"coupon_discount" numeric(19, 4) DEFAULT '0',
	"gift_certificate_amount" numeric(19, 4) DEFAULT '0',
	"store_credit_amount" numeric(19, 4) DEFAULT '0',
	"total_ex_tax" numeric(19, 4) DEFAULT '0' NOT NULL,
	"total_inc_tax" numeric(19, 4) DEFAULT '0' NOT NULL,
	"total_tax" numeric(19, 4) DEFAULT '0',
	"items_total" integer DEFAULT 0,
	"items_shipped" integer DEFAULT 0,
	"refunded_amount" numeric(19, 4) DEFAULT '0',
	"billing_address" jsonb NOT NULL,
	"customer_message" text,
	"staff_notes" text,
	"external_id" varchar(255),
	"external_source" varchar(100),
	"ip_address" "inet",
	"ip_address_v6" "inet",
	"payment_method" varchar(100),
	"payment_provider_id" varchar(255),
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"shipped_at" timestamp with time zone,
	"metafields" jsonb DEFAULT '{}'::jsonb,
	CONSTRAINT "orders_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "orders_order_number_unique" UNIQUE("order_number")
);
--> statement-breakpoint
CREATE TABLE "payment_statuses" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"value" varchar(50) NOT NULL,
	"label" varchar(255) NOT NULL,
	"description" text,
	"color" varchar(100) DEFAULT 'bg-zinc-100 text-zinc-600' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"is_system" boolean DEFAULT false NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "payment_statuses_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "payment_statuses_value_unique" UNIQUE("value")
);
--> statement-breakpoint
CREATE TABLE "price_list_assignments" (
	"id" serial PRIMARY KEY NOT NULL,
	"price_list_id" integer NOT NULL,
	"channel_id" integer,
	"customer_group_id" integer,
	"priority" integer DEFAULT 0,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "price_list_assignment_unique" UNIQUE("price_list_id","channel_id","customer_group_id")
);
--> statement-breakpoint
CREATE TABLE "price_list_records" (
	"id" serial PRIMARY KEY NOT NULL,
	"price_list_id" integer NOT NULL,
	"variant_id" integer NOT NULL,
	"price" numeric(19, 4),
	"sale_price" numeric(19, 4),
	"retail_price" numeric(19, 4),
	"map_price" numeric(19, 4),
	"bulk_pricing_tiers" jsonb DEFAULT '[]'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "price_list_variant_unique" UNIQUE("price_list_id","variant_id")
);
--> statement-breakpoint
CREATE TABLE "price_lists" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(255) NOT NULL,
	"currency_code" char(3) DEFAULT 'USD' NOT NULL,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "price_lists_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "product_categories" (
	"id" serial PRIMARY KEY NOT NULL,
	"product_id" integer NOT NULL,
	"category_id" integer NOT NULL,
	"sort_order" integer DEFAULT 0,
	"is_primary" boolean DEFAULT false,
	CONSTRAINT "product_category_unique" UNIQUE("product_id","category_id")
);
--> statement-breakpoint
CREATE TABLE "product_channel_assignments" (
	"id" serial PRIMARY KEY NOT NULL,
	"product_id" integer NOT NULL,
	"channel_id" integer NOT NULL,
	"is_visible" boolean DEFAULT true,
	"is_featured" boolean,
	"assigned_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "product_channel_unique" UNIQUE("product_id","channel_id")
);
--> statement-breakpoint
CREATE TABLE "product_images" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"product_id" integer NOT NULL,
	"url_standard" varchar(500) NOT NULL,
	"url_thumbnail" varchar(500),
	"url_tiny" varchar(500),
	"url_zoom" varchar(500),
	"description" text,
	"alt_text" varchar(255),
	"is_thumbnail" boolean DEFAULT false,
	"sort_order" integer DEFAULT 0,
	"variant_id" integer,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "product_images_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "product_modifier_values" (
	"id" serial PRIMARY KEY NOT NULL,
	"modifier_id" integer NOT NULL,
	"label" varchar(255) NOT NULL,
	"price_adjuster" varchar(20),
	"price_adjuster_value" numeric(19, 4),
	"weight_adjuster" varchar(20),
	"weight_adjuster_value" numeric(10, 4),
	"sort_order" integer DEFAULT 0,
	"is_default" boolean DEFAULT false,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "product_modifiers" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"product_id" integer NOT NULL,
	"name" varchar(255) NOT NULL,
	"display_name" varchar(255) NOT NULL,
	"type" varchar(50) NOT NULL,
	"is_required" boolean DEFAULT false,
	"sort_order" integer DEFAULT 0,
	"config" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "product_modifiers_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "product_option_values" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"option_id" integer NOT NULL,
	"label" varchar(255) NOT NULL,
	"value_data" jsonb,
	"sort_order" integer DEFAULT 0,
	"is_default" boolean DEFAULT false,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "product_option_values_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "product_options" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"product_id" integer NOT NULL,
	"name" varchar(255) NOT NULL,
	"display_name" varchar(255) NOT NULL,
	"type" varchar(50) DEFAULT 'dropdown' NOT NULL,
	"sort_order" integer DEFAULT 0,
	"is_required" boolean DEFAULT true,
	"config" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "product_options_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "product_reviews" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"product_id" integer NOT NULL,
	"customer_id" integer,
	"contact_id" integer,
	"order_id" integer,
	"title" varchar(255),
	"text" text,
	"rating" integer NOT NULL,
	"author_name" varchar(255),
	"author_email" varchar(255),
	"status" varchar(20) DEFAULT 'pending' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"reviewed_at" timestamp with time zone,
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "product_reviews_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "product_variant_options" (
	"id" serial PRIMARY KEY NOT NULL,
	"variant_id" integer NOT NULL,
	"option_id" integer NOT NULL,
	"option_value_id" integer NOT NULL,
	CONSTRAINT "variant_options_unique" UNIQUE("variant_id","option_id")
);
--> statement-breakpoint
CREATE TABLE "product_variants" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"product_id" integer NOT NULL,
	"sku" varchar(100),
	"sku_id" integer,
	"price" numeric(19, 4),
	"cost_price" numeric(19, 4),
	"sale_price" numeric(19, 4),
	"retail_price" numeric(19, 4),
	"weight" numeric(10, 4),
	"width" numeric(10, 4),
	"height" numeric(10, 4),
	"depth" numeric(10, 4),
	"inventory_level" integer DEFAULT 0,
	"inventory_warning_level" integer DEFAULT 0,
	"upc" varchar(50),
	"ean" varchar(50),
	"gtin" varchar(50),
	"mpn" varchar(50),
	"bin_picking_number" varchar(50),
	"purchasing_disabled" boolean DEFAULT false,
	"purchasing_disabled_message" text,
	"image_url" varchar(500),
	"option_display_name" varchar(500),
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"sort_order" integer DEFAULT 0,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "product_variants_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "product_variants_sku_unique" UNIQUE("sku")
);
--> statement-breakpoint
CREATE TABLE "product_videos" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"product_id" integer NOT NULL,
	"title" varchar(255),
	"description" text,
	"type" varchar(50) NOT NULL,
	"video_id" varchar(100) NOT NULL,
	"sort_order" integer DEFAULT 0,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "product_videos_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "products" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(255) NOT NULL,
	"sku" varchar(100),
	"type" varchar(50) DEFAULT 'physical' NOT NULL,
	"description" text,
	"description_short" text,
	"price" numeric(19, 4) DEFAULT '0' NOT NULL,
	"cost_price" numeric(19, 4),
	"retail_price" numeric(19, 4),
	"sale_price" numeric(19, 4),
	"tax_class_id" integer,
	"is_tax_exempt" boolean DEFAULT false,
	"weight" numeric(10, 4),
	"width" numeric(10, 4),
	"height" numeric(10, 4),
	"depth" numeric(10, 4),
	"inventory_level" integer DEFAULT 0,
	"inventory_warning_level" integer DEFAULT 0,
	"inventory_tracking" varchar(20) DEFAULT 'none',
	"brand_id" integer,
	"is_visible" boolean DEFAULT true,
	"is_featured" boolean DEFAULT false,
	"availability" varchar(50) DEFAULT 'available',
	"availability_description" text,
	"preorder_release_date" date,
	"preorder_message" text,
	"condition" varchar(20) DEFAULT 'new',
	"page_title" varchar(255),
	"meta_description" text,
	"meta_keywords" text,
	"search_keywords" text,
	"url_path" varchar(500),
	"min_purchase_quantity" integer DEFAULT 1,
	"max_purchase_quantity" integer,
	"gift_wrapping_allowed" boolean DEFAULT true,
	"related_product_ids" integer[] DEFAULT '{}',
	"warranty" text,
	"custom_fields" jsonb DEFAULT '{}'::jsonb,
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	"last_imported_at" timestamp with time zone,
	"is_deleted" boolean DEFAULT false,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "products_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "products_sku_unique" UNIQUE("sku")
);
--> statement-breakpoint
CREATE TABLE "promotions" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(255) NOT NULL,
	"redemption_type" varchar(20) DEFAULT 'automatic' NOT NULL,
	"channel_ids" integer[] DEFAULT '{}',
	"customer_group_ids" integer[] DEFAULT '{}',
	"priority" integer DEFAULT 0,
	"status" varchar(20) DEFAULT 'enabled' NOT NULL,
	"start_date" timestamp with time zone,
	"end_date" timestamp with time zone,
	"max_uses" integer,
	"current_uses" integer DEFAULT 0,
	"stop" boolean DEFAULT false,
	"can_be_combined" boolean DEFAULT true,
	"rules" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "promotions_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "quote_items" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"quote_id" integer NOT NULL,
	"product_id" integer NOT NULL,
	"variant_id" integer,
	"quantity" integer DEFAULT 1 NOT NULL,
	"list_price" numeric(19, 4) NOT NULL,
	"sale_price" numeric(19, 4),
	"extended_list_price" numeric(19, 4),
	"extended_sale_price" numeric(19, 4),
	"customer_notes" text,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "quote_items_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "quotes" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"channel_id" integer NOT NULL,
	"customer_id" integer,
	"account_id" integer,
	"contact_id" integer,
	"currency_code" char(3) DEFAULT 'USD' NOT NULL,
	"base_amount" numeric(19, 4) DEFAULT '0',
	"discount_amount" numeric(19, 4) DEFAULT '0',
	"quote_amount" numeric(19, 4) DEFAULT '0',
	"customer_notes" text,
	"internal_notes" text,
	"email" varchar(255),
	"status" varchar(20) DEFAULT 'draft',
	"expires_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "quotes_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "sales_reps" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"email" varchar(255) NOT NULL,
	"first_name" varchar(100),
	"last_name" varchar(100),
	"phone" varchar(50),
	"title" varchar(100),
	"is_active" boolean DEFAULT true,
	"commission_rate" numeric(5, 2),
	"territory" varchar(255),
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "sales_reps_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "sales_reps_email_unique" UNIQUE("email")
);
--> statement-breakpoint
CREATE TABLE "shipment_items" (
	"id" serial PRIMARY KEY NOT NULL,
	"shipment_id" integer NOT NULL,
	"order_item_id" integer NOT NULL,
	"quantity" integer DEFAULT 1 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "shipments" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"order_id" integer NOT NULL,
	"order_shipping_address_id" integer,
	"tracking_number" varchar(255),
	"tracking_carrier" varchar(100),
	"tracking_url" varchar(500),
	"shipping_method" varchar(255),
	"shipping_provider" varchar(255),
	"comments" text,
	"created_at" timestamp with time zone DEFAULT now(),
	"shipped_at" timestamp with time zone,
	CONSTRAINT "shipments_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "shipping_methods" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"shipping_zone_id" integer NOT NULL,
	"name" varchar(255) NOT NULL,
	"type" varchar(50) NOT NULL,
	"display_name" varchar(255),
	"fixed_cost" numeric(19, 4),
	"rate_per_item" numeric(19, 4),
	"rate_per_weight" numeric(19, 4),
	"rate_ranges" jsonb DEFAULT '[]'::jsonb,
	"carrier" varchar(100),
	"carrier_service_code" varchar(100),
	"carrier_options" jsonb DEFAULT '{}'::jsonb,
	"handling_fee" numeric(19, 4),
	"handling_fee_type" varchar(20),
	"enabled" boolean DEFAULT true,
	"sort_order" integer DEFAULT 0,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "shipping_methods_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "shipping_zones" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(255) NOT NULL,
	"type" varchar(50) DEFAULT 'country',
	"locations" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"enabled" boolean DEFAULT true,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "shipping_zones_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "sites" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"channel_id" integer NOT NULL,
	"url" varchar(500) NOT NULL,
	"is_primary" boolean DEFAULT true,
	"ssl_enabled" boolean DEFAULT true,
	"site_name" varchar(255),
	"meta_title" varchar(255),
	"meta_description" text,
	"meta_keywords" text,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "sites_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "sites_channel_url" UNIQUE("channel_id","url")
);
--> statement-breakpoint
CREATE TABLE "store_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"setting_key" varchar(100) NOT NULL,
	"setting_value" jsonb NOT NULL,
	"description" text,
	"is_sensitive" boolean DEFAULT false,
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "store_settings_setting_key_unique" UNIQUE("setting_key")
);
--> statement-breakpoint
CREATE TABLE "tax_classes" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(255) NOT NULL,
	"is_default" boolean DEFAULT false,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "tax_classes_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "tax_rates" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"tax_class_id" integer NOT NULL,
	"name" varchar(255) NOT NULL,
	"country_code" char(2),
	"state_code" varchar(10),
	"postal_codes" text[],
	"rate" numeric(8, 4) NOT NULL,
	"priority" integer DEFAULT 0,
	"is_compound" boolean DEFAULT false,
	"enabled" boolean DEFAULT true,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "tax_rates_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "webhook_events" (
	"id" serial PRIMARY KEY NOT NULL,
	"webhook_id" integer NOT NULL,
	"scope" varchar(100) NOT NULL,
	"payload" jsonb NOT NULL,
	"response_code" integer,
	"response_body" text,
	"status" varchar(20) DEFAULT 'pending' NOT NULL,
	"attempts" integer DEFAULT 0,
	"max_attempts" integer DEFAULT 5,
	"created_at" timestamp with time zone DEFAULT now(),
	"sent_at" timestamp with time zone,
	"next_retry_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "webhooks" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"scope" varchar(100) NOT NULL,
	"destination_url" varchar(500) NOT NULL,
	"is_active" boolean DEFAULT true,
	"headers" jsonb DEFAULT '{}'::jsonb,
	"channel_id" integer,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "webhooks_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "wishlist_items" (
	"id" serial PRIMARY KEY NOT NULL,
	"wishlist_id" integer NOT NULL,
	"product_id" integer NOT NULL,
	"variant_id" integer,
	"quantity" integer DEFAULT 1,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "wishlist_item_unique" UNIQUE("wishlist_id","product_id","variant_id")
);
--> statement-breakpoint
CREATE TABLE "wishlists" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"customer_id" integer NOT NULL,
	"contact_id" integer,
	"name" varchar(255) DEFAULT 'My Wishlist' NOT NULL,
	"is_public" boolean DEFAULT false,
	"share_token" varchar(100),
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "wishlists_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "wishlists_share_token_unique" UNIQUE("share_token")
);
--> statement-breakpoint
ALTER TABLE "account_addresses" ADD CONSTRAINT "account_addresses_account_id_accounts_id_fk" FOREIGN KEY ("account_id") REFERENCES "public"."accounts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "account_addresses" ADD CONSTRAINT "account_addresses_location_id_account_locations_id_fk" FOREIGN KEY ("location_id") REFERENCES "public"."account_locations"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "account_locations" ADD CONSTRAINT "account_locations_account_id_accounts_id_fk" FOREIGN KEY ("account_id") REFERENCES "public"."accounts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "account_sales_rep_assignments" ADD CONSTRAINT "account_sales_rep_assignments_account_id_accounts_id_fk" FOREIGN KEY ("account_id") REFERENCES "public"."accounts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "account_sales_rep_assignments" ADD CONSTRAINT "account_sales_rep_assignments_sales_rep_id_sales_reps_id_fk" FOREIGN KEY ("sales_rep_id") REFERENCES "public"."sales_reps"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "accounts" ADD CONSTRAINT "accounts_customer_group_id_customer_groups_id_fk" FOREIGN KEY ("customer_group_id") REFERENCES "public"."customer_groups"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "accounts" ADD CONSTRAINT "accounts_origin_channel_id_channels_id_fk" FOREIGN KEY ("origin_channel_id") REFERENCES "public"."channels"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "approval_rules" ADD CONSTRAINT "approval_rules_account_id_accounts_id_fk" FOREIGN KEY ("account_id") REFERENCES "public"."accounts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "approval_rules" ADD CONSTRAINT "approval_rules_approver_role_id_account_roles_id_fk" FOREIGN KEY ("approver_role_id") REFERENCES "public"."account_roles"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "audit_log" ADD CONSTRAINT "audit_log_admin_user_id_admin_users_id_fk" FOREIGN KEY ("admin_user_id") REFERENCES "public"."admin_users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "audit_log" ADD CONSTRAINT "audit_log_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "audit_log" ADD CONSTRAINT "audit_log_account_id_accounts_id_fk" FOREIGN KEY ("account_id") REFERENCES "public"."accounts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "audit_log" ADD CONSTRAINT "audit_log_contact_id_contacts_id_fk" FOREIGN KEY ("contact_id") REFERENCES "public"."contacts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bulk_pricing_rules" ADD CONSTRAINT "bulk_pricing_rules_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "cart_items" ADD CONSTRAINT "cart_items_cart_id_carts_id_fk" FOREIGN KEY ("cart_id") REFERENCES "public"."carts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "cart_items" ADD CONSTRAINT "cart_items_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "cart_items" ADD CONSTRAINT "cart_items_variant_id_product_variants_id_fk" FOREIGN KEY ("variant_id") REFERENCES "public"."product_variants"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "carts" ADD CONSTRAINT "carts_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "carts" ADD CONSTRAINT "carts_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "carts" ADD CONSTRAINT "carts_account_id_accounts_id_fk" FOREIGN KEY ("account_id") REFERENCES "public"."accounts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "carts" ADD CONSTRAINT "carts_contact_id_contacts_id_fk" FOREIGN KEY ("contact_id") REFERENCES "public"."contacts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "categories" ADD CONSTRAINT "categories_tree_id_category_trees_id_fk" FOREIGN KEY ("tree_id") REFERENCES "public"."category_trees"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "category_trees" ADD CONSTRAINT "category_trees_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "channel_settings" ADD CONSTRAINT "channel_settings_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contact_location_assignments" ADD CONSTRAINT "contact_location_assignments_contact_id_contacts_id_fk" FOREIGN KEY ("contact_id") REFERENCES "public"."contacts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contact_location_assignments" ADD CONSTRAINT "contact_location_assignments_location_id_account_locations_id_fk" FOREIGN KEY ("location_id") REFERENCES "public"."account_locations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contacts" ADD CONSTRAINT "contacts_account_id_accounts_id_fk" FOREIGN KEY ("account_id") REFERENCES "public"."accounts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contacts" ADD CONSTRAINT "contacts_role_id_account_roles_id_fk" FOREIGN KEY ("role_id") REFERENCES "public"."account_roles"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "coupon_redemptions" ADD CONSTRAINT "coupon_redemptions_coupon_id_coupons_id_fk" FOREIGN KEY ("coupon_id") REFERENCES "public"."coupons"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "coupon_redemptions" ADD CONSTRAINT "coupon_redemptions_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "coupon_redemptions" ADD CONSTRAINT "coupon_redemptions_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "coupon_redemptions" ADD CONSTRAINT "coupon_redemptions_contact_id_contacts_id_fk" FOREIGN KEY ("contact_id") REFERENCES "public"."contacts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "coupons" ADD CONSTRAINT "coupons_promotion_id_promotions_id_fk" FOREIGN KEY ("promotion_id") REFERENCES "public"."promotions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "customer_addresses" ADD CONSTRAINT "customer_addresses_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "customers" ADD CONSTRAINT "customers_origin_channel_id_channels_id_fk" FOREIGN KEY ("origin_channel_id") REFERENCES "public"."channels"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "customers" ADD CONSTRAINT "customers_customer_group_id_customer_groups_id_fk" FOREIGN KEY ("customer_group_id") REFERENCES "public"."customer_groups"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "gift_certificates" ADD CONSTRAINT "gift_certificates_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "gift_certificates" ADD CONSTRAINT "gift_certificates_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "gift_certificates" ADD CONSTRAINT "gift_certificates_contact_id_contacts_id_fk" FOREIGN KEY ("contact_id") REFERENCES "public"."contacts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inventory_levels" ADD CONSTRAINT "inventory_levels_variant_id_product_variants_id_fk" FOREIGN KEY ("variant_id") REFERENCES "public"."product_variants"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inventory_levels" ADD CONSTRAINT "inventory_levels_location_id_inventory_locations_id_fk" FOREIGN KEY ("location_id") REFERENCES "public"."inventory_locations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_items" ADD CONSTRAINT "order_items_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_items" ADD CONSTRAINT "order_items_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_items" ADD CONSTRAINT "order_items_variant_id_product_variants_id_fk" FOREIGN KEY ("variant_id") REFERENCES "public"."product_variants"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_refund_items" ADD CONSTRAINT "order_refund_items_refund_id_order_refunds_id_fk" FOREIGN KEY ("refund_id") REFERENCES "public"."order_refunds"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_refund_items" ADD CONSTRAINT "order_refund_items_order_item_id_order_items_id_fk" FOREIGN KEY ("order_item_id") REFERENCES "public"."order_items"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_refunds" ADD CONSTRAINT "order_refunds_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_refunds" ADD CONSTRAINT "order_refunds_transaction_id_order_transactions_id_fk" FOREIGN KEY ("transaction_id") REFERENCES "public"."order_transactions"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_shipping_addresses" ADD CONSTRAINT "order_shipping_addresses_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_transactions" ADD CONSTRAINT "order_transactions_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_account_id_accounts_id_fk" FOREIGN KEY ("account_id") REFERENCES "public"."accounts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_contact_id_contacts_id_fk" FOREIGN KEY ("contact_id") REFERENCES "public"."contacts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_sales_rep_id_sales_reps_id_fk" FOREIGN KEY ("sales_rep_id") REFERENCES "public"."sales_reps"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "price_list_assignments" ADD CONSTRAINT "price_list_assignments_price_list_id_price_lists_id_fk" FOREIGN KEY ("price_list_id") REFERENCES "public"."price_lists"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "price_list_assignments" ADD CONSTRAINT "price_list_assignments_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "price_list_records" ADD CONSTRAINT "price_list_records_price_list_id_price_lists_id_fk" FOREIGN KEY ("price_list_id") REFERENCES "public"."price_lists"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "price_list_records" ADD CONSTRAINT "price_list_records_variant_id_product_variants_id_fk" FOREIGN KEY ("variant_id") REFERENCES "public"."product_variants"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_categories" ADD CONSTRAINT "product_categories_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_categories" ADD CONSTRAINT "product_categories_category_id_categories_id_fk" FOREIGN KEY ("category_id") REFERENCES "public"."categories"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_channel_assignments" ADD CONSTRAINT "product_channel_assignments_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_channel_assignments" ADD CONSTRAINT "product_channel_assignments_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_images" ADD CONSTRAINT "product_images_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_images" ADD CONSTRAINT "product_images_variant_id_product_variants_id_fk" FOREIGN KEY ("variant_id") REFERENCES "public"."product_variants"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_modifier_values" ADD CONSTRAINT "product_modifier_values_modifier_id_product_modifiers_id_fk" FOREIGN KEY ("modifier_id") REFERENCES "public"."product_modifiers"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_modifiers" ADD CONSTRAINT "product_modifiers_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_option_values" ADD CONSTRAINT "product_option_values_option_id_product_options_id_fk" FOREIGN KEY ("option_id") REFERENCES "public"."product_options"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_options" ADD CONSTRAINT "product_options_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_reviews" ADD CONSTRAINT "product_reviews_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_reviews" ADD CONSTRAINT "product_reviews_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_reviews" ADD CONSTRAINT "product_reviews_contact_id_contacts_id_fk" FOREIGN KEY ("contact_id") REFERENCES "public"."contacts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_reviews" ADD CONSTRAINT "product_reviews_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_variant_options" ADD CONSTRAINT "product_variant_options_variant_id_product_variants_id_fk" FOREIGN KEY ("variant_id") REFERENCES "public"."product_variants"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_variant_options" ADD CONSTRAINT "product_variant_options_option_id_product_options_id_fk" FOREIGN KEY ("option_id") REFERENCES "public"."product_options"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_variant_options" ADD CONSTRAINT "product_variant_options_option_value_id_product_option_values_id_fk" FOREIGN KEY ("option_value_id") REFERENCES "public"."product_option_values"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_variants" ADD CONSTRAINT "product_variants_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_videos" ADD CONSTRAINT "product_videos_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "products" ADD CONSTRAINT "products_brand_id_brands_id_fk" FOREIGN KEY ("brand_id") REFERENCES "public"."brands"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_items" ADD CONSTRAINT "quote_items_quote_id_quotes_id_fk" FOREIGN KEY ("quote_id") REFERENCES "public"."quotes"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_items" ADD CONSTRAINT "quote_items_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_items" ADD CONSTRAINT "quote_items_variant_id_product_variants_id_fk" FOREIGN KEY ("variant_id") REFERENCES "public"."product_variants"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quotes" ADD CONSTRAINT "quotes_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quotes" ADD CONSTRAINT "quotes_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quotes" ADD CONSTRAINT "quotes_account_id_accounts_id_fk" FOREIGN KEY ("account_id") REFERENCES "public"."accounts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quotes" ADD CONSTRAINT "quotes_contact_id_contacts_id_fk" FOREIGN KEY ("contact_id") REFERENCES "public"."contacts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shipment_items" ADD CONSTRAINT "shipment_items_shipment_id_shipments_id_fk" FOREIGN KEY ("shipment_id") REFERENCES "public"."shipments"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shipment_items" ADD CONSTRAINT "shipment_items_order_item_id_order_items_id_fk" FOREIGN KEY ("order_item_id") REFERENCES "public"."order_items"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shipments" ADD CONSTRAINT "shipments_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shipments" ADD CONSTRAINT "shipments_order_shipping_address_id_order_shipping_addresses_id_fk" FOREIGN KEY ("order_shipping_address_id") REFERENCES "public"."order_shipping_addresses"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shipping_methods" ADD CONSTRAINT "shipping_methods_shipping_zone_id_shipping_zones_id_fk" FOREIGN KEY ("shipping_zone_id") REFERENCES "public"."shipping_zones"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sites" ADD CONSTRAINT "sites_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "tax_rates" ADD CONSTRAINT "tax_rates_tax_class_id_tax_classes_id_fk" FOREIGN KEY ("tax_class_id") REFERENCES "public"."tax_classes"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "webhook_events" ADD CONSTRAINT "webhook_events_webhook_id_webhooks_id_fk" FOREIGN KEY ("webhook_id") REFERENCES "public"."webhooks"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "webhooks" ADD CONSTRAINT "webhooks_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "wishlist_items" ADD CONSTRAINT "wishlist_items_wishlist_id_wishlists_id_fk" FOREIGN KEY ("wishlist_id") REFERENCES "public"."wishlists"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "wishlist_items" ADD CONSTRAINT "wishlist_items_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "wishlist_items" ADD CONSTRAINT "wishlist_items_variant_id_product_variants_id_fk" FOREIGN KEY ("variant_id") REFERENCES "public"."product_variants"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "wishlists" ADD CONSTRAINT "wishlists_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "wishlists" ADD CONSTRAINT "wishlists_contact_id_contacts_id_fk" FOREIGN KEY ("contact_id") REFERENCES "public"."contacts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_account_addresses_account" ON "account_addresses" USING btree ("account_id");--> statement-breakpoint
CREATE INDEX "idx_account_locations_account" ON "account_locations" USING btree ("account_id");--> statement-breakpoint
CREATE INDEX "idx_account_sales_rep_account" ON "account_sales_rep_assignments" USING btree ("account_id");--> statement-breakpoint
CREATE INDEX "idx_account_sales_rep_rep" ON "account_sales_rep_assignments" USING btree ("sales_rep_id");--> statement-breakpoint
CREATE INDEX "idx_accounts_name" ON "accounts" USING btree ("name");--> statement-breakpoint
CREATE INDEX "idx_accounts_status" ON "accounts" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_accounts_customer_group" ON "accounts" USING btree ("customer_group_id");--> statement-breakpoint
CREATE INDEX "idx_accounts_channel" ON "accounts" USING btree ("origin_channel_id");--> statement-breakpoint
CREATE INDEX "idx_approval_rules_account" ON "approval_rules" USING btree ("account_id");--> statement-breakpoint
CREATE INDEX "idx_audit_entity" ON "audit_log" USING btree ("entity_type","entity_id");--> statement-breakpoint
CREATE INDEX "idx_audit_date" ON "audit_log" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_audit_user" ON "audit_log" USING btree ("admin_user_id");--> statement-breakpoint
CREATE INDEX "idx_bulk_pricing_product" ON "bulk_pricing_rules" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "idx_cart_items_cart" ON "cart_items" USING btree ("cart_id");--> statement-breakpoint
CREATE INDEX "idx_cart_items_product" ON "cart_items" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "idx_carts_customer" ON "carts" USING btree ("customer_id");--> statement-breakpoint
CREATE INDEX "idx_carts_channel" ON "carts" USING btree ("channel_id");--> statement-breakpoint
CREATE INDEX "idx_carts_status" ON "carts" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_categories_tree" ON "categories" USING btree ("tree_id");--> statement-breakpoint
CREATE INDEX "idx_categories_parent" ON "categories" USING btree ("parent_id");--> statement-breakpoint
CREATE INDEX "idx_categories_tree_parent_active" ON "categories" USING btree ("tree_id","parent_id","is_active");--> statement-breakpoint
CREATE INDEX "idx_contact_location_contact" ON "contact_location_assignments" USING btree ("contact_id");--> statement-breakpoint
CREATE INDEX "idx_contact_location_location" ON "contact_location_assignments" USING btree ("location_id");--> statement-breakpoint
CREATE INDEX "idx_contacts_email" ON "contacts" USING btree ("email");--> statement-breakpoint
CREATE INDEX "idx_contacts_account" ON "contacts" USING btree ("account_id");--> statement-breakpoint
CREATE INDEX "idx_contacts_role" ON "contacts" USING btree ("role_id");--> statement-breakpoint
CREATE INDEX "idx_contacts_active" ON "contacts" USING btree ("is_active");--> statement-breakpoint
CREATE INDEX "idx_contacts_email_active" ON "contacts" USING btree ("email","is_active");--> statement-breakpoint
CREATE INDEX "idx_coupons_code" ON "coupons" USING btree ("code");--> statement-breakpoint
CREATE INDEX "idx_coupons_promotion" ON "coupons" USING btree ("promotion_id");--> statement-breakpoint
CREATE INDEX "idx_customer_addresses_customer" ON "customer_addresses" USING btree ("customer_id");--> statement-breakpoint
CREATE INDEX "idx_customers_email" ON "customers" USING btree ("email");--> statement-breakpoint
CREATE INDEX "idx_customers_group" ON "customers" USING btree ("customer_group_id");--> statement-breakpoint
CREATE INDEX "idx_customers_channel" ON "customers" USING btree ("origin_channel_id");--> statement-breakpoint
CREATE INDEX "idx_customers_email_active" ON "customers" USING btree ("email","is_active");--> statement-breakpoint
CREATE INDEX "idx_gift_certificates_code" ON "gift_certificates" USING btree ("code");--> statement-breakpoint
CREATE INDEX "idx_gift_certificates_email" ON "gift_certificates" USING btree ("to_email");--> statement-breakpoint
CREATE INDEX "idx_inventory_variant" ON "inventory_levels" USING btree ("variant_id");--> statement-breakpoint
CREATE INDEX "idx_inventory_location" ON "inventory_levels" USING btree ("location_id");--> statement-breakpoint
CREATE INDEX "idx_order_items_order" ON "order_items" USING btree ("order_id");--> statement-breakpoint
CREATE INDEX "idx_order_items_product" ON "order_items" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "idx_order_shipping_order" ON "order_shipping_addresses" USING btree ("order_id");--> statement-breakpoint
CREATE INDEX "idx_transactions_order" ON "order_transactions" USING btree ("order_id");--> statement-breakpoint
CREATE INDEX "idx_transactions_gateway" ON "order_transactions" USING btree ("gateway_transaction_id");--> statement-breakpoint
CREATE INDEX "idx_orders_channel" ON "orders" USING btree ("channel_id");--> statement-breakpoint
CREATE INDEX "idx_orders_account" ON "orders" USING btree ("account_id");--> statement-breakpoint
CREATE INDEX "idx_orders_contact" ON "orders" USING btree ("contact_id");--> statement-breakpoint
CREATE INDEX "idx_orders_sales_rep" ON "orders" USING btree ("sales_rep_id");--> statement-breakpoint
CREATE INDEX "idx_orders_status" ON "orders" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_orders_date" ON "orders" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_orders_number" ON "orders" USING btree ("order_number");--> statement-breakpoint
CREATE INDEX "idx_orders_status_date" ON "orders" USING btree ("status","created_at");--> statement-breakpoint
CREATE INDEX "idx_price_records_pricelist" ON "price_list_records" USING btree ("price_list_id");--> statement-breakpoint
CREATE INDEX "idx_price_records_variant" ON "price_list_records" USING btree ("variant_id");--> statement-breakpoint
CREATE INDEX "idx_product_categories_product" ON "product_categories" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "idx_product_categories_category" ON "product_categories" USING btree ("category_id");--> statement-breakpoint
CREATE INDEX "idx_product_channel_product" ON "product_channel_assignments" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "idx_product_channel_channel" ON "product_channel_assignments" USING btree ("channel_id");--> statement-breakpoint
CREATE INDEX "idx_product_images_product" ON "product_images" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "idx_option_values_option" ON "product_option_values" USING btree ("option_id");--> statement-breakpoint
CREATE INDEX "idx_product_options_product" ON "product_options" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "idx_reviews_product" ON "product_reviews" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "idx_reviews_customer" ON "product_reviews" USING btree ("customer_id");--> statement-breakpoint
CREATE INDEX "idx_reviews_status" ON "product_reviews" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_variant_options_variant" ON "product_variant_options" USING btree ("variant_id");--> statement-breakpoint
CREATE INDEX "idx_variants_product" ON "product_variants" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "idx_variants_sku" ON "product_variants" USING btree ("sku");--> statement-breakpoint
CREATE INDEX "idx_products_sku" ON "products" USING btree ("sku");--> statement-breakpoint
CREATE INDEX "idx_products_brand" ON "products" USING btree ("brand_id");--> statement-breakpoint
CREATE INDEX "idx_products_type" ON "products" USING btree ("type");--> statement-breakpoint
CREATE INDEX "idx_products_name" ON "products" USING btree ("name");--> statement-breakpoint
CREATE INDEX "idx_products_visible_featured" ON "products" USING btree ("is_visible","is_featured");--> statement-breakpoint
CREATE INDEX "idx_promotions_status" ON "promotions" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_promotions_dates" ON "promotions" USING btree ("start_date","end_date");--> statement-breakpoint
CREATE INDEX "idx_quote_items_quote" ON "quote_items" USING btree ("quote_id");--> statement-breakpoint
CREATE INDEX "idx_quote_items_product" ON "quote_items" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "idx_quotes_customer" ON "quotes" USING btree ("customer_id");--> statement-breakpoint
CREATE INDEX "idx_quotes_channel" ON "quotes" USING btree ("channel_id");--> statement-breakpoint
CREATE INDEX "idx_quotes_status" ON "quotes" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_shipments_order" ON "shipments" USING btree ("order_id");--> statement-breakpoint
CREATE INDEX "idx_webhook_events_status" ON "webhook_events" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_webhook_events_webhook" ON "webhook_events" USING btree ("webhook_id");