import { eq, sql } from "drizzle-orm";
import { orderStatuses, orders } from "../../schema";
import { getCommerceDb } from "../../db";
import { BaseService } from "../../base/BaseService";
import { UniqueConstraint } from "../../base/types";
import { ConflictError } from "../../errors";

/**
 * Service for managing order statuses.
 */
class OrderStatusServiceClass extends BaseService<typeof orderStatuses> {
  constructor() {
    super(orderStatuses, {
      resourceName: "Order Status",
      defaultSort: "sort_order",
      sortColumns: {
        id: orderStatuses.id,
        value: orderStatuses.value,
        label: orderStatuses.label,
        sort_order: orderStatuses.sortOrder,
        created_at: orderStatuses.createdAt,
      },
      filterColumns: {
        value: orderStatuses.value,
        label: orderStatuses.label,
        is_system: orderStatuses.isSystem,
        is_active: orderStatuses.isActive,
      },
      allowedFilters: ["value", "label", "is_system", "is_active"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [{ column: orderStatuses.value, fieldName: "value" }],
        message: "An order status with this value already exists.",
      },
    ];
  }

  protected async beforeDelete(
    _id: number,
    existing: Record<string, unknown>
  ): Promise<void> {
    if (existing.isSystem) {
      throw new ConflictError(
        "Cannot delete a built-in system status. System statuses are required for core functionality."
      );
    }

    // Check if any orders reference this status value
    const statusValue = existing.value as string;
    const db = getCommerceDb();
    const [countResult] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(orders)
      .where(eq(orders.status, statusValue));

    const count = countResult?.count ?? 0;
    if (count > 0) {
      throw new ConflictError(
        `Cannot delete order status because ${count} order(s) are using it.`
      );
    }
  }
}

export const orderStatusService = new OrderStatusServiceClass();
