import { PgColumn } from "drizzle-orm/pg-core";
import { coupons, couponRedemptions } from "../../schema";
import { NestedService } from "../../base/NestedService";

/**
 * Service for managing coupon redemptions (read-only).
 *
 * Coupon redemptions are created automatically when a coupon is used on an order,
 * not through direct API calls. This service only provides read access.
 */
class CouponRedemptionServiceClass extends NestedService<typeof coupons, typeof couponRedemptions> {
  constructor() {
    super(coupons, couponRedemptions, {
      resourceName: "Coupon Redemption",
      parentResourceName: "Coupon",
      defaultSort: "id",
      sortColumns: {
        id: couponRedemptions.id,
        redeemed_at: couponRedemptions.redeemedAt,
      },
      filterColumns: {
        order_id: couponRedemptions.orderId,
        customer_id: couponRedemptions.customerId,
        contact_id: couponRedemptions.contactId,
      },
      allowedFilters: ["order_id", "customer_id", "contact_id"],
    });
  }

  protected getParentIdColumn(): PgColumn {
    return coupons.id;
  }

  protected getParentForeignKey(): PgColumn {
    return couponRedemptions.couponId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "couponId";
  }
}

export const couponRedemptionService = new CouponRedemptionServiceClass();
