import { sql } from "drizzle-orm";
import { getCommerceDb } from "../../db";

export type Granularity = "day" | "week" | "month";

export interface RevenueTimeSeriesRow {
  period: string;
  revenue: number;
  order_count: number;
  avg_order_value: number;
}

interface GetRevenueTimeSeriesParams {
  startDate: Date;
  endDate: Date;
  granularity: Granularity;
}

const EXCLUDED_STATUSES = ["canceled", "cancelled", "declined", "refunded", "closed"];

/**
 * Get revenue and order count aggregated by time period.
 * Uses the idx_orders_status_date index for efficient filtering.
 */
export async function getRevenueTimeSeries({
  startDate,
  endDate,
  granularity,
}: GetRevenueTimeSeriesParams): Promise<RevenueTimeSeriesRow[]> {
  const db = getCommerceDb();

  const truncFn =
    granularity === "day"
      ? sql`date_trunc('day', created_at)`
      : granularity === "week"
        ? sql`date_trunc('week', created_at)`
        : sql`date_trunc('month', created_at)`;

  const rows = await db.execute(sql`
    SELECT
      ${truncFn} AS period,
      COALESCE(SUM(total_inc_tax::numeric), 0) AS revenue,
      COUNT(*)::int AS order_count,
      CASE
        WHEN COUNT(*) > 0
        THEN ROUND(COALESCE(SUM(total_inc_tax::numeric), 0) / COUNT(*), 2)
        ELSE 0
      END AS avg_order_value
    FROM orders
    WHERE created_at >= ${startDate.toISOString()}
      AND created_at < ${endDate.toISOString()}
      AND status NOT IN (${sql.join(
        EXCLUDED_STATUSES.map((s) => sql`${s}`),
        sql`, `
      )})
    GROUP BY ${truncFn}
    ORDER BY period ASC
  `);

  return (rows as unknown as Record<string, unknown>[]).map((row) => ({
    period: row.period instanceof Date
      ? row.period.toISOString()
      : new Date(String(row.period)).toISOString(),
    revenue: Number(row.revenue),
    order_count: Number(row.order_count),
    avg_order_value: Number(row.avg_order_value),
  }));
}
