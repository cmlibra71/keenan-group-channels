import { eq, and } from "drizzle-orm";
import {
  subscriptionPlans,
  channels,
  customerGroups,
} from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation, UniqueConstraint, DependencyCheck } from "../../base/types";

/**
 * Service for managing subscription plans per channel.
 */
class SubscriptionPlanServiceClass extends BaseService<typeof subscriptionPlans> {
  constructor() {
    super(subscriptionPlans, {
      resourceName: "Subscription Plan",
      defaultSort: "sort_order",
      sortColumns: {
        id: subscriptionPlans.id,
        name: subscriptionPlans.name,
        sort_order: subscriptionPlans.sortOrder,
        price: subscriptionPlans.price,
        created_at: subscriptionPlans.createdAt,
      },
      filterColumns: {
        channel_id: subscriptionPlans.channelId,
        is_active: subscriptionPlans.isActive,
        billing_interval: subscriptionPlans.billingInterval,
      },
      allowedFilters: ["channel_id", "is_active", "billing_interval"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: channels,
        column: channels.id,
        resourceName: "Channel",
        fieldName: "channelId",
      },
      {
        table: customerGroups,
        column: customerGroups.id,
        resourceName: "Customer Group",
        fieldName: "memberCustomerGroupId",
        optional: true,
      },
    ];
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [
          { column: subscriptionPlans.channelId, fieldName: "channelId" },
          { column: subscriptionPlans.slug, fieldName: "slug" },
        ],
        message: "A subscription plan with this slug already exists for this channel.",
        composite: true,
      },
    ];
  }

  /**
   * List active plans for a channel (storefront use).
   */
  async listActiveForChannel(channelId: number) {
    return this.db
      .select()
      .from(subscriptionPlans)
      .where(
        and(
          eq(subscriptionPlans.channelId, channelId),
          eq(subscriptionPlans.isActive, true)
        )
      )
      .orderBy(subscriptionPlans.sortOrder);
  }

  /**
   * Get a plan by slug within a channel.
   */
  async getBySlugForChannel(channelId: number, slug: string) {
    const [plan] = await this.db
      .select()
      .from(subscriptionPlans)
      .where(
        and(
          eq(subscriptionPlans.channelId, channelId),
          eq(subscriptionPlans.slug, slug)
        )
      )
      .limit(1);
    return plan || null;
  }
}

export const subscriptionPlanService = new SubscriptionPlanServiceClass();
