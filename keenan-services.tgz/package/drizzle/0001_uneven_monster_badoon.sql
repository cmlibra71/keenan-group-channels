CREATE TABLE "draw_entries" (
	"id" serial PRIMARY KEY NOT NULL,
	"draw_id" integer NOT NULL,
	"subscription_id" integer,
	"customer_id" integer NOT NULL,
	"entry_count" integer DEFAULT 1,
	"source" varchar(50) DEFAULT 'subscription' NOT NULL,
	"status" varchar(20) DEFAULT 'active' NOT NULL,
	"forfeited_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "draw_entry_unique" UNIQUE("draw_id","subscription_id","source")
);
--> statement-breakpoint
CREATE TABLE "draw_types" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"channel_id" integer NOT NULL,
	"name" varchar(255) NOT NULL,
	"slug" varchar(255) NOT NULL,
	"frequency" varchar(20) DEFAULT 'monthly' NOT NULL,
	"entry_model" varchar(20) DEFAULT 'accumulated' NOT NULL,
	"description" text,
	"is_active" boolean DEFAULT true,
	"sort_order" integer DEFAULT 0,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "draw_types_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "draw_type_channel_slug" UNIQUE("channel_id","slug")
);
--> statement-breakpoint
CREATE TABLE "draw_winners" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"draw_id" integer NOT NULL,
	"entry_id" integer NOT NULL,
	"customer_id" integer NOT NULL,
	"prize_id" integer,
	"status" varchar(20) DEFAULT 'pending' NOT NULL,
	"notified_at" timestamp with time zone,
	"claimed_at" timestamp with time zone,
	"fulfilled_at" timestamp with time zone,
	"notes" text,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "draw_winners_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "draws" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"draw_type_id" integer NOT NULL,
	"channel_id" integer NOT NULL,
	"name" varchar(255) NOT NULL,
	"description" text,
	"status" varchar(20) DEFAULT 'scheduled' NOT NULL,
	"scheduled_at" timestamp with time zone,
	"entry_deadline" timestamp with time zone,
	"drawn_at" timestamp with time zone,
	"entry_pool_size" integer DEFAULT 0,
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "draws_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "partner_discount_codes" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"partner_offer_id" integer NOT NULL,
	"subscription_id" integer NOT NULL,
	"customer_id" integer NOT NULL,
	"code" varchar(100) NOT NULL,
	"status" varchar(20) DEFAULT 'active' NOT NULL,
	"redeemed_at" timestamp with time zone,
	"revoked_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "partner_discount_codes_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "partner_code_offer_sub" UNIQUE("partner_offer_id","subscription_id")
);
--> statement-breakpoint
CREATE TABLE "partner_offers" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"channel_id" integer NOT NULL,
	"partner_name" varchar(255) NOT NULL,
	"partner_logo" varchar(500),
	"category" varchar(100),
	"title" varchar(255) NOT NULL,
	"description" text,
	"discount_type" varchar(20) DEFAULT 'percentage' NOT NULL,
	"discount_value" numeric(19, 4),
	"external_url" varchar(500),
	"is_active" boolean DEFAULT true,
	"start_date" timestamp with time zone,
	"end_date" timestamp with time zone,
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "partner_offers_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "prizes" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"channel_id" integer NOT NULL,
	"name" varchar(255) NOT NULL,
	"description" text,
	"image_url" varchar(500),
	"value" numeric(19, 4),
	"currency_code" char(3) DEFAULT 'AUD',
	"is_active" boolean DEFAULT true,
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "prizes_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "product_attachments" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"product_id" integer NOT NULL,
	"file_name" varchar(255) NOT NULL,
	"url" varchar(500) NOT NULL,
	"label" varchar(255),
	"file_type" varchar(50),
	"file_size" integer,
	"sort_order" integer DEFAULT 0,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "product_attachments_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "subscription_events" (
	"id" serial PRIMARY KEY NOT NULL,
	"subscription_id" integer NOT NULL,
	"event_type" varchar(50) NOT NULL,
	"previous_status" varchar(20),
	"new_status" varchar(20),
	"stripe_event_id" varchar(255),
	"amount" numeric(19, 4),
	"currency_code" char(3),
	"metadata" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "subscription_plans" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"channel_id" integer NOT NULL,
	"name" varchar(255) NOT NULL,
	"slug" varchar(255) NOT NULL,
	"description" text,
	"price" numeric(19, 4) NOT NULL,
	"currency_code" char(3) DEFAULT 'AUD',
	"billing_interval" varchar(20) DEFAULT 'month' NOT NULL,
	"billing_interval_count" integer DEFAULT 1,
	"trial_period_days" integer DEFAULT 0,
	"benefits" jsonb DEFAULT '[]'::jsonb,
	"member_customer_group_id" integer,
	"is_active" boolean DEFAULT true,
	"sort_order" integer DEFAULT 0,
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "subscription_plans_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "subscription_plan_channel_slug" UNIQUE("channel_id","slug")
);
--> statement-breakpoint
CREATE TABLE "subscriptions" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"channel_id" integer NOT NULL,
	"customer_id" integer NOT NULL,
	"plan_id" integer NOT NULL,
	"status" varchar(20) DEFAULT 'pending' NOT NULL,
	"stripe_subscription_id" varchar(255),
	"stripe_customer_id" varchar(255),
	"current_period_start" timestamp with time zone,
	"current_period_end" timestamp with time zone,
	"cancelled_at" timestamp with time zone,
	"cancel_at_period_end" boolean DEFAULT false,
	"consecutive_months" integer DEFAULT 0,
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "subscriptions_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
ALTER TABLE "products" ADD COLUMN "embedding" vector(768);--> statement-breakpoint
ALTER TABLE "draw_entries" ADD CONSTRAINT "draw_entries_draw_id_draws_id_fk" FOREIGN KEY ("draw_id") REFERENCES "public"."draws"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "draw_entries" ADD CONSTRAINT "draw_entries_subscription_id_subscriptions_id_fk" FOREIGN KEY ("subscription_id") REFERENCES "public"."subscriptions"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "draw_entries" ADD CONSTRAINT "draw_entries_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "draw_types" ADD CONSTRAINT "draw_types_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "draw_winners" ADD CONSTRAINT "draw_winners_draw_id_draws_id_fk" FOREIGN KEY ("draw_id") REFERENCES "public"."draws"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "draw_winners" ADD CONSTRAINT "draw_winners_entry_id_draw_entries_id_fk" FOREIGN KEY ("entry_id") REFERENCES "public"."draw_entries"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "draw_winners" ADD CONSTRAINT "draw_winners_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "draw_winners" ADD CONSTRAINT "draw_winners_prize_id_prizes_id_fk" FOREIGN KEY ("prize_id") REFERENCES "public"."prizes"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "draws" ADD CONSTRAINT "draws_draw_type_id_draw_types_id_fk" FOREIGN KEY ("draw_type_id") REFERENCES "public"."draw_types"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "draws" ADD CONSTRAINT "draws_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "partner_discount_codes" ADD CONSTRAINT "partner_discount_codes_partner_offer_id_partner_offers_id_fk" FOREIGN KEY ("partner_offer_id") REFERENCES "public"."partner_offers"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "partner_discount_codes" ADD CONSTRAINT "partner_discount_codes_subscription_id_subscriptions_id_fk" FOREIGN KEY ("subscription_id") REFERENCES "public"."subscriptions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "partner_discount_codes" ADD CONSTRAINT "partner_discount_codes_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "partner_offers" ADD CONSTRAINT "partner_offers_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "prizes" ADD CONSTRAINT "prizes_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_attachments" ADD CONSTRAINT "product_attachments_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "subscription_events" ADD CONSTRAINT "subscription_events_subscription_id_subscriptions_id_fk" FOREIGN KEY ("subscription_id") REFERENCES "public"."subscriptions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "subscription_plans" ADD CONSTRAINT "subscription_plans_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "subscription_plans" ADD CONSTRAINT "subscription_plans_member_customer_group_id_customer_groups_id_fk" FOREIGN KEY ("member_customer_group_id") REFERENCES "public"."customer_groups"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "subscriptions" ADD CONSTRAINT "subscriptions_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "subscriptions" ADD CONSTRAINT "subscriptions_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "subscriptions" ADD CONSTRAINT "subscriptions_plan_id_subscription_plans_id_fk" FOREIGN KEY ("plan_id") REFERENCES "public"."subscription_plans"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_draw_entries_draw" ON "draw_entries" USING btree ("draw_id");--> statement-breakpoint
CREATE INDEX "idx_draw_entries_customer" ON "draw_entries" USING btree ("customer_id");--> statement-breakpoint
CREATE INDEX "idx_draw_entries_subscription" ON "draw_entries" USING btree ("subscription_id");--> statement-breakpoint
CREATE INDEX "idx_draw_winners_draw" ON "draw_winners" USING btree ("draw_id");--> statement-breakpoint
CREATE INDEX "idx_draw_winners_customer" ON "draw_winners" USING btree ("customer_id");--> statement-breakpoint
CREATE INDEX "idx_draws_channel" ON "draws" USING btree ("channel_id");--> statement-breakpoint
CREATE INDEX "idx_draws_type" ON "draws" USING btree ("draw_type_id");--> statement-breakpoint
CREATE INDEX "idx_draws_status" ON "draws" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_draws_scheduled" ON "draws" USING btree ("scheduled_at");--> statement-breakpoint
CREATE INDEX "idx_partner_codes_offer" ON "partner_discount_codes" USING btree ("partner_offer_id");--> statement-breakpoint
CREATE INDEX "idx_partner_codes_subscription" ON "partner_discount_codes" USING btree ("subscription_id");--> statement-breakpoint
CREATE INDEX "idx_partner_codes_customer" ON "partner_discount_codes" USING btree ("customer_id");--> statement-breakpoint
CREATE INDEX "idx_partner_offers_channel_active" ON "partner_offers" USING btree ("channel_id","is_active");--> statement-breakpoint
CREATE INDEX "idx_partner_offers_category" ON "partner_offers" USING btree ("category");--> statement-breakpoint
CREATE INDEX "idx_prizes_channel" ON "prizes" USING btree ("channel_id");--> statement-breakpoint
CREATE INDEX "idx_product_attachments_product" ON "product_attachments" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "idx_subscription_events_sub" ON "subscription_events" USING btree ("subscription_id");--> statement-breakpoint
CREATE INDEX "idx_subscription_events_stripe" ON "subscription_events" USING btree ("stripe_event_id");--> statement-breakpoint
CREATE INDEX "idx_subscription_plans_channel_active" ON "subscription_plans" USING btree ("channel_id","is_active");--> statement-breakpoint
CREATE INDEX "idx_subscriptions_channel_customer" ON "subscriptions" USING btree ("channel_id","customer_id");--> statement-breakpoint
CREATE INDEX "idx_subscriptions_status" ON "subscriptions" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_subscriptions_stripe" ON "subscriptions" USING btree ("stripe_subscription_id");--> statement-breakpoint
CREATE INDEX "idx_products_embedding" ON "products" USING hnsw ("embedding" vector_cosine_ops);