import { inventoryLocations, inventoryLevels } from "../../schema";
import { BaseService } from "../../base/BaseService";
import { DependencyCheck, UniqueConstraint } from "../../base/types";

/**
 * Service for managing inventory locations (warehouses, stores, etc.).
 */
class InventoryLocationServiceClass extends BaseService<typeof inventoryLocations> {
  constructor() {
    super(inventoryLocations, {
      resourceName: "Inventory Location",
      defaultSort: "id",
      sortColumns: {
        id: inventoryLocations.id,
        name: inventoryLocations.name,
        created_at: inventoryLocations.createdAt,
      },
      filterColumns: {
        name: inventoryLocations.name,
        type: inventoryLocations.type,
        is_active: inventoryLocations.isActive,
        is_shipping_enabled: inventoryLocations.isShippingEnabled,
        is_pickup_enabled: inventoryLocations.isPickupEnabled,
      },
      allowedFilters: ["name", "type", "is_active", "is_shipping_enabled", "is_pickup_enabled"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [{ column: inventoryLocations.code, fieldName: "code" }],
        message: "An inventory location with this code already exists.",
      },
    ];
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: inventoryLevels,
        foreignKeyColumn: inventoryLevels.locationId,
        resourceName: "inventory level",
        message:
          "Cannot delete inventory location because it has {count} inventory level(s) associated. Remove inventory levels first.",
      },
    ];
  }
}

export const inventoryLocationService = new InventoryLocationServiceClass();
