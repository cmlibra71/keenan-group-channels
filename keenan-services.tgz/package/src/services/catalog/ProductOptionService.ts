import { PgColumn } from "drizzle-orm/pg-core";
import { products, productOptions, productOptionValues } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { DependencyCheck } from "../../base/types";

/**
 * Service for managing product options.
 */
class ProductOptionServiceClass extends NestedService<typeof products, typeof productOptions> {
  constructor() {
    super(products, productOptions, {
      resourceName: "Option",
      parentResourceName: "Product",
      defaultSort: "id",
      sortColumns: {
        id: productOptions.id,
        sort_order: productOptions.sortOrder,
        name: productOptions.name,
      },
      filterColumns: {
        name: productOptions.name,
        type: productOptions.type,
        is_required: productOptions.isRequired,
      },
      allowedFilters: ["name", "type", "is_required"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return products.id;
  }

  protected getParentForeignKey(): PgColumn {
    return productOptions.productId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "productId";
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: productOptionValues,
        foreignKeyColumn: productOptionValues.optionId,
        resourceName: "option value",
        message: "Cannot delete option because it has {count} value(s). Delete option values first.",
      },
    ];
  }
}

export const productOptionService = new ProductOptionServiceClass();
