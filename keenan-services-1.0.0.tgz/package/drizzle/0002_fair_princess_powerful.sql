CREATE TABLE IF NOT EXISTS "shipping_rate_cards" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"channel_id" integer NOT NULL,
	"name" varchar(255) NOT NULL,
	"description" text,
	"floor_rate" numeric(19, 4) DEFAULT '30.0000' NOT NULL,
	"is_active" boolean DEFAULT false,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "shipping_rate_cards_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "shipping_rate_tiers" (
	"id" serial PRIMARY KEY NOT NULL,
	"rate_zone_id" integer NOT NULL,
	"lower_limit" numeric(19, 4) NOT NULL,
	"upper_limit" numeric(19, 4),
	"rate" numeric(19, 4) NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "shipping_rate_zones" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"rate_card_id" integer NOT NULL,
	"name" varchar(100) NOT NULL,
	"state" varchar(10),
	"postcodes" text NOT NULL,
	"cap_rule" varchar(20) DEFAULT 'capped' NOT NULL,
	"cap_percentage" numeric(5, 2) DEFAULT '8.00' NOT NULL,
	"handling_fee" numeric(19, 4) DEFAULT '0.0000' NOT NULL,
	"enabled" boolean DEFAULT true,
	"sort_order" integer DEFAULT 0,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "shipping_rate_zones_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
ALTER TABLE "prizes" ADD COLUMN IF NOT EXISTS "product_id" integer;--> statement-breakpoint
ALTER TABLE "products" ADD COLUMN IF NOT EXISTS "upsell_product_ids" integer[] DEFAULT '{}';--> statement-breakpoint
ALTER TABLE "products" ADD COLUMN IF NOT EXISTS "cross_sell_product_ids" integer[] DEFAULT '{}';--> statement-breakpoint
ALTER TABLE "sites" ADD COLUMN IF NOT EXISTS "logo_url" varchar(500);--> statement-breakpoint
ALTER TABLE "sites" ADD COLUMN IF NOT EXISTS "logo_alt" varchar(255);--> statement-breakpoint
ALTER TABLE "sites" ADD COLUMN IF NOT EXISTS "favicon_url" varchar(500);--> statement-breakpoint
ALTER TABLE "sites" ADD COLUMN IF NOT EXISTS "mobile_logo_url" varchar(500);--> statement-breakpoint
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'shipping_rate_cards_channel_id_channels_id_fk') THEN
    ALTER TABLE "shipping_rate_cards" ADD CONSTRAINT "shipping_rate_cards_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;
  END IF;
END $$;--> statement-breakpoint
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'shipping_rate_tiers_rate_zone_id_shipping_rate_zones_id_fk') THEN
    ALTER TABLE "shipping_rate_tiers" ADD CONSTRAINT "shipping_rate_tiers_rate_zone_id_shipping_rate_zones_id_fk" FOREIGN KEY ("rate_zone_id") REFERENCES "public"."shipping_rate_zones"("id") ON DELETE cascade ON UPDATE no action;
  END IF;
END $$;--> statement-breakpoint
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'shipping_rate_zones_rate_card_id_shipping_rate_cards_id_fk') THEN
    ALTER TABLE "shipping_rate_zones" ADD CONSTRAINT "shipping_rate_zones_rate_card_id_shipping_rate_cards_id_fk" FOREIGN KEY ("rate_card_id") REFERENCES "public"."shipping_rate_cards"("id") ON DELETE cascade ON UPDATE no action;
  END IF;
END $$;--> statement-breakpoint
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'prizes_product_id_products_id_fk') THEN
    ALTER TABLE "prizes" ADD CONSTRAINT "prizes_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE set null ON UPDATE no action;
  END IF;
END $$;--> statement-breakpoint
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'category_trees_channel_id_unique') THEN
    ALTER TABLE "category_trees" ADD CONSTRAINT "category_trees_channel_id_unique" UNIQUE("channel_id");
  END IF;
END $$;
