/**
 * Seed Chef's Depot (Channel 2) membership data:
 * subscription plan, draw types, draws, prizes, partner offers, and feature flags.
 *
 * Prizes are populated from real products in the catalog.
 *
 * Idempotent — safe to run multiple times.
 * Run with: npx tsx scripts/seed-chefs-depot-membership.ts
 */
import "dotenv/config";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { eq, and } from "drizzle-orm";
import {
  channelSettings,
  subscriptionPlans,
  drawTypes,
  draws,
  prizes,
  partnerOffers,
} from "../src/schema";

const CHANNEL_ID = 2;

async function main() {
  const connectionString = process.env.COMMERCE_DATABASE_URL;
  if (!connectionString) {
    console.error("COMMERCE_DATABASE_URL is not set");
    process.exit(1);
  }

  const client = postgres(connectionString, { prepare: false, max: 2 });
  const db = drizzle(client);

  let created = 0;
  let skipped = 0;
  let updated = 0;

  function log(action: "created" | "skipped" | "updated", label: string) {
    if (action === "created") {
      created++;
      console.log(`  ✓ Created: ${label}`);
    } else if (action === "updated") {
      updated++;
      console.log(`  ↻ Updated: ${label}`);
    } else {
      skipped++;
      console.log(`  – Skipped (exists): ${label}`);
    }
  }

  // ── 1. Feature Flags ──────────────────────────────────────────────────
  console.log("\n── Feature Flags ──");
  const featureFlags: Record<string, boolean> = {
    subscriptions_enabled: true,
    draws_enabled: true,
    partner_offers_enabled: true,
    member_pricing_enabled: true,
  };

  for (const [key, value] of Object.entries(featureFlags)) {
    const existing = await db
      .select()
      .from(channelSettings)
      .where(
        and(
          eq(channelSettings.channelId, CHANNEL_ID),
          eq(channelSettings.settingKey, key)
        )
      )
      .limit(1);

    if (existing.length > 0) {
      log("skipped", key);
    } else {
      await db.insert(channelSettings).values({
        channelId: CHANNEL_ID,
        settingKey: key,
        settingValue: value,
      });
      log("created", key);
    }
  }

  // ── 2. Subscription Plan ──────────────────────────────────────────────
  console.log("\n── Subscription Plan ──");
  const planSlug = "chefs-depot-membership";
  const existingPlan = await db
    .select()
    .from(subscriptionPlans)
    .where(
      and(
        eq(subscriptionPlans.channelId, CHANNEL_ID),
        eq(subscriptionPlans.slug, planSlug)
      )
    )
    .limit(1);

  if (existingPlan.length > 0) {
    log("skipped", planSlug);
  } else {
    await db.insert(subscriptionPlans).values({
      channelId: CHANNEL_ID,
      name: "Chef's Depot Membership",
      slug: planSlug,
      description:
        "Monthly membership for exclusive member pricing, prize draws, free delivery, and partner discounts.",
      price: "14.95",
      billingInterval: "month",
      billingIntervalCount: 1,
      trialPeriodDays: 0,
      benefits: [
        "Members-only pricing (10-25% off retail)",
        "Free delivery on orders over $500",
        "Monthly, quarterly & grand prize draw entries",
        "Exclusive partner discounts",
        "Priority customer support",
      ],
      metafields: {},
    });
    log("created", planSlug);
  }

  // ── 3. Draw Types ─────────────────────────────────────────────────────
  console.log("\n── Draw Types ──");
  const drawTypeData = [
    {
      name: "Monthly Member Draw",
      slug: "monthly-member-draw",
      frequency: "monthly",
      entryModel: "accumulated",
      sortOrder: 0,
    },
    {
      name: "Quarterly Bonus Draw",
      slug: "quarterly-bonus-draw",
      frequency: "quarterly",
      entryModel: "accumulated",
      sortOrder: 1,
    },
    {
      name: "Grand Prize Draw",
      slug: "grand-prize-draw",
      frequency: "yearly",
      entryModel: "accumulated",
      sortOrder: 2,
    },
  ];

  const drawTypeIds: Record<string, number> = {};

  for (const dt of drawTypeData) {
    const existing = await db
      .select()
      .from(drawTypes)
      .where(
        and(
          eq(drawTypes.channelId, CHANNEL_ID),
          eq(drawTypes.slug, dt.slug)
        )
      )
      .limit(1);

    if (existing.length > 0) {
      drawTypeIds[dt.slug] = existing[0].id;
      log("skipped", dt.slug);
    } else {
      const [inserted] = await db
        .insert(drawTypes)
        .values({
          channelId: CHANNEL_ID,
          name: dt.name,
          slug: dt.slug,
          frequency: dt.frequency,
          entryModel: dt.entryModel,
          sortOrder: dt.sortOrder,
        })
        .returning({ id: drawTypes.id });
      drawTypeIds[dt.slug] = inserted.id;
      log("created", dt.slug);
    }
  }

  // ── 4. Draws ──────────────────────────────────────────────────────────
  console.log("\n── Draws ──");
  const drawData = [
    {
      drawTypeSlug: "monthly-member-draw",
      name: "April 2026 Monthly Draw",
      status: "open",
      scheduledAt: "2026-04-30T00:00:00+10:00",
      entryDeadline: "2026-04-28T23:59:59+10:00",
    },
    {
      drawTypeSlug: "monthly-member-draw",
      name: "May 2026 Monthly Draw",
      status: "scheduled",
      scheduledAt: "2026-05-31T00:00:00+10:00",
      entryDeadline: "2026-05-29T23:59:59+10:00",
    },
    {
      drawTypeSlug: "quarterly-bonus-draw",
      name: "Q2 2026 Quarterly Bonus Draw",
      status: "open",
      scheduledAt: "2026-06-30T00:00:00+10:00",
      entryDeadline: "2026-06-28T23:59:59+10:00",
    },
    {
      drawTypeSlug: "grand-prize-draw",
      name: "Grand Prize Draw 2026",
      status: "open",
      scheduledAt: "2026-12-20T00:00:00+11:00",
      entryDeadline: "2026-12-18T23:59:59+11:00",
    },
  ];

  for (const d of drawData) {
    const existing = await db
      .select()
      .from(draws)
      .where(
        and(eq(draws.channelId, CHANNEL_ID), eq(draws.name, d.name))
      )
      .limit(1);

    if (existing.length > 0) {
      log("skipped", d.name);
    } else {
      await db.insert(draws).values({
        drawTypeId: drawTypeIds[d.drawTypeSlug],
        channelId: CHANNEL_ID,
        name: d.name,
        status: d.status,
        scheduledAt: new Date(d.scheduledAt),
        entryDeadline: new Date(d.entryDeadline),
      });
      log("created", d.name);
    }
  }

  // ── 5. Prizes (from real catalog products) ────────────────────────────
  console.log("\n── Prizes ──");

  // Look up real products to use as prizes
  const [grandPrizeProduct] = await client`
    SELECT p.id, p.name, p.price, pi.url_standard as image_url
    FROM products p
    INNER JOIN product_channel_assignments pca ON pca.product_id = p.id AND pca.channel_id = ${CHANNEL_ID}
    LEFT JOIN product_images pi ON pi.product_id = p.id AND pi.sort_order = 0
    WHERE p.is_visible = true AND p.is_deleted = false AND p.name ILIKE '%rational%icombi%classic%'
    ORDER BY p.price ASC LIMIT 1
  `;

  const [quarterlyProduct] = await client`
    SELECT p.id, p.name, p.price, pi.url_standard as image_url
    FROM products p
    INNER JOIN product_channel_assignments pca ON pca.product_id = p.id AND pca.channel_id = ${CHANNEL_ID}
    LEFT JOIN product_images pi ON pi.product_id = p.id AND pi.sort_order = 0
    WHERE p.is_visible = true AND p.is_deleted = false AND p.name ILIKE '%rotel%deck%oven%'
    ORDER BY p.price ASC LIMIT 1
  `;

  const [monthlyProduct] = await client`
    SELECT p.id, p.name, p.price, pi.url_standard as image_url
    FROM products p
    INNER JOIN product_channel_assignments pca ON pca.product_id = p.id AND pca.channel_id = ${CHANNEL_ID}
    LEFT JOIN product_images pi ON pi.product_id = p.id AND pi.sort_order = 0
    WHERE p.is_visible = true AND p.is_deleted = false AND p.name ILIKE '%convotherm%combi%steamer%boiler%'
    ORDER BY p.price ASC LIMIT 1
  `;

  const prizeData = [
    {
      name: grandPrizeProduct?.name ?? "Rational iCombi Classic Combi Oven",
      description:
        "Grand Prize — the ultimate commercial combi oven for professional kitchens. Entry for all active members.",
      value: grandPrizeProduct?.price ?? "82200.0000",
      imageUrl: grandPrizeProduct?.image_url ?? null,
      productId: grandPrizeProduct?.id ?? null,
      metafields: {},
    },
    {
      name: quarterlyProduct?.name ?? "Rotel VTL Advantage 4 Deck Oven",
      description:
        "Quarterly Bonus Draw prize — a premium deck oven for serious baking operations.",
      value: quarterlyProduct?.price ?? "82910.0000",
      imageUrl: quarterlyProduct?.image_url ?? null,
      productId: quarterlyProduct?.id ?? null,
      metafields: {},
    },
    {
      name: monthlyProduct?.name ?? "Convotherm Electric Combi-Steamer Oven",
      description:
        "Monthly Member Draw prize — a versatile 40-tray combi-steamer oven with boiler system.",
      value: monthlyProduct?.price ?? "74750.0000",
      imageUrl: monthlyProduct?.image_url ?? null,
      productId: monthlyProduct?.id ?? null,
      metafields: {},
    },
  ];

  for (const p of prizeData) {
    const existing = await db
      .select()
      .from(prizes)
      .where(
        and(eq(prizes.channelId, CHANNEL_ID), eq(prizes.name, p.name))
      )
      .limit(1);

    if (existing.length > 0) {
      // Update existing prize with product data
      await db
        .update(prizes)
        .set({
          description: p.description,
          imageUrl: p.imageUrl,
          value: p.value,
          productId: p.productId,
          metafields: p.metafields,
          updatedAt: new Date(),
        })
        .where(eq(prizes.id, existing[0].id));
      log("updated", p.name);
    } else {
      // Check for old placeholder prizes by description keyword to replace them
      const oldPrize = await db
        .select()
        .from(prizes)
        .where(
          and(
            eq(prizes.channelId, CHANNEL_ID),
            eq(
              prizes.description,
              p.description.includes("Grand Prize")
                ? "The ultimate commercial combi oven for professional kitchens. Grand Prize draw entry for all active members."
                : p.description.includes("Quarterly")
                  ? "Quarterly bonus draw — premium equipment package of your choice."
                  : "Monthly member draw prize — spend on any equipment in our store."
            )
          )
        )
        .limit(1);

      if (oldPrize.length > 0) {
        // Replace the old placeholder prize with real product data
        await db
          .update(prizes)
          .set({
            name: p.name,
            description: p.description,
            imageUrl: p.imageUrl,
            value: p.value,
            productId: p.productId,
            metafields: p.metafields,
            updatedAt: new Date(),
          })
          .where(eq(prizes.id, oldPrize[0].id));
        log("updated", `${oldPrize[0].name} → ${p.name}`);
      } else {
        await db.insert(prizes).values({
          channelId: CHANNEL_ID,
          name: p.name,
          description: p.description,
          imageUrl: p.imageUrl,
          value: p.value,
          productId: p.productId,
          metafields: p.metafields,
        });
        log("created", p.name);
      }
    }
  }

  // ── 6. Partner Offers ─────────────────────────────────────────────────
  console.log("\n── Partner Offers ──");
  const offerData = [
    {
      partnerName: "CleanCo Supplies",
      title: "15% off all cleaning products",
      description:
        "Exclusive member discount on the full range of CleanCo commercial cleaning products.",
      discountType: "percentage",
      discountValue: "15",
      category: "Cleaning",
    },
    {
      partnerName: "Pacific Packaging",
      title: "10% off food packaging supplies",
      description:
        "Save on food-safe packaging, containers, and wrapping supplies from Pacific Packaging.",
      discountType: "percentage",
      discountValue: "10",
      category: "Packaging",
    },
    {
      partnerName: "Chef Uniforms Australia",
      title: "$50 off orders over $200",
      description:
        "Get $50 off when you spend $200 or more on chef uniforms and kitchen apparel.",
      discountType: "fixed",
      discountValue: "50",
      category: "Uniforms",
    },
  ];

  for (const o of offerData) {
    const existing = await db
      .select()
      .from(partnerOffers)
      .where(
        and(
          eq(partnerOffers.channelId, CHANNEL_ID),
          eq(partnerOffers.title, o.title)
        )
      )
      .limit(1);

    if (existing.length > 0) {
      log("skipped", o.title);
    } else {
      await db.insert(partnerOffers).values({
        channelId: CHANNEL_ID,
        partnerName: o.partnerName,
        title: o.title,
        description: o.description,
        discountType: o.discountType,
        discountValue: o.discountValue,
        category: o.category,
      });
      log("created", o.title);
    }
  }

  // ── Summary ───────────────────────────────────────────────────────────
  console.log(
    `\n── Done! Created: ${created}, Updated: ${updated}, Skipped: ${skipped} ──\n`
  );

  await client.end();
}

main().catch((err) => {
  console.error("Script failed:", err);
  process.exit(1);
});
