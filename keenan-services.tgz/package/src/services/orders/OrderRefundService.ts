import { PgColumn } from "drizzle-orm/pg-core";
import { orders, orderRefunds, orderRefundItems, orderTransactions } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { ForeignKeyValidation, IncludeConfig } from "../../base/types";

/**
 * Service for managing order refunds.
 *
 * This is a read-only service - refunds should not be deleted directly
 * as they represent financial records.
 */
class OrderRefundServiceClass extends NestedService<typeof orders, typeof orderRefunds> {
  constructor() {
    super(orders, orderRefunds, {
      resourceName: "Refund",
      parentResourceName: "Order",
      defaultSort: "id",
      sortColumns: {
        id: orderRefunds.id,
        created_at: orderRefunds.createdAt,
        total_amount: orderRefunds.totalAmount,
      },
      filterColumns: {
        payment_method: orderRefunds.paymentMethod,
        created_by_user_id: orderRefunds.createdByUserId,
        transaction_id: orderRefunds.transactionId,
      },
      allowedFilters: ["payment_method", "created_by_user_id", "transaction_id"],
      timestamps: {
        created: "createdAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return orders.id;
  }

  protected getParentForeignKey(): PgColumn {
    return orderRefunds.orderId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "orderId";
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: orderTransactions,
        column: orderTransactions.id,
        resourceName: "Transaction",
        fieldName: "transactionId",
        optional: true,
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "items",
        table: orderRefundItems,
        foreignKey: orderRefundItems.refundId,
      },
    ];
  }

  // Read-only service - no create, update, or delete operations
  // These methods are inherited but should not be used directly via API routes
}

export const orderRefundService = new OrderRefundServiceClass();
