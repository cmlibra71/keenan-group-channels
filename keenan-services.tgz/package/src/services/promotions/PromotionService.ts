import { promotions, coupons } from "../../schema";
import { BaseService } from "../../base/BaseService";
import { DependencyCheck, IncludeConfig } from "../../base/types";

/**
 * Service for managing promotions.
 */
class PromotionServiceClass extends BaseService<typeof promotions> {
  constructor() {
    super(promotions, {
      resourceName: "Promotion",
      defaultSort: "id",
      sortColumns: {
        id: promotions.id,
        name: promotions.name,
        priority: promotions.priority,
        start_date: promotions.startDate,
        created_at: promotions.createdAt,
      },
      filterColumns: {
        status: promotions.status,
        redemption_type: promotions.redemptionType,
        name: promotions.name,
      },
      allowedFilters: ["status", "redemption_type", "name"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: coupons,
        foreignKeyColumn: coupons.promotionId,
        resourceName: "coupon",
        message: "Cannot delete promotion because it has {count} coupon(s) associated with it.",
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "coupons",
        table: coupons,
        foreignKey: coupons.promotionId,
      },
    ];
  }
}

export const promotionService = new PromotionServiceClass();
