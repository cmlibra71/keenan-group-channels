import {
  accounts,
  channels,
  customerGroups,
  contacts,
  accountLocations,
  accountAddresses,
  accountSalesRepAssignments,
  orders,
} from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation, DependencyCheck, IncludeConfig } from "../../base/types";

/**
 * Service for managing accounts (B2B company entities).
 */
class AccountServiceClass extends BaseService<typeof accounts> {
  constructor() {
    super(accounts, {
      resourceName: "Account",
      defaultSort: "id",
      sortColumns: {
        id: accounts.id,
        name: accounts.name,
        status: accounts.status,
        created_at: accounts.createdAt,
      },
      filterColumns: {
        name: accounts.name,
        status: accounts.status,
        customer_group_id: accounts.customerGroupId,
        origin_channel_id: accounts.originChannelId,
        industry: accounts.industry,
      },
      allowedFilters: ["name", "status", "customer_group_id", "origin_channel_id", "industry"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: customerGroups,
        column: customerGroups.id,
        resourceName: "Customer Group",
        fieldName: "customerGroupId",
        optional: true,
      },
      {
        table: channels,
        column: channels.id,
        resourceName: "Channel",
        fieldName: "originChannelId",
        optional: true,
      },
    ];
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: orders,
        foreignKeyColumn: orders.accountId,
        resourceName: "order",
        message: "Cannot delete account because it has {count} order(s).",
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "contacts",
        table: contacts,
        foreignKey: contacts.accountId,
      },
      {
        name: "locations",
        table: accountLocations,
        foreignKey: accountLocations.accountId,
      },
      {
        name: "addresses",
        table: accountAddresses,
        foreignKey: accountAddresses.accountId,
      },
      {
        name: "sales_reps",
        table: accountSalesRepAssignments,
        foreignKey: accountSalesRepAssignments.accountId,
      },
    ];
  }
}

export const accountService = new AccountServiceClass();
