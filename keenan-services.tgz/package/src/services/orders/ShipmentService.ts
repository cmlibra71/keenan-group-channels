import { PgColumn } from "drizzle-orm/pg-core";
import { orders, shipments, shipmentItems, orderShippingAddresses } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { ForeignKeyValidation, DependencyCheck, IncludeConfig } from "../../base/types";

/**
 * Service for managing shipments.
 */
class ShipmentServiceClass extends NestedService<typeof orders, typeof shipments> {
  constructor() {
    super(orders, shipments, {
      resourceName: "Shipment",
      parentResourceName: "Order",
      defaultSort: "id",
      sortColumns: {
        id: shipments.id,
        created_at: shipments.createdAt,
        shipped_at: shipments.shippedAt,
        tracking_carrier: shipments.trackingCarrier,
      },
      filterColumns: {
        tracking_carrier: shipments.trackingCarrier,
        shipping_method: shipments.shippingMethod,
        shipping_provider: shipments.shippingProvider,
        order_shipping_address_id: shipments.orderShippingAddressId,
      },
      allowedFilters: ["tracking_carrier", "shipping_method", "shipping_provider", "order_shipping_address_id"],
      timestamps: {
        created: "createdAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return orders.id;
  }

  protected getParentForeignKey(): PgColumn {
    return shipments.orderId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "orderId";
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: orderShippingAddresses,
        column: orderShippingAddresses.id,
        resourceName: "Order Shipping Address",
        fieldName: "orderShippingAddressId",
        optional: true,
      },
    ];
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: shipmentItems,
        foreignKeyColumn: shipmentItems.shipmentId,
        resourceName: "shipment item",
        message: "Cannot delete Shipment because it has {count} shipment item(s). Delete shipment items first.",
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "items",
        table: shipmentItems,
        foreignKey: shipmentItems.shipmentId,
      },
    ];
  }
}

export const shipmentService = new ShipmentServiceClass();
