import { SquareClient, SquareEnvironment, SquareError } from "square";
import type * as Square from "square";
import type {
  PaymentProvider,
  PaymentResult,
  PaymentDetails,
  CredentialValidationResult,
} from "../types";

/**
 * Square payment provider.
 *
 * Uses source_id nonce from client-side Square Web Payments SDK.
 * Credentials: { access_token, location_id }
 */
export class SquareProvider implements PaymentProvider {
  readonly providerName = "square";
  private client: SquareClient;
  private locationId: string;

  constructor(accessToken: string, locationId: string, testMode: boolean) {
    this.client = new SquareClient({
      token: accessToken,
      environment: testMode ? SquareEnvironment.Sandbox : SquareEnvironment.Production,
    });
    this.locationId = locationId;
  }

  /** Convert decimal string to cents */
  private toCents(amount: string): number {
    return Math.round(parseFloat(amount) * 100);
  }

  private generateIdempotencyKey(): string {
    return `${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
  }

  async validateCredentials(
    credentials: Record<string, string>,
    testMode: boolean
  ): Promise<CredentialValidationResult> {
    try {
      const client = new SquareClient({
        token: credentials.access_token,
        environment: testMode ? SquareEnvironment.Sandbox : SquareEnvironment.Production,
      });

      const response = await client.locations.list();
      const locations = response.locations || [];
      const locationNames = locations.map((l) => l.name);

      return {
        valid: true,
        message: testMode
          ? "Connected to Square (sandbox)"
          : "Connected to Square (live)",
        details: {
          locations: locationNames,
          location_count: locations.length,
        },
      };
    } catch (err) {
      const message = this.extractErrorMessage(err);
      return { valid: false, message };
    }
  }

  async authorize(
    amount: string,
    currencyCode: string,
    details: PaymentDetails
  ): Promise<PaymentResult> {
    try {
      const response = await this.client.payments.create({
        sourceId: details.payment_token || "EXTERNAL",
        idempotencyKey: this.generateIdempotencyKey(),
        amountMoney: {
          amount: BigInt(this.toCents(amount)),
          currency: currencyCode as Square.Currency,
        },
        locationId: this.locationId,
        autocomplete: false,
        note: details.description,
        referenceId: details.order_number || undefined,
      });

      const payment = response.payment;
      return {
        success: payment?.status === "APPROVED",
        gateway_transaction_id: payment?.id || null,
        status: payment?.status === "APPROVED" ? "authorized" : "pending",
        amount,
        currency_code: currencyCode,
        gateway_response: {
          id: payment?.id,
          status: payment?.status,
          receipt_number: payment?.receiptNumber,
        },
      };
    } catch (err) {
      return this.handleError(err, amount, currencyCode);
    }
  }

  async capture(transactionId: string, amount?: string): Promise<PaymentResult> {
    try {
      const response = await this.client.payments.complete({
        paymentId: transactionId,
      });

      const payment = response.payment;
      const capturedAmount =
        amount || String(Number(payment?.totalMoney?.amount || 0) / 100);

      return {
        success: payment?.status === "COMPLETED",
        gateway_transaction_id: payment?.id || null,
        status: "captured",
        amount: capturedAmount,
        currency_code: (payment?.totalMoney?.currency as string) || "",
        gateway_response: { id: payment?.id, status: payment?.status },
      };
    } catch (err) {
      return this.handleError(err, amount || "0", "");
    }
  }

  async charge(
    amount: string,
    currencyCode: string,
    details: PaymentDetails
  ): Promise<PaymentResult> {
    try {
      const response = await this.client.payments.create({
        sourceId: details.payment_token || "EXTERNAL",
        idempotencyKey: this.generateIdempotencyKey(),
        amountMoney: {
          amount: BigInt(this.toCents(amount)),
          currency: currencyCode as Square.Currency,
        },
        locationId: this.locationId,
        autocomplete: true,
        note: details.description,
        referenceId: details.order_number || undefined,
      });

      const payment = response.payment;
      return {
        success: payment?.status === "COMPLETED",
        gateway_transaction_id: payment?.id || null,
        status: payment?.status === "COMPLETED" ? "captured" : "pending",
        amount,
        currency_code: currencyCode,
        gateway_response: {
          id: payment?.id,
          status: payment?.status,
          receipt_number: payment?.receiptNumber,
        },
      };
    } catch (err) {
      return this.handleError(err, amount, currencyCode);
    }
  }

  async refund(transactionId: string, amount?: string): Promise<PaymentResult> {
    try {
      // If no amount provided, look up the original payment to get the full amount
      let refundAmount: bigint;
      let currencyCode = "AUD";

      if (amount) {
        refundAmount = BigInt(this.toCents(amount));
      } else {
        const paymentResponse = await this.client.payments.get({
          paymentId: transactionId,
        });
        refundAmount = paymentResponse.payment?.totalMoney?.amount || BigInt(0);
        currencyCode = (paymentResponse.payment?.totalMoney?.currency as string) || "AUD";
      }

      const response = await this.client.refunds.refundPayment({
        idempotencyKey: this.generateIdempotencyKey(),
        paymentId: transactionId,
        amountMoney: {
          amount: refundAmount,
          currency: currencyCode as Square.Currency,
        },
      });

      const refund = response.refund;
      return {
        success: refund?.status === "COMPLETED" || refund?.status === "PENDING",
        gateway_transaction_id: refund?.id || null,
        status: "refunded",
        amount: amount || String(Number(refund?.amountMoney?.amount || 0) / 100),
        currency_code: (refund?.amountMoney?.currency as string) || "",
        gateway_response: { id: refund?.id, status: refund?.status },
      };
    } catch (err) {
      return this.handleError(err, amount || "0", "");
    }
  }

  async void(transactionId: string): Promise<PaymentResult> {
    try {
      const response = await this.client.payments.cancel({
        paymentId: transactionId,
      });

      const payment = response.payment;
      return {
        success: payment?.status === "CANCELED",
        gateway_transaction_id: payment?.id || null,
        status: "voided",
        amount: String(Number(payment?.totalMoney?.amount || 0) / 100),
        currency_code: (payment?.totalMoney?.currency as string) || "",
        gateway_response: { id: payment?.id, status: payment?.status },
      };
    } catch (err) {
      return this.handleError(err, "0", "");
    }
  }

  private extractErrorMessage(err: unknown): string {
    if (err instanceof SquareError) {
      return err.message || "Square API error";
    }
    if (err instanceof Error) {
      return err.message;
    }
    return "Unknown Square error";
  }

  private handleError(
    err: unknown,
    amount: string,
    currencyCode: string
  ): PaymentResult {
    const message = this.extractErrorMessage(err);

    return {
      success: false,
      gateway_transaction_id: null,
      status: "failed",
      amount,
      currency_code: currencyCode,
      gateway_response: { error: message },
      error_message: message,
    };
  }
}
