export { storeSettingsService } from "./StoreSettingsService";
