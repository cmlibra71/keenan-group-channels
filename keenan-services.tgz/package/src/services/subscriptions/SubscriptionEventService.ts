import { eq } from "drizzle-orm";
import { PgColumn } from "drizzle-orm/pg-core";
import { subscriptions, subscriptionEvents } from "../../schema";
import { NestedService } from "../../base/NestedService";

/**
 * Append-only event log for subscriptions. No update or delete operations.
 */
class SubscriptionEventServiceClass extends NestedService<
  typeof subscriptions,
  typeof subscriptionEvents
> {
  constructor() {
    super(subscriptions, subscriptionEvents, {
      resourceName: "Subscription Event",
      parentResourceName: "Subscription",
      defaultSort: "id",
      sortColumns: {
        id: subscriptionEvents.id,
        created_at: subscriptionEvents.createdAt,
        event_type: subscriptionEvents.eventType,
      },
      filterColumns: {
        event_type: subscriptionEvents.eventType,
        stripe_event_id: subscriptionEvents.stripeEventId,
      },
      allowedFilters: ["event_type", "stripe_event_id"],
      timestamps: {
        created: "createdAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return subscriptions.id;
  }

  protected getParentForeignKey(): PgColumn {
    return subscriptionEvents.subscriptionId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "subscriptionId";
  }

  /**
   * Check if a Stripe event has already been processed (idempotency).
   */
  async existsByStripeEventId(stripeEventId: string): Promise<boolean> {
    const [existing] = await this.db
      .select({ id: subscriptionEvents.id })
      .from(subscriptionEvents)
      .where(eq(subscriptionEvents.stripeEventId, stripeEventId))
      .limit(1);
    return !!existing;
  }
}

export const subscriptionEventService = new SubscriptionEventServiceClass();
