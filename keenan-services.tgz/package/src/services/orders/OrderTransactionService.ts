import { PgColumn } from "drizzle-orm/pg-core";
import { orders, orderTransactions } from "../../schema";
import { NestedService } from "../../base/NestedService";

/**
 * Service for managing order transactions.
 *
 * This is a read-only service - transactions should not be deleted directly
 * as they represent financial records.
 */
class OrderTransactionServiceClass extends NestedService<typeof orders, typeof orderTransactions> {
  constructor() {
    super(orders, orderTransactions, {
      resourceName: "Transaction",
      parentResourceName: "Order",
      defaultSort: "id",
      sortColumns: {
        id: orderTransactions.id,
        created_at: orderTransactions.createdAt,
        amount: orderTransactions.amount,
        event: orderTransactions.event,
        status: orderTransactions.status,
      },
      filterColumns: {
        event: orderTransactions.event,
        method: orderTransactions.method,
        status: orderTransactions.status,
        gateway: orderTransactions.gateway,
        currency_code: orderTransactions.currencyCode,
      },
      allowedFilters: ["event", "method", "status", "gateway", "currency_code"],
      timestamps: {
        created: "createdAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return orders.id;
  }

  protected getParentForeignKey(): PgColumn {
    return orderTransactions.orderId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "orderId";
  }

  // Read-only service - no create, update, or delete operations
  // These methods are inherited but should not be used directly via API routes
}

export const orderTransactionService = new OrderTransactionServiceClass();
