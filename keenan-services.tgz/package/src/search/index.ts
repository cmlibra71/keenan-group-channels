export {
  // Types
  type MeilisearchProductDocument,
  type MeilisearchSearchResult,
  type SearchOptions,

  // Index management
  ensureProductIndex,

  // Document building
  buildProductDocument,
  buildProductDocumentsBatch,

  // Indexing
  indexProduct,
  indexProductsBatch,
  removeProduct,
  removeProductFromAllChannels,

  // Search
  searchProducts,

  // Sync (used by ProductService hooks)
  syncProductToMeilisearch,
  getProductChannelIds,
} from "./meilisearch";
