import { eq, and, sql, asc, desc, inArray, like } from "drizzle-orm";
import { getCommerceDb } from "../../db";
import {
  productChannelAssignments,
  products,
  productImages,
  channels,
} from "../../schema";
import { NotFoundError, ConflictError } from "../../errors";
import { transformRow, transformRows } from "../../transforms";
import {
  syncProductToMeilisearch,
  removeProduct as removeFromMeili,
  indexProduct,
  buildProductDocument,
  ensureProductIndex,
} from "../../search";

interface ListOptions {
  page: number;
  limit: number;
  sort?: string;
  direction?: "asc" | "desc";
  channelId?: number;
  productSearch?: string;
  isVisible?: boolean;
}

interface PaginatedResult<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
  };
}

interface ProductWithAssignments {
  id: number;
  name: string;
  sku: string | null;
  thumbnail_url: string | null;
  is_visible: boolean;
  price: string | null;
  assignments: {
    channel_id: number;
    channel_name: string;
    is_visible: boolean;
    is_featured: boolean | null;
    assigned_at: string | null;
  }[];
}

interface AssignmentOptions {
  isVisible?: boolean;
  isFeatured?: boolean | null;
  assigned_at?: string;
}

/**
 * Service for managing product-channel assignments.
 * Handles assigning products to sales channels with visibility and featured settings.
 */
class ProductChannelAssignmentServiceClass {
  private get db() {
    return getCommerceDb();
  }

  /**
   * List products with their channel assignments
   */
  async listProductsWithAssignments(options: ListOptions): Promise<PaginatedResult<ProductWithAssignments>> {
    const { page, limit, sort = "name", direction = "asc", channelId, productSearch, isVisible } = options;

    // Build base query conditions for products
    const conditions = [eq(products.isDeleted, false)];

    // If filtering by channel, we need to join with assignments
    let productIds: number[] | undefined;
    if (channelId) {
      // Get product IDs that have this channel assignment
      const assignmentFilter = isVisible !== undefined
        ? and(
            eq(productChannelAssignments.channelId, channelId),
            eq(productChannelAssignments.isVisible, isVisible)
          )
        : eq(productChannelAssignments.channelId, channelId);

      const assignedProducts = await this.db
        .select({ productId: productChannelAssignments.productId })
        .from(productChannelAssignments)
        .where(assignmentFilter);

      productIds = assignedProducts.map((a) => a.productId);

      if (productIds.length === 0) {
        return {
          data: [],
          pagination: { page, limit, total: 0 },
        };
      }

      conditions.push(inArray(products.id, productIds));
    }

    // Apply product name search
    if (productSearch) {
      conditions.push(like(products.name, `%${productSearch}%`));
    }

    const whereClause = and(...conditions);

    // Get total count
    const [countResult] = await this.db
      .select({ count: sql<number>`count(*)::int` })
      .from(products)
      .where(whereClause);

    const total = countResult?.count ?? 0;

    // Get sort column
    const sortColumn = sort === "name" ? products.name : sort === "sku" ? products.sku : products.id;
    const orderFn = direction === "desc" ? desc : asc;

    // Get paginated products
    const productResults = await this.db
      .select({
        id: products.id,
        name: products.name,
        sku: products.sku,
        isVisible: products.isVisible,
        price: products.price,
      })
      .from(products)
      .where(whereClause)
      .orderBy(orderFn(sortColumn))
      .limit(limit)
      .offset((page - 1) * limit);

    if (productResults.length === 0) {
      return {
        data: [],
        pagination: { page, limit, total },
      };
    }

    const resultProductIds = productResults.map((p) => p.id);

    // Get thumbnail images for these products
    const thumbnails = await this.db
      .select({
        productId: productImages.productId,
        urlThumbnail: productImages.urlThumbnail,
      })
      .from(productImages)
      .where(
        and(
          inArray(productImages.productId, resultProductIds),
          eq(productImages.isThumbnail, true)
        )
      );

    // Map thumbnails by product ID
    const thumbnailsByProduct = new Map<number, string | null>();
    for (const thumb of thumbnails) {
      thumbnailsByProduct.set(thumb.productId, thumb.urlThumbnail);
    }

    // Get all assignments for these products
    const assignments = await this.db
      .select({
        productId: productChannelAssignments.productId,
        channelId: productChannelAssignments.channelId,
        channelName: channels.name,
        isVisible: productChannelAssignments.isVisible,
        isFeatured: productChannelAssignments.isFeatured,
        assignedAt: productChannelAssignments.assignedAt,
      })
      .from(productChannelAssignments)
      .innerJoin(channels, eq(productChannelAssignments.channelId, channels.id))
      .where(inArray(productChannelAssignments.productId, resultProductIds));

    // Group assignments by product ID
    const assignmentsByProduct = new Map<number, typeof assignments>();
    for (const assignment of assignments) {
      const existing = assignmentsByProduct.get(assignment.productId) || [];
      existing.push(assignment);
      assignmentsByProduct.set(assignment.productId, existing);
    }

    // Build final result
    const data: ProductWithAssignments[] = productResults.map((product) => ({
      id: product.id,
      name: product.name,
      sku: product.sku,
      thumbnail_url: thumbnailsByProduct.get(product.id) ?? null,
      is_visible: product.isVisible ?? true,
      price: product.price,
      assignments: (assignmentsByProduct.get(product.id) || []).map((a) => ({
        channel_id: a.channelId,
        channel_name: a.channelName,
        is_visible: a.isVisible ?? true,
        is_featured: a.isFeatured,
        assigned_at: a.assignedAt?.toISOString() ?? null,
      })),
    }));

    return {
      data,
      pagination: { page, limit, total },
    };
  }

  /**
   * Get a single assignment
   */
  async getAssignment(productId: number, channelId: number): Promise<Record<string, unknown> | null> {
    const [result] = await this.db
      .select()
      .from(productChannelAssignments)
      .where(
        and(
          eq(productChannelAssignments.productId, productId),
          eq(productChannelAssignments.channelId, channelId)
        )
      )
      .limit(1);

    return result ? transformRow(result as Record<string, unknown>) : null;
  }

  /**
   * Assign a product to a channel
   */
  async assign(
    productId: number,
    channelId: number,
    options: AssignmentOptions = {}
  ): Promise<Record<string, unknown>> {
    // Validate product exists
    await this.validateProduct(productId);

    // Validate channel exists
    await this.validateChannel(channelId);

    // Check if assignment already exists
    const existing = await this.getAssignment(productId, channelId);
    if (existing) {
      throw new ConflictError(`Product ${productId} is already assigned to channel ${channelId}.`);
    }

    const [result] = await this.db
      .insert(productChannelAssignments)
      .values({
        productId,
        channelId,
        isVisible: options.isVisible ?? true,
        isFeatured: options.isFeatured ?? null,
        assignedAt: options.assigned_at ? new Date(options.assigned_at) : undefined,
      })
      .returning();

    // Sync to Meilisearch — add product to this channel's index
    this.syncProductToChannel(productId, channelId).catch(() => {});

    return transformRow(result as Record<string, unknown>);
  }

  /**
   * Update an existing assignment
   */
  async update(
    productId: number,
    channelId: number,
    data: AssignmentOptions
  ): Promise<Record<string, unknown>> {
    const existing = await this.getAssignment(productId, channelId);
    if (!existing) {
      throw new NotFoundError("Assignment", `${productId}-${channelId}`);
    }

    const [result] = await this.db
      .update(productChannelAssignments)
      .set({
        isVisible: data.isVisible,
        isFeatured: data.isFeatured,
      })
      .where(
        and(
          eq(productChannelAssignments.productId, productId),
          eq(productChannelAssignments.channelId, channelId)
        )
      )
      .returning();

    // Sync to Meilisearch — if hidden, remove; otherwise re-index
    if (data.isVisible === false) {
      removeFromMeili(channelId, productId).catch(() => {});
    } else {
      this.syncProductToChannel(productId, channelId).catch(() => {});
    }

    return transformRow(result as Record<string, unknown>);
  }

  /**
   * Remove a product from a channel
   */
  async remove(productId: number, channelId: number): Promise<void> {
    const existing = await this.getAssignment(productId, channelId);
    if (!existing) {
      throw new NotFoundError("Assignment", `${productId}-${channelId}`);
    }

    await this.db
      .delete(productChannelAssignments)
      .where(
        and(
          eq(productChannelAssignments.productId, productId),
          eq(productChannelAssignments.channelId, channelId)
        )
      );

    // Remove from Meilisearch
    removeFromMeili(channelId, productId).catch(() => {});
  }

  /**
   * Bulk assign products to a channel
   */
  async bulkAssign(
    productIds: number[],
    channelId: number,
    options: AssignmentOptions = {}
  ): Promise<{ assigned: number; skipped: number }> {
    // Validate channel exists
    await this.validateChannel(channelId);

    // Get existing assignments for this channel
    const existing = await this.db
      .select({ productId: productChannelAssignments.productId })
      .from(productChannelAssignments)
      .where(
        and(
          eq(productChannelAssignments.channelId, channelId),
          inArray(productChannelAssignments.productId, productIds)
        )
      );

    const existingProductIds = new Set(existing.map((e) => e.productId));
    const newProductIds = productIds.filter((id) => !existingProductIds.has(id));

    if (newProductIds.length > 0) {
      await this.db.insert(productChannelAssignments).values(
        newProductIds.map((productId) => ({
          productId,
          channelId,
          isVisible: options.isVisible ?? true,
          isFeatured: options.isFeatured ?? null,
        }))
      );

      // Sync new products to Meilisearch
      this.syncProductsToChannel(newProductIds, channelId).catch(() => {});
    }

    return {
      assigned: newProductIds.length,
      skipped: existingProductIds.size,
    };
  }

  /**
   * Bulk remove products from a channel
   */
  async bulkRemove(productIds: number[], channelId: number): Promise<number> {
    const result = await this.db
      .delete(productChannelAssignments)
      .where(
        and(
          eq(productChannelAssignments.channelId, channelId),
          inArray(productChannelAssignments.productId, productIds)
        )
      )
      .returning({ productId: productChannelAssignments.productId });

    // Remove from Meilisearch
    const removedIds = result.map((r) => r.productId);
    Promise.allSettled(
      removedIds.map((pid) => removeFromMeili(channelId, pid))
    ).catch(() => {});

    return result.length;
  }

  /**
   * Bulk update visibility for products in a channel
   */
  async bulkSetVisibility(
    productIds: number[],
    channelId: number,
    isVisible: boolean
  ): Promise<number> {
    const result = await this.db
      .update(productChannelAssignments)
      .set({ isVisible })
      .where(
        and(
          eq(productChannelAssignments.channelId, channelId),
          inArray(productChannelAssignments.productId, productIds)
        )
      )
      .returning({ productId: productChannelAssignments.productId });

    // Sync Meilisearch — remove hidden products, re-index visible ones
    const affectedIds = result.map((r) => r.productId);
    if (isVisible) {
      this.syncProductsToChannel(affectedIds, channelId).catch(() => {});
    } else {
      Promise.allSettled(
        affectedIds.map((pid) => removeFromMeili(channelId, pid))
      ).catch(() => {});
    }

    return result.length;
  }

  /**
   * Get the count of products assigned to a channel
   */
  async countForChannel(channelId: number): Promise<number> {
    const [result] = await this.db
      .select({ count: sql<number>`count(*)::int` })
      .from(productChannelAssignments)
      .where(eq(productChannelAssignments.channelId, channelId));

    return result?.count ?? 0;
  }

  /**
   * Get all channel assignments for a product
   */
  async getChannelsForProduct(productId: number): Promise<Record<string, unknown>[]> {
    const results = await this.db
      .select({
        id: productChannelAssignments.id,
        productId: productChannelAssignments.productId,
        channelId: productChannelAssignments.channelId,
        channelName: channels.name,
        isVisible: productChannelAssignments.isVisible,
        isFeatured: productChannelAssignments.isFeatured,
        assignedAt: productChannelAssignments.assignedAt,
      })
      .from(productChannelAssignments)
      .innerJoin(channels, eq(productChannelAssignments.channelId, channels.id))
      .where(eq(productChannelAssignments.productId, productId));

    return transformRows(results as unknown as Record<string, unknown>[]);
  }

  /**
   * Update all channel assignments for a product
   * Takes an array of channel IDs and syncs assignments
   */
  async syncProductChannels(
    productId: number,
    channelIds: number[],
    options: AssignmentOptions = {}
  ): Promise<{ added: number; removed: number }> {
    // Get current assignments
    const current = await this.db
      .select({ channelId: productChannelAssignments.channelId })
      .from(productChannelAssignments)
      .where(eq(productChannelAssignments.productId, productId));

    const currentChannelIds = new Set(current.map((c) => c.channelId));
    const targetChannelIds = new Set(channelIds);

    // Determine what to add and remove
    const toAdd = channelIds.filter((id) => !currentChannelIds.has(id));
    const toRemove = [...currentChannelIds].filter((id) => !targetChannelIds.has(id));

    // Add new assignments
    if (toAdd.length > 0) {
      await this.db.insert(productChannelAssignments).values(
        toAdd.map((channelId) => ({
          productId,
          channelId,
          isVisible: options.isVisible ?? true,
          isFeatured: options.isFeatured ?? null,
        }))
      );
    }

    // Remove old assignments
    if (toRemove.length > 0) {
      await this.db
        .delete(productChannelAssignments)
        .where(
          and(
            eq(productChannelAssignments.productId, productId),
            inArray(productChannelAssignments.channelId, toRemove)
          )
        );
    }

    // Sync Meilisearch — add to new channels, remove from old
    if (toAdd.length > 0) {
      Promise.allSettled(
        toAdd.map((cid) => this.syncProductToChannel(productId, cid))
      ).catch(() => {});
    }
    if (toRemove.length > 0) {
      Promise.allSettled(
        toRemove.map((cid) => removeFromMeili(cid, productId))
      ).catch(() => {});
    }

    return {
      added: toAdd.length,
      removed: toRemove.length,
    };
  }

  /**
   * Validate that a product exists
   */
  private async validateProduct(productId: number): Promise<void> {
    const [product] = await this.db
      .select({ id: products.id })
      .from(products)
      .where(and(eq(products.id, productId), eq(products.isDeleted, false)))
      .limit(1);

    if (!product) {
      throw new NotFoundError("Product", productId);
    }
  }

  // ── Meilisearch sync helpers ─────────────────────────────────────────

  /**
   * Build and index a single product into a channel's Meilisearch index.
   */
  private async syncProductToChannel(productId: number, channelId: number): Promise<void> {
    try {
      const doc = await buildProductDocument(productId);
      if (!doc) return;
      await ensureProductIndex(channelId);
      await indexProduct(channelId, doc);
    } catch (err) {
      console.error(`[ChannelAssignment] Meilisearch sync failed for product ${productId} channel ${channelId}:`, (err as Error).message);
    }
  }

  /**
   * Sync multiple products to a channel's Meilisearch index.
   */
  private async syncProductsToChannel(productIds: number[], channelId: number): Promise<void> {
    try {
      const { buildProductDocumentsBatch, indexProductsBatch } = await import("../../search");
      const docs = await buildProductDocumentsBatch(productIds);
      if (docs.size === 0) return;
      await ensureProductIndex(channelId);
      await indexProductsBatch(channelId, [...docs.values()]);
    } catch (err) {
      console.error(`[ChannelAssignment] Meilisearch batch sync failed for channel ${channelId}:`, (err as Error).message);
    }
  }

  /**
   * Validate that a channel exists
   */
  private async validateChannel(channelId: number): Promise<void> {
    const [channel] = await this.db
      .select({ id: channels.id })
      .from(channels)
      .where(eq(channels.id, channelId))
      .limit(1);

    if (!channel) {
      throw new NotFoundError("Channel", channelId);
    }
  }
}

export const productChannelAssignmentService = new ProductChannelAssignmentServiceClass();
