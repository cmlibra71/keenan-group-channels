import { eq, and } from "drizzle-orm";
import { PgColumn } from "drizzle-orm/pg-core";
import { webhooks, webhookEvents } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { NotFoundError, BadRequestError } from "../../errors";
import { transformRow } from "../../transforms";

/**
 * Service for managing webhook events (read-only).
 *
 * Webhook events are created by the system when webhooks fire,
 * and should not be manually created/updated/deleted via the API.
 */
class WebhookEventServiceClass extends NestedService<typeof webhooks, typeof webhookEvents> {
  constructor() {
    super(webhooks, webhookEvents, {
      resourceName: "Webhook Event",
      parentResourceName: "Webhook",
      defaultSort: "id",
      sortColumns: {
        id: webhookEvents.id,
        status: webhookEvents.status,
        created_at: webhookEvents.createdAt,
      },
      filterColumns: {
        status: webhookEvents.status,
        scope: webhookEvents.scope,
      },
      allowedFilters: ["status", "scope"],
      timestamps: {
        created: "createdAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return webhooks.id;
  }

  protected getParentForeignKey(): PgColumn {
    return webhookEvents.webhookId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "webhookId";
  }

  // Override create/update/delete to prevent modifications
  // Only list and getById are allowed (inherited from NestedService)

  /**
   * Retry a failed webhook event by resetting its status to "pending".
   * Cannot retry successful events or events that have exceeded max attempts.
   */
  async retryEvent(
    webhookId: number,
    eventId: number
  ): Promise<Record<string, unknown>> {
    // Check webhook exists
    const [webhook] = await this.db
      .select()
      .from(webhooks)
      .where(eq(webhooks.id, webhookId))
      .limit(1);

    if (!webhook) {
      throw new NotFoundError("Webhook", webhookId);
    }

    // Check event exists and belongs to this webhook
    const [event] = await this.db
      .select()
      .from(webhookEvents)
      .where(
        and(
          eq(webhookEvents.id, eventId),
          eq(webhookEvents.webhookId, webhookId)
        )
      )
      .limit(1);

    if (!event) {
      throw new NotFoundError("Webhook Event", eventId);
    }

    if ((event as Record<string, unknown>).status === "success") {
      throw new BadRequestError("Cannot retry a successful webhook event.");
    }

    const maxAttempts = ((event as Record<string, unknown>).maxAttempts as number) ?? 5;
    const attempts = ((event as Record<string, unknown>).attempts as number) ?? 0;
    if (attempts >= maxAttempts) {
      throw new BadRequestError(
        `Maximum retry attempts (${maxAttempts}) reached for this event.`
      );
    }

    // Reset event for retry
    const [updatedEvent] = await this.db
      .update(webhookEvents)
      .set({
        status: "pending",
        nextRetryAt: new Date(),
      })
      .where(eq(webhookEvents.id, eventId))
      .returning();

    return transformRow(updatedEvent as Record<string, unknown>);
  }
}

export const webhookEventService = new WebhookEventServiceClass();
