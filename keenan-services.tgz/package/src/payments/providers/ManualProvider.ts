import type {
  PaymentProvider,
  PaymentResult,
  PaymentDetails,
  CredentialValidationResult,
} from "../types";

/**
 * Manual / offline payment provider.
 *
 * No external calls — generates internal transaction IDs.
 * Used for invoices, bank transfers, cash, cheque, etc.
 */
export class ManualProvider implements PaymentProvider {
  readonly providerName = "manual";

  private generateId(): string {
    return `manual_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  }

  async validateCredentials(): Promise<CredentialValidationResult> {
    return { valid: true, message: "Manual gateway requires no credentials." };
  }

  async authorize(
    amount: string,
    currencyCode: string,
    details: PaymentDetails
  ): Promise<PaymentResult> {
    return {
      success: true,
      gateway_transaction_id: this.generateId(),
      status: "authorized",
      amount,
      currency_code: currencyCode,
      gateway_response: {
        provider: "manual",
        description: details.description || "Manual authorization",
      },
    };
  }

  async capture(transactionId: string, amount?: string): Promise<PaymentResult> {
    return {
      success: true,
      gateway_transaction_id: transactionId,
      status: "captured",
      amount: amount || "0",
      currency_code: "",
      gateway_response: {
        provider: "manual",
        original_transaction: transactionId,
      },
    };
  }

  async charge(
    amount: string,
    currencyCode: string,
    details: PaymentDetails
  ): Promise<PaymentResult> {
    return {
      success: true,
      gateway_transaction_id: this.generateId(),
      status: "captured",
      amount,
      currency_code: currencyCode,
      gateway_response: {
        provider: "manual",
        description: details.description || "Manual payment",
      },
    };
  }

  async refund(transactionId: string, amount?: string): Promise<PaymentResult> {
    return {
      success: true,
      gateway_transaction_id: this.generateId(),
      status: "refunded",
      amount: amount || "0",
      currency_code: "",
      gateway_response: {
        provider: "manual",
        original_transaction: transactionId,
      },
    };
  }

  async void(transactionId: string): Promise<PaymentResult> {
    return {
      success: true,
      gateway_transaction_id: transactionId,
      status: "voided",
      amount: "0",
      currency_code: "",
      gateway_response: {
        provider: "manual",
        original_transaction: transactionId,
      },
    };
  }
}
