import { PgColumn } from "drizzle-orm/pg-core";
import { products, productVideos } from "../../schema";
import { NestedService } from "../../base/NestedService";

/**
 * Service for managing product videos.
 */
class ProductVideoServiceClass extends NestedService<typeof products, typeof productVideos> {
  constructor() {
    super(products, productVideos, {
      resourceName: "Video",
      parentResourceName: "Product",
      defaultSort: "sort_order",
      sortColumns: {
        id: productVideos.id,
        sort_order: productVideos.sortOrder,
        created_at: productVideos.createdAt,
      },
      filterColumns: {
        type: productVideos.type,
      },
      allowedFilters: ["type"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return products.id;
  }

  protected getParentForeignKey(): PgColumn {
    return productVideos.productId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "productId";
  }
}

export const productVideoService = new ProductVideoServiceClass();
