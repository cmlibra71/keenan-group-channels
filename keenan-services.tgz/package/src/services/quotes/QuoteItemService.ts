import { eq, and } from "drizzle-orm";
import { PgColumn } from "drizzle-orm/pg-core";
import { quotes, quoteItems, products, productVariants } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { ForeignKeyValidation, UniqueConstraint } from "../../base/types";

/**
 * Service for managing quote items (nested under quotes).
 */
class QuoteItemServiceClass extends NestedService<typeof quotes, typeof quoteItems> {
  constructor() {
    super(quotes, quoteItems, {
      resourceName: "Quote Item",
      parentResourceName: "Quote",
      defaultSort: "id",
      sortColumns: {
        id: quoteItems.id,
        created_at: quoteItems.createdAt,
        updated_at: quoteItems.updatedAt,
      },
      filterColumns: {
        product_id: quoteItems.productId,
        variant_id: quoteItems.variantId,
      },
      allowedFilters: ["product_id", "variant_id"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return quotes.id;
  }

  protected getParentForeignKey(): PgColumn {
    return quoteItems.quoteId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "quoteId";
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: products,
        column: products.id,
        resourceName: "Product",
        fieldName: "productId",
      },
      {
        table: productVariants,
        column: productVariants.id,
        resourceName: "Variant",
        fieldName: "variantId",
        optional: true,
      },
    ];
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [
          { column: quoteItems.quoteId, fieldName: "quoteId" },
          { column: quoteItems.productId, fieldName: "productId" },
          { column: quoteItems.variantId, fieldName: "variantId" },
        ],
        message: "This product/variant is already in the quote.",
        composite: true,
      },
    ];
  }

  protected async beforeCreate(data: Record<string, unknown>): Promise<Record<string, unknown>> {
    const quantity = (data.quantity as number) || 1;
    const listPrice = parseFloat((data.listPrice as string) || "0");
    const salePrice = data.salePrice ? parseFloat(data.salePrice as string) : null;

    data.extendedListPrice = String(listPrice * quantity);
    data.extendedSalePrice = salePrice ? String(salePrice * quantity) : null;

    return data;
  }

  protected async afterCreate(result: Record<string, unknown>): Promise<void> {
    const quoteId = result.quoteId as number;
    await this.recalculateQuoteTotals(quoteId);
  }

  protected async beforeUpdate(
    data: Record<string, unknown>,
    existing: Record<string, unknown>
  ): Promise<Record<string, unknown>> {
    const quantity = (data.quantity as number) ?? (existing.quantity as number);
    const listPrice = data.listPrice ?? existing.listPrice;
    const salePrice = data.salePrice !== undefined ? data.salePrice : existing.salePrice;

    if (listPrice) {
      const listPriceNum = parseFloat(listPrice as string);
      data.extendedListPrice = String(listPriceNum * quantity);
    }

    if (salePrice) {
      const salePriceNum = parseFloat(salePrice as string);
      data.extendedSalePrice = String(salePriceNum * quantity);
    } else if (data.salePrice === null) {
      data.extendedSalePrice = null;
    }

    return data;
  }

  protected async afterUpdate(
    result: Record<string, unknown>,
    _previous: Record<string, unknown>
  ): Promise<void> {
    const quoteId = result.quoteId as number;
    await this.recalculateQuoteTotals(quoteId);
  }

  protected async afterDelete(_id: number, deleted: Record<string, unknown>): Promise<void> {
    const quoteId = deleted.quoteId as number;
    await this.recalculateQuoteTotals(quoteId);
  }

  // ── Storefront convenience methods ──────────────────────────────────

  /**
   * Find an existing quote item by product and optional variant.
   */
  async findByProductVariant(quoteId: number, productId: number, variantId?: number | null) {
    const conditions = [
      eq(quoteItems.quoteId, quoteId),
      eq(quoteItems.productId, productId),
    ];
    if (variantId) {
      conditions.push(eq(quoteItems.variantId, variantId));
    }

    const [item] = await this.db
      .select()
      .from(quoteItems)
      .where(and(...conditions))
      .limit(1);

    return item || null;
  }

  /**
   * Recalculate quote totals based on all items.
   */
  private async recalculateQuoteTotals(quoteId: number): Promise<void> {
    const items = await this.db
      .select({
        extendedListPrice: quoteItems.extendedListPrice,
        extendedSalePrice: quoteItems.extendedSalePrice,
      })
      .from(quoteItems)
      .where(eq(quoteItems.quoteId, quoteId));

    let baseAmount = 0;
    let discountAmount = 0;

    for (const item of items) {
      const listTotal = parseFloat(item.extendedListPrice ?? "0");
      const saleTotal = item.extendedSalePrice
        ? parseFloat(item.extendedSalePrice)
        : listTotal;
      baseAmount += saleTotal;
    }

    const quoteAmount = baseAmount - discountAmount;

    await this.db
      .update(quotes)
      .set({
        baseAmount: String(baseAmount),
        discountAmount: String(discountAmount),
        quoteAmount: String(quoteAmount),
        updatedAt: new Date(),
      })
      .where(eq(quotes.id, quoteId));
  }
}

export const quoteItemService = new QuoteItemServiceClass();
