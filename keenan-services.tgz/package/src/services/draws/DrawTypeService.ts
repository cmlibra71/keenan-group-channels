import { eq, and } from "drizzle-orm";
import { drawTypes, channels } from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation, UniqueConstraint } from "../../base/types";

/**
 * Service for managing draw type categories per channel.
 */
class DrawTypeServiceClass extends BaseService<typeof drawTypes> {
  constructor() {
    super(drawTypes, {
      resourceName: "Draw Type",
      defaultSort: "sort_order",
      sortColumns: {
        id: drawTypes.id,
        name: drawTypes.name,
        sort_order: drawTypes.sortOrder,
        created_at: drawTypes.createdAt,
      },
      filterColumns: {
        channel_id: drawTypes.channelId,
        is_active: drawTypes.isActive,
        frequency: drawTypes.frequency,
      },
      allowedFilters: ["channel_id", "is_active", "frequency"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: channels,
        column: channels.id,
        resourceName: "Channel",
        fieldName: "channelId",
      },
    ];
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [
          { column: drawTypes.channelId, fieldName: "channelId" },
          { column: drawTypes.slug, fieldName: "slug" },
        ],
        message: "A draw type with this slug already exists for this channel.",
        composite: true,
      },
    ];
  }

  /**
   * List active draw types for a channel.
   */
  async listActiveForChannel(channelId: number) {
    return this.db
      .select()
      .from(drawTypes)
      .where(
        and(
          eq(drawTypes.channelId, channelId),
          eq(drawTypes.isActive, true)
        )
      )
      .orderBy(drawTypes.sortOrder);
  }
}

export const drawTypeService = new DrawTypeServiceClass();
