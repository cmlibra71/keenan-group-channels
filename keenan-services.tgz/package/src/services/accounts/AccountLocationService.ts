import { PgColumn } from "drizzle-orm/pg-core";
import { accounts, accountLocations } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { UniqueConstraint } from "../../base/types";

/**
 * Service for managing account locations (divisions/branches).
 */
class AccountLocationServiceClass extends NestedService<typeof accounts, typeof accountLocations> {
  constructor() {
    super(accounts, accountLocations, {
      resourceName: "Location",
      parentResourceName: "Account",
      defaultSort: "id",
      sortColumns: {
        id: accountLocations.id,
        name: accountLocations.name,
        code: accountLocations.code,
        created_at: accountLocations.createdAt,
      },
      filterColumns: {
        name: accountLocations.name,
        code: accountLocations.code,
        is_active: accountLocations.isActive,
      },
      allowedFilters: ["name", "code", "is_active"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return accounts.id;
  }

  protected getParentForeignKey(): PgColumn {
    return accountLocations.accountId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "accountId";
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [
          { column: accountLocations.accountId, fieldName: "accountId" },
          { column: accountLocations.code, fieldName: "code" },
        ],
        message: "A location with this code already exists for this account.",
        composite: true,
      },
    ];
  }
}

export const accountLocationService = new AccountLocationServiceClass();
