import { eq } from "drizzle-orm";
import { PgColumn } from "drizzle-orm/pg-core";
import { accounts, accountAddresses, accountLocations } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { ForeignKeyValidation } from "../../base/types";

/**
 * Service for managing account addresses.
 */
class AccountAddressServiceClass extends NestedService<typeof accounts, typeof accountAddresses> {
  constructor() {
    super(accounts, accountAddresses, {
      resourceName: "Address",
      parentResourceName: "Account",
      defaultSort: "id",
      sortColumns: {
        id: accountAddresses.id,
        city: accountAddresses.city,
        country: accountAddresses.country,
        created_at: accountAddresses.createdAt,
      },
      filterColumns: {
        address_type: accountAddresses.addressType,
        is_default_billing: accountAddresses.isDefaultBilling,
        is_default_shipping: accountAddresses.isDefaultShipping,
        country: accountAddresses.country,
        city: accountAddresses.city,
        location_id: accountAddresses.locationId,
      },
      allowedFilters: [
        "address_type",
        "is_default_billing",
        "is_default_shipping",
        "country",
        "city",
        "location_id",
      ],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- dual drizzle-orm versions
    return accounts.id as any;
  }

  protected getParentForeignKey(): PgColumn {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- dual drizzle-orm versions
    return accountAddresses.accountId as any;
  }

  protected getParentForeignKeyFieldName(): string {
    return "accountId";
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: accountLocations,
        column: accountLocations.id,
        resourceName: "Location",
        fieldName: "locationId",
        optional: true,
      },
    ];
  }

  /**
   * Handle default billing/shipping flags
   */
  protected async beforeCreate(data: Record<string, unknown>): Promise<Record<string, unknown>> {
    const accountId = data.accountId as number;

    if (data.isDefaultBilling) {
      await this.db
        .update(accountAddresses)
        .set({ isDefaultBilling: false })
        .where(eq(accountAddresses.accountId, accountId));
    }

    if (data.isDefaultShipping) {
      await this.db
        .update(accountAddresses)
        .set({ isDefaultShipping: false })
        .where(eq(accountAddresses.accountId, accountId));
    }

    return data;
  }

  /**
   * Handle default billing/shipping flags on update
   */
  protected async beforeUpdate(
    data: Record<string, unknown>,
    existing: Record<string, unknown>
  ): Promise<Record<string, unknown>> {
    const accountId = existing.accountId as number;

    if (data.isDefaultBilling === true) {
      await this.db
        .update(accountAddresses)
        .set({ isDefaultBilling: false })
        .where(eq(accountAddresses.accountId, accountId));
    }

    if (data.isDefaultShipping === true) {
      await this.db
        .update(accountAddresses)
        .set({ isDefaultShipping: false })
        .where(eq(accountAddresses.accountId, accountId));
    }

    return data;
  }
}

export const accountAddressService = new AccountAddressServiceClass();
