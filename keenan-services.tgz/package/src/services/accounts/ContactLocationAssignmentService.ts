import { eq, and } from "drizzle-orm";
import { getCommerceDb } from "../../db";
import {
  contactLocationAssignments,
  contacts,
  accountLocations,
} from "../../schema";
import { NotFoundError, ConflictError, ValidationError } from "../../errors";
import { transformRow, transformRows } from "../../transforms";

/**
 * Service for managing contact-location assignments.
 * Handles the join table between contacts and account locations.
 */
class ContactLocationAssignmentServiceClass {
  private get db() {
    return getCommerceDb();
  }

  /**
   * Get all location assignments for a contact
   */
  async getLocationsForContact(contactId: number): Promise<Record<string, unknown>[]> {
    await this.validateContact(contactId);

    const results = await this.db
      .select({
        id: contactLocationAssignments.id,
        contactId: contactLocationAssignments.contactId,
        locationId: contactLocationAssignments.locationId,
        locationName: accountLocations.name,
        locationCode: accountLocations.code,
        isDefault: contactLocationAssignments.isDefault,
        createdAt: contactLocationAssignments.createdAt,
      })
      .from(contactLocationAssignments)
      .innerJoin(accountLocations, eq(contactLocationAssignments.locationId, accountLocations.id))
      .where(eq(contactLocationAssignments.contactId, contactId));

    return transformRows(results as unknown as Record<string, unknown>[]);
  }

  /**
   * Get all contacts for a location
   */
  async getContactsForLocation(locationId: number): Promise<Record<string, unknown>[]> {
    await this.validateLocation(locationId);

    const results = await this.db
      .select({
        id: contactLocationAssignments.id,
        contactId: contactLocationAssignments.contactId,
        locationId: contactLocationAssignments.locationId,
        contactEmail: contacts.email,
        contactFirstName: contacts.firstName,
        contactLastName: contacts.lastName,
        isDefault: contactLocationAssignments.isDefault,
        createdAt: contactLocationAssignments.createdAt,
      })
      .from(contactLocationAssignments)
      .innerJoin(contacts, eq(contactLocationAssignments.contactId, contacts.id))
      .where(eq(contactLocationAssignments.locationId, locationId));

    return transformRows(results as unknown as Record<string, unknown>[]);
  }

  /**
   * Assign a contact to a location
   */
  async assign(
    contactId: number,
    locationId: number,
    options: { isDefault?: boolean; created_at?: string } = {}
  ): Promise<Record<string, unknown>> {
    const contact = await this.validateContact(contactId);
    const location = await this.validateLocation(locationId);

    // Verify both belong to the same account
    if (contact.accountId !== location.accountId) {
      throw new ValidationError("Contact and location must belong to the same account.", { accountId: "Contact and location must belong to the same account" });
    }

    const existing = await this.getAssignment(contactId, locationId);
    if (existing) {
      throw new ConflictError(`Contact ${contactId} is already assigned to location ${locationId}.`);
    }

    const [result] = await this.db
      .insert(contactLocationAssignments)
      .values({
        contactId,
        locationId,
        isDefault: options.isDefault ?? false,
        createdAt: options.created_at ? new Date(options.created_at) : undefined,
      })
      .returning();

    return transformRow(result as Record<string, unknown>);
  }

  /**
   * Remove a contact from a location
   */
  async remove(contactId: number, locationId: number): Promise<void> {
    const existing = await this.getAssignment(contactId, locationId);
    if (!existing) {
      throw new NotFoundError("Assignment", `${contactId}-${locationId}`);
    }

    await this.db
      .delete(contactLocationAssignments)
      .where(
        and(
          eq(contactLocationAssignments.contactId, contactId),
          eq(contactLocationAssignments.locationId, locationId)
        )
      );
  }

  /**
   * Set all location assignments for a contact (replace)
   */
  async setLocationsForContact(
    contactId: number,
    locationIds: number[]
  ): Promise<Record<string, unknown>[]> {
    const contact = await this.validateContact(contactId);

    // Validate all locations exist and belong to same account
    for (const locationId of locationIds) {
      const location = await this.validateLocation(locationId);
      if (location.accountId !== contact.accountId) {
        throw new ValidationError(
          `Location ${locationId} does not belong to the same account as contact ${contactId}.`,
          { locationId: "Location does not belong to the same account" }
        );
      }
    }

    // Delete existing assignments
    await this.db
      .delete(contactLocationAssignments)
      .where(eq(contactLocationAssignments.contactId, contactId));

    // Insert new assignments
    if (locationIds.length > 0) {
      await this.db
        .insert(contactLocationAssignments)
        .values(locationIds.map((locationId, i) => ({
          contactId,
          locationId,
          isDefault: i === 0,
        })));
    }

    return this.getLocationsForContact(contactId);
  }

  private async getAssignment(contactId: number, locationId: number) {
    const [result] = await this.db
      .select()
      .from(contactLocationAssignments)
      .where(
        and(
          eq(contactLocationAssignments.contactId, contactId),
          eq(contactLocationAssignments.locationId, locationId)
        )
      )
      .limit(1);

    return result || null;
  }

  private async validateContact(contactId: number) {
    const [contact] = await this.db
      .select({ id: contacts.id, accountId: contacts.accountId })
      .from(contacts)
      .where(eq(contacts.id, contactId))
      .limit(1);

    if (!contact) {
      throw new NotFoundError("Contact", contactId);
    }
    return contact;
  }

  private async validateLocation(locationId: number) {
    const [location] = await this.db
      .select({ id: accountLocations.id, accountId: accountLocations.accountId })
      .from(accountLocations)
      .where(eq(accountLocations.id, locationId))
      .limit(1);

    if (!location) {
      throw new NotFoundError("Location", locationId);
    }
    return location;
  }
}

export const contactLocationAssignmentService = new ContactLocationAssignmentServiceClass();
