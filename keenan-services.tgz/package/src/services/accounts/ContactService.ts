import { PgColumn } from "drizzle-orm/pg-core";
import bcrypt from "bcryptjs";
import { accounts, contacts } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { UniqueConstraint } from "../../base/types";

/**
 * Service for managing contacts within accounts.
 */
class ContactServiceClass extends NestedService<typeof accounts, typeof contacts> {
  constructor() {
    super(accounts, contacts, {
      resourceName: "Contact",
      parentResourceName: "Account",
      defaultSort: "id",
      sortColumns: {
        id: contacts.id,
        email: contacts.email,
        first_name: contacts.firstName,
        last_name: contacts.lastName,
        created_at: contacts.createdAt,
        updated_at: contacts.updatedAt,
      },
      filterColumns: {
        email: contacts.email,
        is_active: contacts.isActive,
        role_id: contacts.roleId,
        is_primary: contacts.isPrimary,
      },
      allowedFilters: ["email", "is_active", "role_id", "is_primary"],
    });
  }

  protected getParentIdColumn(): PgColumn {
    return accounts.id;
  }

  protected getParentForeignKey(): PgColumn {
    return contacts.accountId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "accountId";
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [
          { column: contacts.accountId, fieldName: "accountId" },
          { column: contacts.email, fieldName: "email" },
        ],
        message: "A contact with this email already exists for this account.",
        composite: true,
      },
    ];
  }

  /**
   * Hash password before create
   */
  protected async beforeCreate(data: Record<string, unknown>): Promise<Record<string, unknown>> {
    if (data.passwordHash && typeof data.passwordHash === "string" && !data.passwordHash.startsWith("$2")) {
      data.passwordHash = await bcrypt.hash(data.passwordHash, 12);
    }
    return data;
  }

  /**
   * Hash password before update
   */
  protected async beforeUpdate(
    data: Record<string, unknown>,
    _existing: Record<string, unknown>
  ): Promise<Record<string, unknown>> {
    if (data.passwordHash && typeof data.passwordHash === "string" && !data.passwordHash.startsWith("$2")) {
      data.passwordHash = await bcrypt.hash(data.passwordHash, 12);
    }
    return data;
  }
}

export const contactService = new ContactServiceClass();
