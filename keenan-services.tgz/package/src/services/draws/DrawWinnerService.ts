import { eq } from "drizzle-orm";
import { PgColumn } from "drizzle-orm/pg-core";
import { draws, drawWinners, drawEntries, customers, prizes } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { ForeignKeyValidation } from "../../base/types";

/**
 * Service for managing draw winners (nested under draws).
 */
class DrawWinnerServiceClass extends NestedService<typeof draws, typeof drawWinners> {
  constructor() {
    super(draws, drawWinners, {
      resourceName: "Draw Winner",
      parentResourceName: "Draw",
      defaultSort: "id",
      sortColumns: {
        id: drawWinners.id,
        status: drawWinners.status,
        created_at: drawWinners.createdAt,
      },
      filterColumns: {
        customer_id: drawWinners.customerId,
        prize_id: drawWinners.prizeId,
        status: drawWinners.status,
      },
      allowedFilters: ["customer_id", "prize_id", "status"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return draws.id;
  }

  protected getParentForeignKey(): PgColumn {
    return drawWinners.drawId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "drawId";
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: drawEntries,
        column: drawEntries.id,
        resourceName: "Draw Entry",
        fieldName: "entryId",
      },
      {
        table: customers,
        column: customers.id,
        resourceName: "Customer",
        fieldName: "customerId",
      },
      {
        table: prizes,
        column: prizes.id,
        resourceName: "Prize",
        fieldName: "prizeId",
        optional: true,
      },
    ];
  }

  /**
   * Transition winner to notified status.
   */
  async markNotified(drawId: number, winnerId: number) {
    const [updated] = await this.db
      .update(drawWinners)
      .set({
        status: "notified",
        notifiedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(drawWinners.id, winnerId))
      .returning();
    return updated || null;
  }

  /**
   * Transition winner to claimed status.
   */
  async markClaimed(drawId: number, winnerId: number) {
    const [updated] = await this.db
      .update(drawWinners)
      .set({
        status: "claimed",
        claimedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(drawWinners.id, winnerId))
      .returning();
    return updated || null;
  }

  /**
   * Transition winner to fulfilled status.
   */
  async markFulfilled(drawId: number, winnerId: number) {
    const [updated] = await this.db
      .update(drawWinners)
      .set({
        status: "fulfilled",
        fulfilledAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(drawWinners.id, winnerId))
      .returning();
    return updated || null;
  }

  /**
   * Forfeit a winner (unclaimed after deadline).
   */
  async markForfeited(drawId: number, winnerId: number) {
    const [updated] = await this.db
      .update(drawWinners)
      .set({
        status: "forfeited",
        updatedAt: new Date(),
      })
      .where(eq(drawWinners.id, winnerId))
      .returning();
    return updated || null;
  }
}

export const drawWinnerService = new DrawWinnerServiceClass();
