import crypto from "crypto";
import type sharp from "sharp";
import {
  S3Client,
  PutObjectCommand,
  HeadObjectCommand,
} from "@aws-sdk/client-s3";

// Lazy-load sharp to avoid webpack bundling issues with native binaries
let _sharp: typeof sharp | null = null;
async function getSharp(): Promise<typeof sharp> {
  if (!_sharp) {
    _sharp = (await import("sharp")).default;
  }
  return _sharp;
}

/** Standard image widths generated for responsive images */
export const IMAGE_SIZES = [100, 200, 400, 600, 800, 1200, 1600] as const;

const DEFAULT_BUCKET = "keenan-group-images";
const DEFAULT_PREFIX = "optimized";
const DEFAULT_QUALITY = 80;
const DEFAULT_REGION = "ap-southeast-2";

export interface OptimizeOptions {
  bucket?: string;
  prefix?: string;
  quality?: number;
  sizes?: readonly number[];
  s3Region?: string;
}

interface OptimizeResult {
  url: string;
  sizes: number[];
  totalBytes: number;
  skipped: number;
}

function getS3(region: string): S3Client {
  return new S3Client({ region });
}

/**
 * Compute the S3 cache key for an optimized image.
 * Matches the cache key scheme used by the storefront /api/image route.
 */
export function getCacheKey(
  url: string,
  width: number,
  quality: number = DEFAULT_QUALITY,
  prefix: string = DEFAULT_PREFIX
): string {
  const hash = crypto
    .createHash("sha256")
    .update(url)
    .digest("hex")
    .slice(0, 16);
  return `${prefix}/${width}w-q${quality}/${hash}.webp`;
}

/**
 * Get the public S3 URL for a cached optimized image.
 */
export function getOptimizedUrl(
  sourceUrl: string,
  width: number,
  quality: number = DEFAULT_QUALITY,
  options?: { bucket?: string; prefix?: string; region?: string }
): string {
  const bucket = options?.bucket ?? DEFAULT_BUCKET;
  const region = options?.region ?? DEFAULT_REGION;
  const prefix = options?.prefix ?? DEFAULT_PREFIX;
  const key = getCacheKey(sourceUrl, width, quality, prefix);
  return `https://${bucket}.s3.${region}.amazonaws.com/${key}`;
}

/**
 * Check if a cached image already exists in S3.
 */
export async function checkCacheExists(
  url: string,
  width: number,
  quality: number = DEFAULT_QUALITY,
  options?: { bucket?: string; prefix?: string; s3Region?: string }
): Promise<boolean> {
  const bucket = options?.bucket ?? DEFAULT_BUCKET;
  const prefix = options?.prefix ?? DEFAULT_PREFIX;
  const region = options?.s3Region ?? DEFAULT_REGION;
  const key = getCacheKey(url, width, quality, prefix);
  const s3 = getS3(region);

  try {
    await s3.send(new HeadObjectCommand({ Bucket: bucket, Key: key }));
    return true;
  } catch {
    return false;
  }
}

/**
 * Generate all optimized sizes for a source image URL.
 * Fetches the original once, resizes in parallel, uploads to S3.
 * Skips sizes larger than the original width (no upscaling).
 */
export async function generateOptimizedSizes(
  sourceUrl: string,
  options?: OptimizeOptions & { skipExisting?: boolean }
): Promise<OptimizeResult> {
  const bucket = options?.bucket ?? DEFAULT_BUCKET;
  const prefix = options?.prefix ?? DEFAULT_PREFIX;
  const quality = options?.quality ?? DEFAULT_QUALITY;
  const sizes = options?.sizes ?? IMAGE_SIZES;
  const region = options?.s3Region ?? DEFAULT_REGION;
  const skipExisting = options?.skipExisting ?? false;

  const s3 = getS3(region);
  const sharpLib = await getSharp();

  // Fetch original image
  const res = await fetch(sourceUrl);
  if (!res.ok) {
    throw new Error(
      `Failed to fetch image ${sourceUrl}: ${res.status} ${res.statusText}`
    );
  }
  const originalBuffer = Buffer.from(await res.arrayBuffer());

  // Get original dimensions to skip upscaling
  const metadata = await sharpLib(originalBuffer).metadata();
  const originalWidth = metadata.width ?? Infinity;

  // Filter sizes: no upscaling
  const applicableSizes = sizes.filter((w) => w <= originalWidth);

  let totalBytes = 0;
  let skipped = 0;
  const generatedSizes: number[] = [];

  await Promise.all(
    applicableSizes.map(async (width) => {
      const key = getCacheKey(sourceUrl, width, quality, prefix);

      // Optionally skip if already cached
      if (skipExisting) {
        try {
          await s3.send(new HeadObjectCommand({ Bucket: bucket, Key: key }));
          skipped++;
          return;
        } catch {
          // Not cached, proceed
        }
      }

      const optimized = await sharpLib(originalBuffer)
        .resize(width, undefined, { withoutEnlargement: true })
        .webp({ quality })
        .toBuffer();

      await s3.send(
        new PutObjectCommand({
          Bucket: bucket,
          Key: key,
          Body: optimized,
          ContentType: "image/webp",
          CacheControl: "public, max-age=31536000, immutable",
        })
      );

      totalBytes += optimized.length;
      generatedSizes.push(width);
    })
  );

  return {
    url: sourceUrl,
    sizes: generatedSizes.sort((a, b) => a - b),
    totalBytes,
    skipped,
  };
}
