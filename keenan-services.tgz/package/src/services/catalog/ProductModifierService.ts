import { PgColumn } from "drizzle-orm/pg-core";
import { products, productModifiers, productModifierValues } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { IncludeConfig } from "../../base/types";

/**
 * Service for managing product modifiers.
 */
class ProductModifierServiceClass extends NestedService<typeof products, typeof productModifiers> {
  constructor() {
    super(products, productModifiers, {
      resourceName: "Modifier",
      parentResourceName: "Product",
      defaultSort: "id",
      sortColumns: {
        id: productModifiers.id,
        sort_order: productModifiers.sortOrder,
        name: productModifiers.name,
      },
      filterColumns: {
        name: productModifiers.name,
        type: productModifiers.type,
        is_required: productModifiers.isRequired,
      },
      allowedFilters: ["name", "type", "is_required"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return products.id;
  }

  protected getParentForeignKey(): PgColumn {
    return productModifiers.productId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "productId";
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "values",
        table: productModifierValues,
        foreignKey: productModifierValues.modifierId,
      },
    ];
  }
}

export const productModifierService = new ProductModifierServiceClass();
