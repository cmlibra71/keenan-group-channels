import { PgColumn } from "drizzle-orm/pg-core";
import { taxClasses, taxRates } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { ForeignKeyValidation } from "../../base/types";

/**
 * Service for managing tax rates within tax classes.
 *
 * Supports both nested operations (via parent tax class) and top-level
 * operations with tax_class_id as a required field.
 */
class TaxRateServiceClass extends NestedService<typeof taxClasses, typeof taxRates> {
  constructor() {
    super(taxClasses, taxRates, {
      resourceName: "Tax Rate",
      parentResourceName: "Tax Class",
      defaultSort: "id",
      sortColumns: {
        id: taxRates.id,
        name: taxRates.name,
        priority: taxRates.priority,
      },
      filterColumns: {
        tax_class_id: taxRates.taxClassId,
        country_code: taxRates.countryCode,
        state_code: taxRates.stateCode,
        enabled: taxRates.enabled,
      },
      allowedFilters: ["tax_class_id", "country_code", "state_code", "enabled"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return taxClasses.id;
  }

  protected getParentForeignKey(): PgColumn {
    return taxRates.taxClassId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "taxClassId";
  }

  /**
   * Validate tax_class_id exists when using top-level create/update.
   */
  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        fieldName: "taxClassId",
        table: taxClasses,
        column: taxClasses.id,
        resourceName: "Tax Class",
      },
    ];
  }
}

export const taxRateService = new TaxRateServiceClass();
