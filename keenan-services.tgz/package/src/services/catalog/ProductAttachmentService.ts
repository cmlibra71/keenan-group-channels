import { PgColumn } from "drizzle-orm/pg-core";
import { products, productAttachments } from "../../schema";
import { NestedService } from "../../base/NestedService";

/**
 * Service for managing product attachments (PDF spec sheets, documents, etc.).
 */
class ProductAttachmentServiceClass extends NestedService<typeof products, typeof productAttachments> {
  constructor() {
    super(products, productAttachments, {
      resourceName: "Attachment",
      parentResourceName: "Product",
      defaultSort: "sort_order",
      sortColumns: {
        id: productAttachments.id,
        sort_order: productAttachments.sortOrder,
        created_at: productAttachments.createdAt,
      },
      filterColumns: {
        file_type: productAttachments.fileType,
        label: productAttachments.label,
      },
      allowedFilters: ["file_type", "label"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return products.id;
  }

  protected getParentForeignKey(): PgColumn {
    return productAttachments.productId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "productId";
  }
}

export const productAttachmentService = new ProductAttachmentServiceClass();
