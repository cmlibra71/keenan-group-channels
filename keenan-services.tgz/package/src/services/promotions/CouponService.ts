import { PgColumn } from "drizzle-orm/pg-core";
import { promotions, coupons, couponRedemptions } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { UniqueConstraint, DependencyCheck, IncludeConfig } from "../../base/types";

/**
 * Service for managing coupons within promotions.
 */
class CouponServiceClass extends NestedService<typeof promotions, typeof coupons> {
  constructor() {
    super(promotions, coupons, {
      resourceName: "Coupon",
      parentResourceName: "Promotion",
      defaultSort: "id",
      sortColumns: {
        id: coupons.id,
        code: coupons.code,
        created_at: coupons.createdAt,
        updated_at: coupons.updatedAt,
      },
      filterColumns: {
        code: coupons.code,
      },
      allowedFilters: ["code"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return promotions.id;
  }

  protected getParentForeignKey(): PgColumn {
    return coupons.promotionId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "promotionId";
  }

  /**
   * Coupon code must be globally unique
   */
  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [{ column: coupons.code, fieldName: "code" }],
        message: "Coupon code already exists.",
      },
    ];
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: couponRedemptions,
        foreignKeyColumn: couponRedemptions.couponId,
        resourceName: "redemption",
        message: "Cannot delete coupon because it has {count} redemption(s) associated with it.",
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "redemptions",
        table: couponRedemptions,
        foreignKey: couponRedemptions.couponId,
      },
    ];
  }
}

export const couponService = new CouponServiceClass();
