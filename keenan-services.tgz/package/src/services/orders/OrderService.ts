import {
  orders,
  orderItems,
  orderShippingAddresses,
  channels,
  accounts,
  contacts,
  salesReps,
  shipments,
  orderTransactions,
  orderRefunds,
} from "../../schema";
import { BaseService } from "../../base/BaseService";
import {
  ForeignKeyValidation,
  DependencyCheck,
  IncludeConfig,
} from "../../base/types";

/**
 * Service for managing orders.
 */
class OrderServiceClass extends BaseService<typeof orders> {
  constructor() {
    super(orders, {
      resourceName: "Order",
      defaultSort: "id",
      sortColumns: {
        id: orders.id,
        order_number: orders.orderNumber,
        created_at: orders.createdAt,
        updated_at: orders.updatedAt,
        status: orders.status,
        approval_status: orders.approvalStatus,
      },
      filterColumns: {
        channel_id: orders.channelId,
        account_id: orders.accountId,
        contact_id: orders.contactId,
        sales_rep_id: orders.salesRepId,
        status: orders.status,
        payment_status: orders.paymentStatus,
        approval_status: orders.approvalStatus,
        order_number: orders.orderNumber,
        payment_method: orders.paymentMethod,
        external_id: orders.externalId,
        external_source: orders.externalSource,
      },
      allowedFilters: [
        "channel_id",
        "account_id",
        "contact_id",
        "sales_rep_id",
        "status",
        "payment_status",
        "approval_status",
        "order_number",
        "payment_method",
        "external_id",
        "external_source",
      ],
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: channels,
        column: channels.id,
        resourceName: "Channel",
        fieldName: "channelId",
        optional: false,
      },
      {
        table: accounts,
        column: accounts.id,
        resourceName: "Account",
        fieldName: "accountId",
        optional: true,
      },
      {
        table: contacts,
        column: contacts.id,
        resourceName: "Contact",
        fieldName: "contactId",
        optional: true,
      },
      {
        table: salesReps,
        column: salesReps.id,
        resourceName: "Sales Rep",
        fieldName: "salesRepId",
        optional: true,
      },
    ];
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: orderItems,
        foreignKeyColumn: orderItems.orderId,
        resourceName: "order item",
        message: "Cannot delete Order because it has {count} order item(s). Delete order items first.",
      },
      {
        table: shipments,
        foreignKeyColumn: shipments.orderId,
        resourceName: "shipment",
        message: "Cannot delete Order because it has {count} shipment(s). Delete shipments first.",
      },
      {
        table: orderTransactions,
        foreignKeyColumn: orderTransactions.orderId,
        resourceName: "transaction",
        message: "Cannot delete Order because it has {count} transaction(s) associated with it.",
      },
      {
        table: orderRefunds,
        foreignKeyColumn: orderRefunds.orderId,
        resourceName: "refund",
        message: "Cannot delete Order because it has {count} refund(s) associated with it.",
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "items",
        table: orderItems,
        foreignKey: orderItems.orderId,
      },
      {
        name: "shipping_addresses",
        table: orderShippingAddresses,
        foreignKey: orderShippingAddresses.orderId,
      },
      {
        name: "shipments",
        table: shipments,
        foreignKey: shipments.orderId,
      },
      {
        name: "transactions",
        table: orderTransactions,
        foreignKey: orderTransactions.orderId,
      },
      {
        name: "refunds",
        table: orderRefunds,
        foreignKey: orderRefunds.orderId,
      },
    ];
  }

  /**
   * Generate an order number if not provided
   */
  protected async beforeCreate(data: Record<string, unknown>): Promise<Record<string, unknown>> {
    if (!data.orderNumber) {
      const timestamp = Date.now().toString(36).toUpperCase();
      const random = Math.random().toString(36).substring(2, 6).toUpperCase();
      data.orderNumber = `ORD-${timestamp}-${random}`;
    }
    return data;
  }
}

export const orderService = new OrderServiceClass();
