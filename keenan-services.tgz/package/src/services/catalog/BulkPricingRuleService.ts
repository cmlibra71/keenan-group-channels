import { PgColumn } from "drizzle-orm/pg-core";
import { products, bulkPricingRules } from "../../schema";
import { ValidationError } from "../../errors";
import { NestedService } from "../../base/NestedService";

/**
 * Service for managing bulk pricing rules.
 */
class BulkPricingRuleServiceClass extends NestedService<typeof products, typeof bulkPricingRules> {
  constructor() {
    super(products, bulkPricingRules, {
      resourceName: "Bulk Pricing Rule",
      parentResourceName: "Product",
      defaultSort: "id",
      sortColumns: {
        id: bulkPricingRules.id,
        quantity_min: bulkPricingRules.quantityMin,
      },
      filterColumns: {
        type: bulkPricingRules.type,
      },
      allowedFilters: ["type"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return products.id;
  }

  protected getParentForeignKey(): PgColumn {
    return bulkPricingRules.productId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "productId";
  }

  protected async beforeCreate(data: Record<string, unknown>): Promise<Record<string, unknown>> {
    this.validateQuantityRange(data);
    return data;
  }

  protected async beforeUpdate(
    data: Record<string, unknown>,
    existing: Record<string, unknown>
  ): Promise<Record<string, unknown>> {
    const merged = {
      quantityMin: data.quantityMin ?? existing.quantityMin,
      quantityMax: data.quantityMax ?? existing.quantityMax,
    };
    this.validateQuantityRange(merged);
    return data;
  }

  private validateQuantityRange(data: Record<string, unknown>): void {
    const min = data.quantityMin as number | undefined;
    const max = data.quantityMax as number | undefined | null;
    if (min !== undefined && max !== undefined && max !== null && min >= max) {
      throw new ValidationError("Quantity range is invalid.", {
        quantity_max: "quantity_max must be greater than quantity_min.",
      });
    }
  }
}

export const bulkPricingRuleService = new BulkPricingRuleServiceClass();
