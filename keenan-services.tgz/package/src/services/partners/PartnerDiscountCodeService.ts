import { eq, and } from "drizzle-orm";
import { PgColumn } from "drizzle-orm/pg-core";
import { randomBytes } from "crypto";
import {
  partnerOffers,
  partnerDiscountCodes,
  subscriptions,
  customers,
  draws,
} from "../../schema";
import { NestedService } from "../../base/NestedService";
import { ForeignKeyValidation, UniqueConstraint } from "../../base/types";

/**
 * Service for managing partner discount codes (nested under partner offers).
 */
class PartnerDiscountCodeServiceClass extends NestedService<
  typeof partnerOffers,
  typeof partnerDiscountCodes
> {
  constructor() {
    super(partnerOffers, partnerDiscountCodes, {
      resourceName: "Partner Discount Code",
      parentResourceName: "Partner Offer",
      defaultSort: "id",
      sortColumns: {
        id: partnerDiscountCodes.id,
        status: partnerDiscountCodes.status,
        created_at: partnerDiscountCodes.createdAt,
      },
      filterColumns: {
        subscription_id: partnerDiscountCodes.subscriptionId,
        customer_id: partnerDiscountCodes.customerId,
        status: partnerDiscountCodes.status,
      },
      allowedFilters: ["subscription_id", "customer_id", "status"],
      timestamps: {
        created: "createdAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return partnerOffers.id;
  }

  protected getParentForeignKey(): PgColumn {
    return partnerDiscountCodes.partnerOfferId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "partnerOfferId";
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: subscriptions,
        column: subscriptions.id,
        resourceName: "Subscription",
        fieldName: "subscriptionId",
      },
      {
        table: customers,
        column: customers.id,
        resourceName: "Customer",
        fieldName: "customerId",
      },
    ];
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [
          { column: partnerDiscountCodes.partnerOfferId, fieldName: "partnerOfferId" },
          { column: partnerDiscountCodes.subscriptionId, fieldName: "subscriptionId" },
        ],
        message: "A discount code for this offer has already been generated for this subscription.",
        composite: true,
      },
    ];
  }

  /**
   * Generate a unique discount code for a subscriber.
   */
  async generateForSubscriber(offerId: number, subscriptionId: number, customerId: number) {
    const code = this.generateCode();
    return this.createForParent(offerId, {
      subscriptionId,
      customerId,
      code,
      status: "active",
    });
  }

  /**
   * Revoke all active codes for a subscription (when subscription ends).
   */
  async revokeForSubscription(subscriptionId: number) {
    return this.db
      .update(partnerDiscountCodes)
      .set({
        status: "revoked",
        revokedAt: new Date(),
      })
      .where(
        and(
          eq(partnerDiscountCodes.subscriptionId, subscriptionId),
          eq(partnerDiscountCodes.status, "active")
        )
      );
  }

  /**
   * Get all codes for a customer across all offers in a channel.
   */
  async getForCustomer(customerId: number, channelId: number) {
    return this.db
      .select({
        code: partnerDiscountCodes,
        offerTitle: partnerOffers.title,
        partnerName: partnerOffers.partnerName,
        partnerLogo: partnerOffers.partnerLogo,
        discountType: partnerOffers.discountType,
        discountValue: partnerOffers.discountValue,
        externalUrl: partnerOffers.externalUrl,
      })
      .from(partnerDiscountCodes)
      .innerJoin(
        partnerOffers,
        eq(partnerDiscountCodes.partnerOfferId, partnerOffers.id)
      )
      .where(
        and(
          eq(partnerDiscountCodes.customerId, customerId),
          eq(partnerOffers.channelId, channelId),
          eq(partnerDiscountCodes.status, "active")
        )
      );
  }

  /**
   * Generate a random alphanumeric discount code.
   */
  private generateCode(): string {
    return randomBytes(6).toString("hex").toUpperCase().slice(0, 10);
  }
}

export const partnerDiscountCodeService = new PartnerDiscountCodeServiceClass();
