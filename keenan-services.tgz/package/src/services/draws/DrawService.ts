import { eq, and, gte, desc, sql } from "drizzle-orm";
import {
  draws,
  drawTypes,
  drawEntries,
  drawWinners,
  channels,
} from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation, IncludeConfig, DependencyCheck } from "../../base/types";
import { BadRequestError } from "../../errors";

/**
 * Service for managing individual draw instances.
 */
class DrawServiceClass extends BaseService<typeof draws> {
  constructor() {
    super(draws, {
      resourceName: "Draw",
      defaultSort: "id",
      sortColumns: {
        id: draws.id,
        name: draws.name,
        status: draws.status,
        scheduled_at: draws.scheduledAt,
        created_at: draws.createdAt,
      },
      filterColumns: {
        channel_id: draws.channelId,
        draw_type_id: draws.drawTypeId,
        status: draws.status,
      },
      allowedFilters: ["channel_id", "draw_type_id", "status"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: channels,
        column: channels.id,
        resourceName: "Channel",
        fieldName: "channelId",
      },
      {
        table: drawTypes,
        column: drawTypes.id,
        resourceName: "Draw Type",
        fieldName: "drawTypeId",
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "entries",
        table: drawEntries,
        foreignKey: drawEntries.drawId,
      },
      {
        name: "winners",
        table: drawWinners,
        foreignKey: drawWinners.drawId,
      },
    ];
  }

  /**
   * Get upcoming draws for a channel (open or scheduled, with future deadline).
   */
  async getUpcomingForChannel(channelId: number) {
    return this.db
      .select()
      .from(draws)
      .where(
        and(
          eq(draws.channelId, channelId),
          sql`${draws.status} IN ('scheduled', 'open')`
        )
      )
      .orderBy(draws.scheduledAt);
  }

  /**
   * Execute a draw — randomly selects a winner from active entries.
   */
  async executeDraw(drawId: number) {
    const [draw] = await this.db
      .select()
      .from(draws)
      .where(eq(draws.id, drawId))
      .limit(1);

    if (!draw) {
      throw new BadRequestError("Draw not found.");
    }

    if (draw.status !== "open" && draw.status !== "closed") {
      throw new BadRequestError(`Cannot execute draw with status "${draw.status}". Draw must be open or closed.`);
    }

    // Get all active entries, weighted by entryCount
    const entries = await this.db
      .select()
      .from(drawEntries)
      .where(
        and(
          eq(drawEntries.drawId, drawId),
          eq(drawEntries.status, "active")
        )
      );

    if (entries.length === 0) {
      throw new BadRequestError("No active entries in this draw.");
    }

    // Build weighted pool
    const pool: typeof entries = [];
    for (const entry of entries) {
      const count = entry.entryCount ?? 1;
      for (let i = 0; i < count; i++) {
        pool.push(entry);
      }
    }

    // Random selection
    const winnerIdx = Math.floor(Math.random() * pool.length);
    const winningEntry = pool[winnerIdx];

    // Update draw status
    await this.db
      .update(draws)
      .set({
        status: "drawn",
        drawnAt: new Date(),
        entryPoolSize: pool.length,
        updatedAt: new Date(),
      })
      .where(eq(draws.id, drawId));

    // Mark winning entry as used
    await this.db
      .update(drawEntries)
      .set({ status: "used" })
      .where(eq(drawEntries.id, winningEntry.id));

    // Auto-create winner record
    const [winner] = await this.db
      .insert(drawWinners)
      .values({
        drawId,
        entryId: winningEntry.id,
        customerId: winningEntry.customerId,
        status: "pending",
      })
      .returning();

    return {
      drawId,
      winningEntry,
      winner,
      totalEntries: pool.length,
      uniqueEntrants: entries.length,
    };
  }

  /**
   * Redraw — select a new winner (after previous winner forfeited).
   */
  async redraw(drawId: number) {
    const [draw] = await this.db
      .select()
      .from(draws)
      .where(eq(draws.id, drawId))
      .limit(1);

    if (!draw) {
      throw new BadRequestError("Draw not found.");
    }

    if (draw.status !== "drawn" && draw.status !== "awarded") {
      throw new BadRequestError(`Cannot redraw with status "${draw.status}".`);
    }

    // Get remaining active entries (excluding used ones from previous winners)
    const entries = await this.db
      .select()
      .from(drawEntries)
      .where(
        and(
          eq(drawEntries.drawId, drawId),
          eq(drawEntries.status, "active")
        )
      );

    if (entries.length === 0) {
      throw new BadRequestError("No remaining active entries for redraw.");
    }

    // Build weighted pool
    const pool: typeof entries = [];
    for (const entry of entries) {
      const count = entry.entryCount ?? 1;
      for (let i = 0; i < count; i++) {
        pool.push(entry);
      }
    }

    // Random selection
    const winnerIdx = Math.floor(Math.random() * pool.length);
    const winningEntry = pool[winnerIdx];

    // Mark winning entry as used
    await this.db
      .update(drawEntries)
      .set({ status: "used" })
      .where(eq(drawEntries.id, winningEntry.id));

    // Update draw
    await this.db
      .update(draws)
      .set({
        status: "drawn",
        drawnAt: new Date(),
        entryPoolSize: pool.length,
        updatedAt: new Date(),
      })
      .where(eq(draws.id, drawId));

    // Create new winner record
    const [winner] = await this.db
      .insert(drawWinners)
      .values({
        drawId,
        entryId: winningEntry.id,
        customerId: winningEntry.customerId,
        status: "pending",
      })
      .returning();

    return {
      drawId,
      winningEntry,
      winner,
      totalEntries: pool.length,
      uniqueEntrants: entries.length,
    };
  }
}

export const drawService = new DrawServiceClass();
