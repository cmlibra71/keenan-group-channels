import { eq, and, sql, asc, desc, gte, lte, inArray, SQL } from "drizzle-orm";
import { PgColumn } from "drizzle-orm/pg-core";
import { getCommerceDb } from "../../db";
import {
  inventoryLevels,
  inventoryLocations,
  productVariants,
} from "../../schema";
import { NotFoundError, ValidationError } from "../../errors";
import { transformRow, transformRows } from "../../transforms";
import { ListOptions, PaginatedResult, FilterValue } from "../../base/types";

/**
 * Custom service for managing inventory levels.
 *
 * Unlike other services, inventory levels use a composite key (variantId + locationId),
 * so this service doesn't extend BaseService.
 */
class InventoryLevelServiceClass {
  private get db() {
    return getCommerceDb();
  }

  private resourceName = "Inventory Level";

  private sortColumns: Record<string, PgColumn> = {
    id: inventoryLevels.id,
    variant_id: inventoryLevels.variantId,
    location_id: inventoryLevels.locationId,
    available: inventoryLevels.available,
    updated_at: inventoryLevels.updatedAt,
  };

  private filterColumns: Record<string, PgColumn> = {
    variant_id: inventoryLevels.variantId,
    location_id: inventoryLevels.locationId,
    available_min: inventoryLevels.available,
    available_max: inventoryLevels.available,
    warning_level: inventoryLevels.warningLevel,
  };

  /**
   * List inventory levels with pagination, filtering, and sorting
   */
  async list(options: ListOptions): Promise<PaginatedResult<Record<string, unknown>>> {
    const { page, limit, sort, direction, filters } = options;

    // Build where conditions
    const whereConditions = this.buildFilterConditions(filters || {});

    // Get total count
    const [countResult] = await this.db
      .select({ count: sql<number>`count(*)::int` })
      .from(inventoryLevels)
      .where(whereConditions);

    const total = countResult?.count ?? 0;

    // Get sort column
    const sortColumn = this.getSortColumn(sort);

    // Get paginated results
    const results = await this.db
      .select()
      .from(inventoryLevels)
      .where(whereConditions)
      .orderBy(direction === "desc" ? desc(sortColumn) : asc(sortColumn))
      .limit(limit)
      .offset((page - 1) * limit);

    // Transform to API format
    const data = transformRows(results as Record<string, unknown>[]);

    return {
      data,
      pagination: { page, limit, total },
    };
  }

  /**
   * Get inventory level by variant ID and location ID (composite key)
   */
  async getByVariantAndLocation(
    variantId: number,
    locationId: number
  ): Promise<Record<string, unknown>> {
    const [result] = await this.db
      .select()
      .from(inventoryLevels)
      .where(
        and(
          eq(inventoryLevels.variantId, variantId),
          eq(inventoryLevels.locationId, locationId)
        )
      )
      .limit(1);

    if (!result) {
      throw new NotFoundError(
        this.resourceName,
        `variant_id=${variantId}, location_id=${locationId}`
      );
    }

    return transformRow(result as Record<string, unknown>);
  }

  /**
   * Create or update inventory level (upsert)
   *
   * If a level for the variant+location combination exists, it updates.
   * Otherwise, it creates a new level.
   */
  async upsert(
    variantId: number,
    locationId: number,
    data: Record<string, unknown>
  ): Promise<Record<string, unknown>> {
    // Transform snake_case to camelCase
    const transformedData = this.transformInputData(data);

    // Validate foreign keys
    await this.validateForeignKeys(variantId, locationId);

    // Check if level exists
    const [existing] = await this.db
      .select()
      .from(inventoryLevels)
      .where(
        and(
          eq(inventoryLevels.variantId, variantId),
          eq(inventoryLevels.locationId, locationId)
        )
      )
      .limit(1);

    if (existing) {
      // Update existing
      const updateData = {
        ...transformedData,
        updatedAt: new Date(),
      };

      const [result] = await this.db
        .update(inventoryLevels)
        .set(updateData)
        .where(
          and(
            eq(inventoryLevels.variantId, variantId),
            eq(inventoryLevels.locationId, locationId)
          )
        )
        .returning();

      return transformRow(result as Record<string, unknown>);
    } else {
      // Create new
      const insertData = {
        variantId,
        locationId,
        ...transformedData,
      };

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const [result] = await this.db
        .insert(inventoryLevels)
        .values(insertData as any)
        .returning();

      return transformRow(result as Record<string, unknown>);
    }
  }

  /**
   * Delete inventory level by variant ID and location ID
   */
  async delete(variantId: number, locationId: number): Promise<void> {
    // Check if it exists first
    const [existing] = await this.db
      .select({ id: inventoryLevels.id })
      .from(inventoryLevels)
      .where(
        and(
          eq(inventoryLevels.variantId, variantId),
          eq(inventoryLevels.locationId, locationId)
        )
      )
      .limit(1);

    if (!existing) {
      throw new NotFoundError(
        this.resourceName,
        `variant_id=${variantId}, location_id=${locationId}`
      );
    }

    await this.db
      .delete(inventoryLevels)
      .where(
        and(
          eq(inventoryLevels.variantId, variantId),
          eq(inventoryLevels.locationId, locationId)
        )
      );
  }

  /**
   * Get inventory levels by variant ID
   */
  async listByVariant(variantId: number): Promise<Record<string, unknown>[]> {
    // Validate variant exists
    const [variant] = await this.db
      .select({ id: productVariants.id })
      .from(productVariants)
      .where(eq(productVariants.id, variantId))
      .limit(1);

    if (!variant) {
      throw new NotFoundError("Product Variant", variantId);
    }

    const results = await this.db
      .select()
      .from(inventoryLevels)
      .where(eq(inventoryLevels.variantId, variantId))
      .orderBy(asc(inventoryLevels.locationId));

    return transformRows(results as Record<string, unknown>[]);
  }

  /**
   * Get inventory levels by location ID
   */
  async listByLocation(locationId: number): Promise<Record<string, unknown>[]> {
    // Validate location exists
    const [location] = await this.db
      .select({ id: inventoryLocations.id })
      .from(inventoryLocations)
      .where(eq(inventoryLocations.id, locationId))
      .limit(1);

    if (!location) {
      throw new NotFoundError("Inventory Location", locationId);
    }

    const results = await this.db
      .select()
      .from(inventoryLevels)
      .where(eq(inventoryLevels.locationId, locationId))
      .orderBy(asc(inventoryLevels.variantId));

    return transformRows(results as Record<string, unknown>[]);
  }

  /**
   * Adjust an inventory level field (available, reserved, or incoming).
   * Auto-creates the inventory level if it doesn't exist.
   * Returns the adjustment details and updated level.
   */
  async adjustLevel(options: {
    variantId: number;
    locationId: number;
    adjustmentType: "set" | "increment" | "decrement";
    field: "available" | "reserved" | "incoming";
    quantity: number;
  }): Promise<{
    previousValue: number;
    newValue: number;
    level: Record<string, unknown>;
  }> {
    const { variantId, locationId, adjustmentType, field, quantity } = options;

    // Validate foreign keys
    await this.validateForeignKeys(variantId, locationId);

    // Get or create inventory level
    let [level] = await this.db
      .select()
      .from(inventoryLevels)
      .where(
        and(
          eq(inventoryLevels.variantId, variantId),
          eq(inventoryLevels.locationId, locationId)
        )
      )
      .limit(1);

    if (!level) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const [created] = await this.db
        .insert(inventoryLevels)
        .values({
          variantId,
          locationId,
          available: 0,
          reserved: 0,
          incoming: 0,
          warningLevel: 0,
        } as any)
        .returning();
      level = created;
    }

    // Calculate new value
    const currentValue = level[field];
    let newValue: number;

    switch (adjustmentType) {
      case "set":
        newValue = quantity;
        break;
      case "increment":
        newValue = currentValue + quantity;
        break;
      case "decrement":
        newValue = currentValue - quantity;
        break;
    }

    // Ensure non-negative for available and reserved
    if ((field === "available" || field === "reserved") && newValue < 0) {
      throw new ValidationError(
        `Cannot adjust ${field} to ${newValue}. Value cannot be negative.`,
        { [field]: `Current: ${currentValue}, requested change would result in ${newValue}` }
      );
    }

    // Update the inventory level
    const [updated] = await this.db
      .update(inventoryLevels)
      .set({
        updatedAt: new Date(),
        [field]: newValue,
      })
      .where(eq(inventoryLevels.id, level.id))
      .returning();

    return {
      previousValue: currentValue,
      newValue,
      level: transformRow(updated as Record<string, unknown>),
    };
  }

  // ============================================================================
  // Helper Methods
  // ============================================================================

  /**
   * Validate that variant and location exist
   */
  private async validateForeignKeys(variantId: number, locationId: number): Promise<void> {
    const errors: Record<string, string> = {};

    // Check variant exists
    const [variant] = await this.db
      .select({ id: productVariants.id })
      .from(productVariants)
      .where(eq(productVariants.id, variantId))
      .limit(1);

    if (!variant) {
      errors.variant_id = `Product Variant with ID ${variantId} does not exist.`;
    }

    // Check location exists
    const [location] = await this.db
      .select({ id: inventoryLocations.id })
      .from(inventoryLocations)
      .where(eq(inventoryLocations.id, locationId))
      .limit(1);

    if (!location) {
      errors.location_id = `Inventory Location with ID ${locationId} does not exist.`;
    }

    if (Object.keys(errors).length > 0) {
      throw new ValidationError(
        "One or more referenced resources do not exist.",
        errors
      );
    }
  }

  /**
   * Get the sort column based on sort parameter
   */
  private getSortColumn(sort: string): PgColumn {
    if (this.sortColumns[sort]) {
      return this.sortColumns[sort];
    }
    return inventoryLevels.id;
  }

  /**
   * Build filter conditions from filter params
   */
  private buildFilterConditions(filters: Record<string, FilterValue>): SQL | undefined {
    const conditions: SQL[] = [];

    for (const [field, filter] of Object.entries(filters)) {
      // Handle special min/max filters
      if (field === "available_min") {
        conditions.push(gte(inventoryLevels.available, filter.value as number));
        continue;
      }
      if (field === "available_max") {
        conditions.push(lte(inventoryLevels.available, filter.value as number));
        continue;
      }

      const column = this.filterColumns[field];
      if (!column) continue;

      switch (filter.type) {
        case "eq":
          conditions.push(eq(column, filter.value as string | number | boolean));
          break;
        case "min":
          conditions.push(gte(column, filter.value as number));
          break;
        case "max":
          conditions.push(lte(column, filter.value as number));
          break;
        case "in":
          if (Array.isArray(filter.value)) {
            conditions.push(inArray(column, filter.value));
          }
          break;
      }
    }

    return conditions.length > 0 ? and(...conditions) : undefined;
  }

  /**
   * Transform input data from snake_case to camelCase
   */
  private transformInputData(data: Record<string, unknown>): Record<string, unknown> {
    const result: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(data)) {
      const camelKey = this.snakeToCamel(key);
      result[camelKey] = value;
    }
    return result;
  }

  /**
   * Convert snake_case to camelCase
   */
  private snakeToCamel(str: string): string {
    return str.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
  }
}

export const inventoryLevelService = new InventoryLevelServiceClass();
