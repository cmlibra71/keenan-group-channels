import { and, eq, inArray } from "drizzle-orm";
import { PgColumn } from "drizzle-orm/pg-core";
import { products, productImages } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { generateOptimizedSizes } from "../../utils/image-optimizer";

/**
 * Service for managing product images.
 */
class ProductImageServiceClass extends NestedService<typeof products, typeof productImages> {
  constructor() {
    super(products, productImages, {
      resourceName: "Image",
      parentResourceName: "Product",
      defaultSort: "sort_order",
      sortColumns: {
        id: productImages.id,
        sort_order: productImages.sortOrder,
        created_at: productImages.createdAt,
      },
      filterColumns: {
        is_thumbnail: productImages.isThumbnail,
      },
      allowedFilters: ["is_thumbnail"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return products.id;
  }

  protected getParentForeignKey(): PgColumn {
    return productImages.productId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "productId";
  }

  /**
   * Handle is_thumbnail flag - ensure only one image per product is thumbnail
   */
  protected async beforeCreate(data: Record<string, unknown>): Promise<Record<string, unknown>> {
    if (data.isThumbnail) {
      const productId = data.productId as number;
      await this.db
        .update(productImages)
        .set({ isThumbnail: false })
        .where(eq(productImages.productId, productId));
    }
    return data;
  }

  /**
   * Handle is_thumbnail flag on update
   */
  protected async beforeUpdate(
    data: Record<string, unknown>,
    existing: Record<string, unknown>
  ): Promise<Record<string, unknown>> {
    if (data.isThumbnail === true) {
      const productId = existing.productId as number;
      await this.db
        .update(productImages)
        .set({ isThumbnail: false })
        .where(eq(productImages.productId, productId));
    }
    return data;
  }

  /**
   * After creating an image, fire-and-forget optimized size generation.
   */
  protected async afterCreate(result: Record<string, unknown>): Promise<void> {
    const url = result.urlStandard as string | undefined;
    if (url) {
      generateOptimizedSizes(url).catch((err) => {
        console.error("[ProductImageService] Failed to generate optimized sizes:", err.message);
      });
    }
  }

  /**
   * After updating an image, regenerate optimized sizes if URL changed.
   */
  protected async afterUpdate(result: Record<string, unknown>, previous: Record<string, unknown>): Promise<void> {
    const url = result.urlStandard as string | undefined;
    const prevUrl = previous.urlStandard as string | undefined;
    if (url && url !== prevUrl) {
      generateOptimizedSizes(url).catch((err) => {
        console.error("[ProductImageService] Failed to generate optimized sizes:", err.message);
      });
    }
  }

  // ── Storefront methods ────────────────────────────────────────────

  /**
   * Get all images for a product, ordered by sort order.
   */
  async getForProduct(productId: number) {
    return this.db
      .select()
      .from(productImages)
      .where(eq(productImages.productId, productId))
      .orderBy(productImages.sortOrder);
  }

  /**
   * Get thumbnail images for multiple products at once.
   */
  async getThumbnailsForProducts(productIds: number[]) {
    if (productIds.length === 0) return [];
    return this.db
      .select()
      .from(productImages)
      .where(
        and(
          inArray(productImages.productId, productIds),
          eq(productImages.isThumbnail, true)
        )
      );
  }
}

export const productImageService = new ProductImageServiceClass();
