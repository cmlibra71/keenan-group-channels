import { eq, and, sql, asc, desc, SQL } from "drizzle-orm";
import { PgColumn } from "drizzle-orm/pg-core";
import { getCommerceDb } from "../../db";
import { auditLog } from "../../schema";
import { NotFoundError } from "../../errors";
import { transformRow, transformRows } from "../../transforms";
import { ListOptions, PaginatedResult, FilterValue } from "../../base/types";

/**
 * Service for viewing audit log entries (read-only).
 *
 * Audit log entries are created by the system when changes occur,
 * and should not be manually created/updated/deleted via the API.
 */
class AuditServiceClass {
  protected get db() {
    return getCommerceDb();
  }

  private sortColumns: Record<string, PgColumn> = {
    id: auditLog.id,
    created_at: auditLog.createdAt,
    action: auditLog.action,
  };

  private filterColumns: Record<string, PgColumn> = {
    action: auditLog.action,
    entity_type: auditLog.entityType,
    entity_id: auditLog.entityId,
    admin_user_id: auditLog.adminUserId,
    account_id: auditLog.accountId,
    contact_id: auditLog.contactId,
    customer_id: auditLog.customerId,
  };

  /**
   * List audit log entries with pagination, filtering, and sorting
   */
  async list(options: ListOptions): Promise<PaginatedResult<Record<string, unknown>>> {
    const { page, limit, sort, direction, filters } = options;

    // Build where conditions
    const whereConditions = this.buildFilterConditions(filters || {});

    // Get total count
    const [countResult] = await this.db
      .select({ count: sql<number>`count(*)::int` })
      .from(auditLog)
      .where(whereConditions);

    const total = countResult?.count ?? 0;

    // Get sort column
    const sortColumn = this.sortColumns[sort] || auditLog.id;

    // Get paginated results
    const results = await this.db
      .select()
      .from(auditLog)
      .where(whereConditions)
      .orderBy(direction === "desc" ? desc(sortColumn) : asc(sortColumn))
      .limit(limit)
      .offset((page - 1) * limit);

    const data = transformRows(results as Record<string, unknown>[]);

    return {
      data,
      pagination: { page, limit, total },
    };
  }

  /**
   * Get a single audit log entry by ID
   */
  async getById(id: number | bigint): Promise<Record<string, unknown>> {
    const [result] = await this.db
      .select()
      .from(auditLog)
      .where(eq(auditLog.id, BigInt(id)))
      .limit(1);

    if (!result) {
      throw new NotFoundError("Audit Log Entry", String(id));
    }

    return transformRow(result as Record<string, unknown>);
  }

  /**
   * Build filter conditions from filter params
   */
  private buildFilterConditions(filters: Record<string, FilterValue>): SQL | undefined {
    const conditions: SQL[] = [];

    for (const [field, filter] of Object.entries(filters)) {
      const column = this.filterColumns[field];
      if (!column) continue;

      switch (filter.type) {
        case "eq":
          conditions.push(eq(column, filter.value as string | number | boolean));
          break;
      }
    }

    return conditions.length > 0 ? and(...conditions) : undefined;
  }
}

export const auditService = new AuditServiceClass();
