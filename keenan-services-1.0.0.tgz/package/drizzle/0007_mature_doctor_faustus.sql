ALTER TABLE "quotes" ALTER COLUMN "status" SET DATA TYPE varchar(30);--> statement-breakpoint
ALTER TABLE "quotes" ALTER COLUMN "status" SET DEFAULT 'quote_pending';--> statement-breakpoint
UPDATE "quotes" SET "status" = 'quote_pending' WHERE "status" = 'draft';--> statement-breakpoint
UPDATE "quotes" SET "status" = 'quote_available' WHERE "status" = 'submitted';--> statement-breakpoint
UPDATE "quotes" SET "status" = 'converted_to_order' WHERE "status" = 'converted';--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "quote_number" varchar(50);--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "quote_name" varchar(255);--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "sent_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "accepted_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "cancelled_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "reminder_sent_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "converted_order_id" integer;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "convertible_multiple_times" boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "hide_prices" boolean DEFAULT true;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "permissions" jsonb DEFAULT '{}'::jsonb;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "external_id" varchar(255);--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "external_source" varchar(100);--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "source_content_hash" varchar(64);--> statement-breakpoint
ALTER TABLE "quotes" ADD CONSTRAINT "quotes_converted_order_id_orders_id_fk" FOREIGN KEY ("converted_order_id") REFERENCES "public"."orders"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_quotes_account" ON "quotes" USING btree ("account_id");--> statement-breakpoint
CREATE INDEX "idx_quotes_expires_at" ON "quotes" USING btree ("expires_at");--> statement-breakpoint
CREATE INDEX "idx_quotes_converted_order" ON "quotes" USING btree ("converted_order_id");--> statement-breakpoint
CREATE UNIQUE INDEX "uq_quotes_external" ON "quotes" USING btree ("external_source","external_id") WHERE "quotes"."external_id" IS NOT NULL;--> statement-breakpoint
ALTER TABLE "quotes" ADD CONSTRAINT "quotes_quote_number_unique" UNIQUE("quote_number");