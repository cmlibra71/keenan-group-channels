CREATE TABLE "blog_posts" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"channel_id" integer NOT NULL,
	"slug" varchar(255) NOT NULL,
	"title" varchar(500) NOT NULL,
	"excerpt" text,
	"body_html" text NOT NULL,
	"hero_image_url" varchar(500),
	"hero_image_alt" varchar(255),
	"author_name" varchar(255),
	"author_avatar_url" varchar(500),
	"tags" text[] DEFAULT '{}',
	"status" varchar(20) DEFAULT 'draft' NOT NULL,
	"published_at" timestamp with time zone,
	"page_title" varchar(255),
	"meta_description" text,
	"metafields" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "blog_posts_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "blog_posts_channel_slug" UNIQUE("channel_id","slug")
);
--> statement-breakpoint
CREATE TABLE "product_upsells" (
	"id" serial PRIMARY KEY NOT NULL,
	"product_id" integer NOT NULL,
	"related_product_id" integer NOT NULL,
	"kind" varchar(20) NOT NULL,
	"sort_order" integer DEFAULT 0,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "product_upsells_unique" UNIQUE("product_id","related_product_id","kind")
);
--> statement-breakpoint
CREATE TABLE "quote_attachments" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"quote_id" integer NOT NULL,
	"file_name" varchar(500) NOT NULL,
	"file_url" varchar(1000) NOT NULL,
	"content_type" varchar(100),
	"file_size" integer,
	"uploaded_by_user_id" integer,
	"created_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "quote_attachments_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "quote_attribute_definitions" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"channel_id" integer,
	"code" varchar(100) NOT NULL,
	"label" varchar(255) NOT NULL,
	"input_type" varchar(30) DEFAULT 'text' NOT NULL,
	"options" jsonb DEFAULT '[]'::jsonb,
	"is_required" boolean DEFAULT false NOT NULL,
	"location" varchar(40) DEFAULT 'information' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"enabled_for_storefront" boolean DEFAULT true NOT NULL,
	"enabled_for_admin" boolean DEFAULT true NOT NULL,
	"copy_to_order" boolean DEFAULT false NOT NULL,
	"visible_customer_group_ids" integer[] DEFAULT '{}',
	"show_in_pdf" boolean DEFAULT false NOT NULL,
	"show_in_emails" boolean DEFAULT false NOT NULL,
	"show_on_csv_export" boolean DEFAULT false NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "quote_attribute_definitions_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "quote_comments" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"quote_id" integer NOT NULL,
	"author_type" varchar(20) DEFAULT 'admin' NOT NULL,
	"author_user_id" integer,
	"author_name" varchar(255),
	"author_contact_id" integer,
	"visibility" varchar(20) DEFAULT 'public' NOT NULL,
	"body" text NOT NULL,
	"email_notification_sent" boolean DEFAULT false NOT NULL,
	"email_sent_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "quote_comments_uuid_unique" UNIQUE("uuid")
);
--> statement-breakpoint
CREATE TABLE "quote_pdf_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"channel_id" integer NOT NULL,
	"template" varchar(30) DEFAULT 'modern' NOT NULL,
	"logo_url" varchar(500),
	"header_text" text,
	"above_items_text" text,
	"ending_message" text,
	"item_attributes_to_show" jsonb DEFAULT '[]'::jsonb,
	"show_email_address" boolean DEFAULT true NOT NULL,
	"footer_text" text,
	"include_pdf_in_emails" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "quote_pdf_settings_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "quote_pdf_settings_channel_id_unique" UNIQUE("channel_id")
);
--> statement-breakpoint
CREATE TABLE "quote_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"channel_id" integer NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"cart_mode" varchar(20) DEFAULT 'add_to_cart' NOT NULL,
	"restricted_to_customer_group_ids" integer[] DEFAULT '{}',
	"quote_id_prefix" varchar(20) DEFAULT 'Q-',
	"quote_id_next_sequence" integer DEFAULT 1 NOT NULL,
	"quote_id_padding" integer DEFAULT 5 NOT NULL,
	"perm_allow_edit_addresses" boolean DEFAULT true NOT NULL,
	"perm_allow_edit_items" boolean DEFAULT true NOT NULL,
	"perm_allow_edit_shipping_method" boolean DEFAULT true NOT NULL,
	"perm_allow_add_comments" boolean DEFAULT true NOT NULL,
	"perm_allow_change_quote_name" boolean DEFAULT true NOT NULL,
	"perm_allow_convert_multiple_times" boolean DEFAULT false NOT NULL,
	"new_quote_status" varchar(50) DEFAULT 'quote_pending' NOT NULL,
	"hide_prices_for_new_quote" boolean DEFAULT true NOT NULL,
	"quote_available_status" varchar(50) DEFAULT 'quote_available' NOT NULL,
	"change_status_on_customer_edit" boolean DEFAULT true NOT NULL,
	"customer_edit_status" varchar(50) DEFAULT 'open_change_request' NOT NULL,
	"expiration_enabled" boolean DEFAULT true NOT NULL,
	"default_expiration_days" integer DEFAULT 30 NOT NULL,
	"reminder_enabled" boolean DEFAULT false NOT NULL,
	"default_reminder_days" integer DEFAULT 7 NOT NULL,
	"reminder_quote_status" varchar(50),
	"pdf_footer_text" text,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "quote_settings_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "quote_settings_channel_id_unique" UNIQUE("channel_id")
);
--> statement-breakpoint
CREATE TABLE "quote_statuses" (
	"id" serial PRIMARY KEY NOT NULL,
	"uuid" uuid DEFAULT gen_random_uuid() NOT NULL,
	"value" varchar(50) NOT NULL,
	"label" varchar(255) NOT NULL,
	"description" text,
	"color" varchar(100) DEFAULT 'bg-zinc-100 text-zinc-600' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"is_system" boolean DEFAULT false NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"hide_prices" boolean DEFAULT false NOT NULL,
	"is_terminal" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "quote_statuses_uuid_unique" UNIQUE("uuid"),
	CONSTRAINT "quote_statuses_value_unique" UNIQUE("value")
);
--> statement-breakpoint
ALTER TABLE "quote_items" ADD COLUMN "customer_group_id" integer;--> statement-breakpoint
ALTER TABLE "quote_items" ADD COLUMN "attributes" jsonb DEFAULT '{}'::jsonb;--> statement-breakpoint
ALTER TABLE "quote_items" ADD COLUMN "discount_type" varchar(20);--> statement-breakpoint
ALTER TABLE "quote_items" ADD COLUMN "discount_amount" numeric(19, 4);--> statement-breakpoint
ALTER TABLE "quote_items" ADD COLUMN "price_source" varchar(20) DEFAULT 'manual';--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "customer_group_id" integer;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "attributes" jsonb DEFAULT '{}'::jsonb;--> statement-breakpoint
ALTER TABLE "blog_posts" ADD CONSTRAINT "blog_posts_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_upsells" ADD CONSTRAINT "product_upsells_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_upsells" ADD CONSTRAINT "product_upsells_related_product_id_products_id_fk" FOREIGN KEY ("related_product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_attachments" ADD CONSTRAINT "quote_attachments_quote_id_quotes_id_fk" FOREIGN KEY ("quote_id") REFERENCES "public"."quotes"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_attribute_definitions" ADD CONSTRAINT "quote_attribute_definitions_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_comments" ADD CONSTRAINT "quote_comments_quote_id_quotes_id_fk" FOREIGN KEY ("quote_id") REFERENCES "public"."quotes"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_comments" ADD CONSTRAINT "quote_comments_author_contact_id_contacts_id_fk" FOREIGN KEY ("author_contact_id") REFERENCES "public"."contacts"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_pdf_settings" ADD CONSTRAINT "quote_pdf_settings_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_settings" ADD CONSTRAINT "quote_settings_channel_id_channels_id_fk" FOREIGN KEY ("channel_id") REFERENCES "public"."channels"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_blog_posts_channel_status_published" ON "blog_posts" USING btree ("channel_id","status","published_at");--> statement-breakpoint
CREATE INDEX "idx_product_upsells_product" ON "product_upsells" USING btree ("product_id","kind");--> statement-breakpoint
CREATE INDEX "idx_quote_attachments_quote" ON "quote_attachments" USING btree ("quote_id");--> statement-breakpoint
CREATE UNIQUE INDEX "uq_quote_attr_def_channel_code" ON "quote_attribute_definitions" USING btree ("channel_id","code");--> statement-breakpoint
CREATE INDEX "idx_quote_attr_def_channel" ON "quote_attribute_definitions" USING btree ("channel_id");--> statement-breakpoint
CREATE INDEX "idx_quote_attr_def_active" ON "quote_attribute_definitions" USING btree ("is_active","sort_order");--> statement-breakpoint
CREATE INDEX "idx_quote_comments_quote" ON "quote_comments" USING btree ("quote_id");--> statement-breakpoint
CREATE INDEX "idx_quote_comments_quote_created" ON "quote_comments" USING btree ("quote_id","created_at");--> statement-breakpoint
ALTER TABLE "quote_items" ADD CONSTRAINT "quote_items_customer_group_id_customer_groups_id_fk" FOREIGN KEY ("customer_group_id") REFERENCES "public"."customer_groups"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quotes" ADD CONSTRAINT "quotes_customer_group_id_customer_groups_id_fk" FOREIGN KEY ("customer_group_id") REFERENCES "public"."customer_groups"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_quote_items_customer_group" ON "quote_items" USING btree ("customer_group_id");--> statement-breakpoint
CREATE INDEX "idx_quotes_customer_group" ON "quotes" USING btree ("customer_group_id");