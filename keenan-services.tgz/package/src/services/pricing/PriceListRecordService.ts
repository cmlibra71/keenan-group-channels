import { eq, and, inArray } from "drizzle-orm";
import { PgColumn } from "drizzle-orm/pg-core";
import { priceLists, priceListRecords, productVariants } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { ForeignKeyValidation, UniqueConstraint } from "../../base/types";
import { NotFoundError, ValidationError } from "../../errors";
import { transformRows } from "../../transforms";

interface PriceRecordInput {
  variant_id: number;
  price?: string | null;
  sale_price?: string | null;
  retail_price?: string | null;
  map_price?: string | null;
  bulk_pricing_tiers?: Record<string, unknown>;
}

/**
 * Service for managing price list records (variant prices within a price list).
 */
class PriceListRecordServiceClass extends NestedService<
  typeof priceLists,
  typeof priceListRecords
> {
  constructor() {
    super(priceLists, priceListRecords, {
      resourceName: "Price List Record",
      parentResourceName: "Price List",
      defaultSort: "id",
      sortColumns: {
        id: priceListRecords.id,
        variant_id: priceListRecords.variantId,
        price: priceListRecords.price,
        created_at: priceListRecords.createdAt,
      },
      filterColumns: {
        variant_id: priceListRecords.variantId,
      },
      allowedFilters: ["variant_id"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return priceLists.id;
  }

  protected getParentForeignKey(): PgColumn {
    return priceListRecords.priceListId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "priceListId";
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: productVariants,
        column: productVariants.id,
        resourceName: "Variant",
        fieldName: "variantId",
        optional: false,
      },
    ];
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [
          { column: priceListRecords.priceListId, fieldName: "priceListId" },
          { column: priceListRecords.variantId, fieldName: "variantId" },
        ],
        message: "A price record for this variant already exists in this price list.",
        composite: true,
      },
    ];
  }

  /**
   * Batch upsert price records for a price list
   */
  async batchUpsertForParent(
    parentId: number,
    records: PriceRecordInput[]
  ): Promise<Record<string, unknown>[]> {
    // Validate parent exists
    await this.validateParent(parentId);

    // Validate all variant IDs exist
    const variantIds = records.map((r) => r.variant_id);
    const existingVariants = await this.db
      .select({ id: productVariants.id })
      .from(productVariants)
      .where(inArray(productVariants.id, variantIds));

    const existingVariantIds = new Set(existingVariants.map((v) => v.id));
    const missingVariantIds = variantIds.filter((id) => !existingVariantIds.has(id));

    if (missingVariantIds.length > 0) {
      throw new ValidationError("Some variant IDs do not exist.", {
        variant_ids: `Invalid variant IDs: ${missingVariantIds.join(", ")}`,
      });
    }

    // Perform upsert for each record
    const upsertedRecords = [];
    for (const record of records) {
      const values = {
        priceListId: parentId,
        variantId: record.variant_id,
        price: record.price,
        salePrice: record.sale_price,
        retailPrice: record.retail_price,
        mapPrice: record.map_price,
        bulkPricingTiers: record.bulk_pricing_tiers ?? [],
        updatedAt: new Date(),
      };

      // Check if record exists
      const [existing] = await this.db
        .select({ id: priceListRecords.id })
        .from(priceListRecords)
        .where(
          and(
            eq(priceListRecords.priceListId, parentId),
            eq(priceListRecords.variantId, record.variant_id)
          )
        )
        .limit(1);

      let result;
      if (existing) {
        // Update existing record
        [result] = await this.db
          .update(priceListRecords)
          .set(values)
          .where(eq(priceListRecords.id, existing.id))
          .returning();
      } else {
        // Insert new record
        [result] = await this.db
          .insert(priceListRecords)
          .values({
            ...values,
            createdAt: new Date(),
          })
          .returning();
      }
      upsertedRecords.push(result);
    }

    return transformRows(upsertedRecords as Record<string, unknown>[]);
  }

  /**
   * Delete a price record by variant ID for a specific price list
   */
  async deleteByVariantForParent(parentId: number, variantId: number): Promise<void> {
    // Validate parent exists
    await this.validateParent(parentId);

    // Check record exists
    const [record] = await this.db
      .select({ id: priceListRecords.id })
      .from(priceListRecords)
      .where(
        and(
          eq(priceListRecords.priceListId, parentId),
          eq(priceListRecords.variantId, variantId)
        )
      )
      .limit(1);

    if (!record) {
      throw new NotFoundError("Price Record for Variant", variantId);
    }

    // Delete record
    await this.db
      .delete(priceListRecords)
      .where(eq(priceListRecords.id, record.id));
  }
}

export const priceListRecordService = new PriceListRecordServiceClass();
