import { and, eq, count, min, max, inArray } from "drizzle-orm";
import { categories, categoryTrees, productCategories, products, brands } from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation, UniqueConstraint, DependencyCheck } from "../../base/types";

/**
 * Service for managing categories within category trees.
 */
class CategoryServiceClass extends BaseService<typeof categories> {
  constructor() {
    super(categories, {
      resourceName: "Category",
      defaultSort: "id",
      sortColumns: {
        id: categories.id,
        name: categories.name,
        sort_order: categories.sortOrder,
        created_at: categories.createdAt,
      },
      filterColumns: {
        tree_id: categories.treeId,
        parent_id: categories.parentId,
        is_active: categories.isActive,
        include_in_menu: categories.includeInMenu,
        include_in_search: categories.includeInSearch,
        include_in_filters: categories.includeInFilters,
        name: categories.name,
      },
      allowedFilters: ["tree_id", "parent_id", "is_active", "include_in_menu", "include_in_search", "include_in_filters", "name"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: categoryTrees,
        column: categoryTrees.id,
        resourceName: "Category Tree",
        fieldName: "treeId",
      },
      {
        table: categories,
        column: categories.id,
        resourceName: "Parent Category",
        fieldName: "parentId",
        optional: true,
      },
    ];
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [
          { column: categories.treeId, fieldName: "treeId" },
          { column: categories.slug, fieldName: "slug" },
        ],
        message: "Category slug already exists in this tree.",
        composite: true,
      },
    ];
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: categories,
        foreignKeyColumn: categories.parentId,
        resourceName: "child category",
        message: "Cannot delete category because it has {count} child category(s).",
      },
      {
        table: productCategories,
        foreignKeyColumn: productCategories.categoryId,
        resourceName: "product assignment",
        message: "Cannot delete category because it has {count} product(s) assigned.",
      },
    ];
  }

  async getBySlug(slug: string, channelId?: number) {
    const conditions = [eq(categories.slug, slug), eq(categories.isActive, true)];

    if (channelId) {
      const treeId = await this.getTreeIdForChannel(channelId);
      if (treeId) conditions.push(eq(categories.treeId, treeId));
    }

    const [category] = await this.db
      .select()
      .from(categories)
      .where(and(...conditions))
      .limit(1);
    return category || null;
  }

  async listVisible(channelId?: number) {
    const conditions = [eq(categories.isActive, true), eq(categories.includeInMenu, true)];

    if (channelId) {
      const treeId = await this.getTreeIdForChannel(channelId);
      if (treeId) conditions.push(eq(categories.treeId, treeId));
    }

    return this.db
      .select()
      .from(categories)
      .where(and(...conditions))
      .orderBy(categories.sortOrder);
  }

  async getBreadcrumbs(pathIds: number[]) {
    if (!pathIds || pathIds.length === 0) return [];
    const results = await this.db
      .select({ id: categories.id, name: categories.name, slug: categories.slug })
      .from(categories)
      .where(inArray(categories.id, pathIds));

    // Return in path order
    const map = new Map(results.map(r => [r.id, r]));
    return pathIds.map(id => map.get(id)).filter(Boolean) as { id: number; name: string; slug: string }[];
  }

  async getChildren(parentId: number) {
    return this.db
      .select()
      .from(categories)
      .where(and(eq(categories.parentId, parentId), eq(categories.isActive, true), eq(categories.includeInMenu, true)))
      .orderBy(categories.sortOrder);
  }

  async listActiveChildren(parentId: number) {
    return this.db
      .select()
      .from(categories)
      .where(and(eq(categories.parentId, parentId), eq(categories.isActive, true)))
      .orderBy(categories.sortOrder);
  }

  async getCategoryStats(categoryId: number) {
    const [stats] = await this.db
      .select({
        productCount: count(products.id),
        minPrice: min(products.price),
        maxPrice: max(products.price),
      })
      .from(productCategories)
      .innerJoin(products, and(
        eq(products.id, productCategories.productId),
        eq(products.isVisible, true),
        eq(products.isDeleted, false),
      ))
      .where(eq(productCategories.categoryId, categoryId));

    const categoryBrands = await this.db
      .selectDistinct({ name: brands.name })
      .from(productCategories)
      .innerJoin(products, and(
        eq(products.id, productCategories.productId),
        eq(products.isVisible, true),
        eq(products.isDeleted, false),
      ))
      .innerJoin(brands, eq(brands.id, products.brandId))
      .where(eq(productCategories.categoryId, categoryId))
      .orderBy(brands.name);

    return {
      productCount: stats?.productCount ?? 0,
      minPrice: stats?.minPrice ? parseFloat(stats.minPrice) : 0,
      maxPrice: stats?.maxPrice ? parseFloat(stats.maxPrice) : 0,
      brands: categoryBrands.map(b => b.name).filter(Boolean) as string[],
    };
  }

  async copyToTree(
    categoryId: number,
    targetTreeId: number,
    targetParentId: number | null = null
  ): Promise<Record<string, unknown>> {
    // Fetch the source category
    const source = await this.getById(categoryId);

    // Build the new category data
    const slug = source.slug as string;
    let finalSlug = slug;

    // Check for slug conflicts and generate unique slug
    const existing = await this.db
      .select({ id: categories.id })
      .from(categories)
      .where(and(eq(categories.treeId, targetTreeId), eq(categories.slug, finalSlug)))
      .limit(1);

    if (existing.length > 0) {
      let counter = 1;
      while (true) {
        finalSlug = `${slug}-${counter}`;
        const conflict = await this.db
          .select({ id: categories.id })
          .from(categories)
          .where(and(eq(categories.treeId, targetTreeId), eq(categories.slug, finalSlug)))
          .limit(1);
        if (conflict.length === 0) break;
        counter++;
      }
    }

    return this.create({
      treeId: targetTreeId,
      parentId: targetParentId,
      name: source.name,
      slug: finalSlug,
      description: source.description || null,
      sortOrder: source.sort_order ?? 0,
      isActive: true,
      includeInMenu: source.include_in_menu ?? true,
      includeInSearch: source.include_in_search ?? true,
      includeInFilters: source.include_in_filters ?? true,
      imageUrl: source.image_url || null,
      pageTitle: source.page_title || null,
      metaDescription: source.meta_description || null,
      metaKeywords: source.meta_keywords || null,
    });
  }

  private async getTreeIdForChannel(channelId: number): Promise<number | null> {
    const [tree] = await this.db
      .select({ id: categoryTrees.id })
      .from(categoryTrees)
      .where(eq(categoryTrees.channelId, channelId))
      .limit(1);
    return tree?.id ?? null;
  }
}

export const categoryService = new CategoryServiceClass();
