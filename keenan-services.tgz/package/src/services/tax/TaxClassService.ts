import { taxClasses, taxRates } from "../../schema";
import { BaseService } from "../../base/BaseService";
import { DependencyCheck } from "../../base/types";

/**
 * Service for managing tax classes.
 */
class TaxClassServiceClass extends BaseService<typeof taxClasses> {
  constructor() {
    super(taxClasses, {
      resourceName: "Tax Class",
      defaultSort: "id",
      sortColumns: {
        id: taxClasses.id,
        name: taxClasses.name,
        created_at: taxClasses.createdAt,
      },
      filterColumns: {
        name: taxClasses.name,
        is_default: taxClasses.isDefault,
      },
      allowedFilters: ["name", "is_default"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: taxRates,
        foreignKeyColumn: taxRates.taxClassId,
        resourceName: "tax rate",
        message: "Cannot delete tax class because it has {count} tax rate(s) associated.",
      },
    ];
  }
}

export const taxClassService = new TaxClassServiceClass();
