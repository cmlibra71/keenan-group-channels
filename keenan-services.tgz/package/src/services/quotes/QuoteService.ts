import { eq, and, ne, desc } from "drizzle-orm";
import {
  quotes,
  channels,
  customers,
  accounts,
  contacts,
  quoteItems,
  products,
  productVariants,
} from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation, DependencyCheck, IncludeConfig } from "../../base/types";

/**
 * Service for managing quotes (B2B quoting workflow).
 */
class QuoteServiceClass extends BaseService<typeof quotes> {
  constructor() {
    super(quotes, {
      resourceName: "Quote",
      defaultSort: "id",
      sortColumns: {
        id: quotes.id,
        created_at: quotes.createdAt,
        updated_at: quotes.updatedAt,
      },
      filterColumns: {
        channel_id: quotes.channelId,
        customer_id: quotes.customerId,
        account_id: quotes.accountId,
        contact_id: quotes.contactId,
        status: quotes.status,
      },
      allowedFilters: ["channel_id", "customer_id", "account_id", "contact_id", "status"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: channels,
        column: channels.id,
        resourceName: "Channel",
        fieldName: "channelId",
      },
      {
        table: customers,
        column: customers.id,
        resourceName: "Customer",
        fieldName: "customerId",
        optional: true,
      },
      {
        table: accounts,
        column: accounts.id,
        resourceName: "Account",
        fieldName: "accountId",
        optional: true,
      },
      {
        table: contacts,
        column: contacts.id,
        resourceName: "Contact",
        fieldName: "contactId",
        optional: true,
      },
    ];
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: quoteItems,
        foreignKeyColumn: quoteItems.quoteId,
        resourceName: "quote item",
        message: "Cannot delete quote because it has {count} item(s). Remove items first or delete the quote with its items.",
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "items",
        table: quoteItems,
        foreignKey: quoteItems.quoteId,
      },
    ];
  }

  // ── Storefront convenience methods ──────────────────────────────────

  /**
   * Find a draft quote by its UUID (from cookie).
   */
  async getByUuid(uuid: string) {
    const [quote] = await this.db
      .select()
      .from(quotes)
      .where(and(eq(quotes.uuid, uuid), eq(quotes.status, "draft")))
      .limit(1);
    return quote || null;
  }

  /**
   * Get quote with items joined to product/variant display info.
   */
  async getWithItems(quoteId: number) {
    const [quote] = await this.db
      .select()
      .from(quotes)
      .where(eq(quotes.id, quoteId))
      .limit(1);
    if (!quote) return null;

    const items = await this.db
      .select({
        id: quoteItems.id,
        productId: quoteItems.productId,
        variantId: quoteItems.variantId,
        quantity: quoteItems.quantity,
        listPrice: quoteItems.listPrice,
        salePrice: quoteItems.salePrice,
        extendedListPrice: quoteItems.extendedListPrice,
        extendedSalePrice: quoteItems.extendedSalePrice,
        customerNotes: quoteItems.customerNotes,
        productName: products.name,
        productSlug: products.urlPath,
        productSku: products.sku,
        variantSku: productVariants.sku,
        variantOptionName: productVariants.optionDisplayName,
      })
      .from(quoteItems)
      .innerJoin(products, eq(quoteItems.productId, products.id))
      .leftJoin(productVariants, eq(quoteItems.variantId, productVariants.id))
      .where(eq(quoteItems.quoteId, quoteId));

    return { ...quote, items };
  }

  /**
   * List all non-draft quotes for a customer within a channel.
   */
  async listForCustomer(customerId: number, channelId: number) {
    return this.db
      .select()
      .from(quotes)
      .where(
        and(
          eq(quotes.customerId, customerId),
          eq(quotes.channelId, channelId),
          ne(quotes.status, "draft")
        )
      )
      .orderBy(desc(quotes.createdAt));
  }

  /**
   * Transition quote to submitted status with optional customer notes.
   */
  async markSubmitted(quoteId: number, customerNotes?: string) {
    const [updated] = await this.db
      .update(quotes)
      .set({
        status: "submitted",
        customerNotes: customerNotes || null,
        updatedAt: new Date(),
      })
      .where(eq(quotes.id, quoteId))
      .returning();
    return updated || null;
  }

  /**
   * Transition quote to converted status (e.g. after creating an order from it).
   */
  async markConverted(quoteId: number) {
    const [updated] = await this.db
      .update(quotes)
      .set({ status: "converted", updatedAt: new Date() })
      .where(eq(quotes.id, quoteId))
      .returning();
    return updated || null;
  }

  protected async beforeCreate(data: Record<string, unknown>): Promise<Record<string, unknown>> {
    if (!data.status) {
      data.status = "draft";
    }

    if (!data.baseAmount) {
      data.baseAmount = "0";
    }
    if (!data.discountAmount) {
      data.discountAmount = "0";
    }
    if (!data.quoteAmount) {
      data.quoteAmount = "0";
    }

    // Set expiry date (30 days from now)
    if (!data.expiresAt) {
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 30);
      data.expiresAt = expiresAt;
    }

    // Get channel's default currency if not specified
    if (!data.currencyCode && data.channelId) {
      const [channel] = await this.db
        .select({ defaultCurrencyCode: channels.defaultCurrencyCode })
        .from(channels)
        .where(eq(channels.id, data.channelId as number))
        .limit(1);

      if (channel?.defaultCurrencyCode) {
        data.currencyCode = channel.defaultCurrencyCode;
      } else {
        data.currencyCode = "USD";
      }
    }

    return data;
  }
}

export const quoteService = new QuoteServiceClass();
