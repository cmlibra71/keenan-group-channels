import { eq, sql } from "drizzle-orm";
import { paymentStatuses, orders } from "../../schema";
import { getCommerceDb } from "../../db";
import { BaseService } from "../../base/BaseService";
import { UniqueConstraint } from "../../base/types";
import { ConflictError } from "../../errors";

/**
 * Service for managing payment statuses.
 */
class PaymentStatusServiceClass extends BaseService<typeof paymentStatuses> {
  constructor() {
    super(paymentStatuses, {
      resourceName: "Payment Status",
      defaultSort: "sort_order",
      sortColumns: {
        id: paymentStatuses.id,
        value: paymentStatuses.value,
        label: paymentStatuses.label,
        sort_order: paymentStatuses.sortOrder,
        created_at: paymentStatuses.createdAt,
      },
      filterColumns: {
        value: paymentStatuses.value,
        label: paymentStatuses.label,
        is_system: paymentStatuses.isSystem,
        is_active: paymentStatuses.isActive,
      },
      allowedFilters: ["value", "label", "is_system", "is_active"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [{ column: paymentStatuses.value, fieldName: "value" }],
        message: "A payment status with this value already exists.",
      },
    ];
  }

  protected async beforeDelete(
    _id: number,
    existing: Record<string, unknown>
  ): Promise<void> {
    if (existing.isSystem) {
      throw new ConflictError(
        "Cannot delete a built-in system status. System statuses are required for core functionality."
      );
    }

    // Check if any orders reference this payment status value
    const statusValue = existing.value as string;
    const db = getCommerceDb();
    const [countResult] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(orders)
      .where(eq(orders.paymentStatus, statusValue));

    const count = countResult?.count ?? 0;
    if (count > 0) {
      throw new ConflictError(
        `Cannot delete payment status because ${count} order(s) are using it.`
      );
    }
  }
}

export const paymentStatusService = new PaymentStatusServiceClass();
