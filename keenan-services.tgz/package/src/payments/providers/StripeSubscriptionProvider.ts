import Stripe from "stripe";

/**
 * Stripe Billing provider for subscription management.
 * Separate from StripeProvider (which handles PaymentIntents).
 */
export class StripeSubscriptionProvider {
  private stripe: Stripe;

  constructor(secretKey: string) {
    this.stripe = new Stripe(secretKey);
  }

  /** Convert decimal string (e.g., "14.95") to cents (1495) */
  private toCents(amount: string): number {
    return Math.round(parseFloat(amount) * 100);
  }

  /**
   * Get or create a Stripe customer by email.
   */
  async getOrCreateCustomer(
    email: string,
    name?: string,
    metadata?: Record<string, string>
  ): Promise<string> {
    // Search for existing customer
    const existing = await this.stripe.customers.list({
      email,
      limit: 1,
    });

    if (existing.data.length > 0) {
      return existing.data[0].id;
    }

    // Create new customer
    const customer = await this.stripe.customers.create({
      email,
      name,
      metadata,
    });

    return customer.id;
  }

  /**
   * Create a Stripe subscription.
   * Returns the subscription ID, client secret for payment confirmation, and status.
   */
  async createSubscription(
    stripeCustomerId: string,
    stripePriceId: string,
    opts?: {
      trialPeriodDays?: number;
      metadata?: Record<string, string>;
    }
  ): Promise<{
    subscriptionId: string;
    clientSecret: string | null;
    status: string;
  }> {
    const params: Stripe.SubscriptionCreateParams = {
      customer: stripeCustomerId,
      items: [{ price: stripePriceId }],
      payment_behavior: "default_incomplete",
      payment_settings: {
        save_default_payment_method: "on_subscription",
      },
      expand: ["latest_invoice.payment_intent"],
      metadata: opts?.metadata,
    };

    if (opts?.trialPeriodDays && opts.trialPeriodDays > 0) {
      params.trial_period_days = opts.trialPeriodDays;
    }

    const subscription = await this.stripe.subscriptions.create(params);

    // Extract client secret from the invoice (Stripe v20+: confirmation_secret)
    let clientSecret: string | null = null;
    const invoice = subscription.latest_invoice;
    if (invoice && typeof invoice === "object") {
      const inv = invoice as Stripe.Invoice;
      if (inv.confirmation_secret?.client_secret) {
        clientSecret = inv.confirmation_secret.client_secret;
      }
    }

    return {
      subscriptionId: subscription.id,
      clientSecret,
      status: subscription.status,
    };
  }

  /**
   * Cancel a Stripe subscription.
   */
  async cancelSubscription(stripeSubId: string, atPeriodEnd: boolean = true) {
    if (atPeriodEnd) {
      const subscription = await this.stripe.subscriptions.update(stripeSubId, {
        cancel_at_period_end: true,
      });
      return {
        subscriptionId: subscription.id,
        status: subscription.status,
        cancelAtPeriodEnd: subscription.cancel_at_period_end,
      };
    }

    const subscription = await this.stripe.subscriptions.cancel(stripeSubId);
    return {
      subscriptionId: subscription.id,
      status: subscription.status,
      cancelAtPeriodEnd: false,
    };
  }

  /**
   * Resume a cancelled subscription (undo cancel_at_period_end).
   */
  async resumeSubscription(stripeSubId: string) {
    const subscription = await this.stripe.subscriptions.update(stripeSubId, {
      cancel_at_period_end: false,
    });
    return {
      subscriptionId: subscription.id,
      status: subscription.status,
      cancelAtPeriodEnd: subscription.cancel_at_period_end,
    };
  }

  /**
   * Create a Stripe Billing Portal session for the customer to manage
   * payment methods, view invoices, etc.
   */
  async createBillingPortalSession(
    stripeCustomerId: string,
    returnUrl: string
  ): Promise<string> {
    const session = await this.stripe.billingPortal.sessions.create({
      customer: stripeCustomerId,
      return_url: returnUrl,
    });
    return session.url;
  }

  /**
   * Create a Stripe product (for admin plan setup).
   */
  async createProduct(
    name: string,
    metadata?: Record<string, string>
  ): Promise<string> {
    const product = await this.stripe.products.create({
      name,
      metadata,
    });
    return product.id;
  }

  /**
   * Create a Stripe recurring price for a product.
   */
  async createPrice(
    productId: string,
    amount: string,
    currency: string,
    interval: "day" | "week" | "month" | "year",
    intervalCount: number = 1
  ): Promise<string> {
    const price = await this.stripe.prices.create({
      product: productId,
      unit_amount: this.toCents(amount),
      currency: currency.toLowerCase(),
      recurring: {
        interval,
        interval_count: intervalCount,
      },
    });
    return price.id;
  }

  /**
   * Construct and verify a Stripe webhook event.
   */
  constructWebhookEvent(
    payload: string | Buffer,
    signature: string,
    webhookSecret: string
  ): Stripe.Event {
    return this.stripe.webhooks.constructEvent(payload, signature, webhookSecret);
  }
}
