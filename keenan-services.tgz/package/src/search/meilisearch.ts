import { MeiliSearch, type SearchParams, type SearchResponse } from "meilisearch";
import { eq, and, inArray, gt, sql } from "drizzle-orm";
import { getCommerceDb } from "../db";
import {
  products,
  brands,
  categories,
  productCategories,
  productImages,
  productChannelAssignments,
  productVariants,
} from "../schema";

// ── Types ──────────────────────────────────────────────────────────────

export interface MeilisearchProductDocument {
  id: number;
  name: string;
  sku: string | null;
  urlPath: string | null;
  description: string | null;
  descriptionShort: string | null;
  price: number;
  salePrice: number | null;
  costPrice: number | null;
  brandId: number | null;
  brandName: string | null;
  categoryIds: number[];
  categoryNames: string[];
  searchKeywords: string | null;
  isFeatured: boolean;
  isOnSale: boolean;
  thumbnailUrl: string | null;
  createdAt: number; // unix timestamp for sorting
}

export interface MeilisearchSearchResult {
  hits: MeilisearchProductDocument[];
  query: string;
  processingTimeMs: number;
  estimatedTotalHits: number;
  facetDistribution?: Record<string, Record<string, number>>;
}

// ── Client Singleton ──────────────────────────────────────────────────

let client: MeiliSearch | null = null;

function getClient(): MeiliSearch | null {
  if (client) return client;

  const url = process.env.MEILI_URL;
  const apiKey = process.env.MEILI_API_KEY;

  if (!url) return null;

  client = new MeiliSearch({ host: url, apiKey: apiKey || undefined });
  return client;
}

function getIndexName(channelId: number): string {
  return `products_channel_${channelId}`;
}

// ── Index Configuration ───────────────────────────────────────────────

const INDEX_SETTINGS = {
  searchableAttributes: [
    "name",
    "sku",
    "brandName",
    "categoryNames",
    "searchKeywords",
    "description",
  ],
  filterableAttributes: [
    "brandName",
    "categoryNames",
    "categoryIds",
    "price",
    "salePrice",
    "isFeatured",
    "isOnSale",
  ],
  sortableAttributes: ["name", "price", "createdAt"],
  rankingRules: [
    "words",
    "typo",
    "exactness",
    "proximity",
    "attribute",
    "sort",
  ],
  typoTolerance: {
    minWordSizeForTypos: {
      oneTypo: 4,
      twoTypos: 8,
    },
  },
};

/**
 * Ensure the product index exists for a channel with correct settings.
 * Idempotent — safe to call multiple times.
 */
export async function ensureProductIndex(channelId: number): Promise<boolean> {
  const meili = getClient();
  if (!meili) return false;

  try {
    const indexName = getIndexName(channelId);
    // createIndex is idempotent — returns the task if index already exists
    await meili.createIndex(indexName, { primaryKey: "id" });
    // Apply settings (always updates to latest config)
    const index = meili.index(indexName);
    await index.updateSettings(INDEX_SETTINGS);
    return true;
  } catch (err) {
    console.error(`[meilisearch] Failed to ensure index for channel ${channelId}:`, (err as Error).message);
    return false;
  }
}

// ── Document Building ─────────────────────────────────────────────────

/**
 * Build a Meilisearch document for a single product.
 * Fetches brand, categories, and thumbnail from the database.
 */
export async function buildProductDocument(
  productId: number
): Promise<MeilisearchProductDocument | null> {
  const db = getCommerceDb();

  // Fetch product
  const [product] = await db
    .select()
    .from(products)
    .where(and(eq(products.id, productId), eq(products.isDeleted, false)))
    .limit(1);

  if (!product) return null;

  // Fetch brand name
  let brandName: string | null = null;
  if (product.brandId) {
    const [brand] = await db
      .select({ name: brands.name })
      .from(brands)
      .where(eq(brands.id, product.brandId))
      .limit(1);
    if (brand) brandName = brand.name;
  }

  // Fetch category names + IDs
  const catRows = await db
    .selectDistinct({
      id: categories.id,
      name: categories.name,
    })
    .from(productCategories)
    .innerJoin(categories, eq(categories.id, productCategories.categoryId))
    .where(eq(productCategories.productId, productId));

  // Fetch thumbnail
  const [thumbnail] = await db
    .select({ urlThumbnail: productImages.urlThumbnail, urlStandard: productImages.urlStandard })
    .from(productImages)
    .where(
      and(
        eq(productImages.productId, productId),
        eq(productImages.isThumbnail, true)
      )
    )
    .limit(1);

  let price = parseFloat(product.price) || 0;
  const salePrice = product.salePrice ? parseFloat(product.salePrice) : null;

  // For configurable products with $0 base price, use the lowest variant price
  if (price === 0) {
    const [minRow] = await db
      .select({ minPrice: sql<string>`MIN(${productVariants.price})` })
      .from(productVariants)
      .where(and(eq(productVariants.productId, productId), gt(productVariants.price, "0")));
    if (minRow?.minPrice) price = parseFloat(minRow.minPrice);
  }

  return {
    id: product.id,
    name: product.name,
    sku: product.sku,
    urlPath: product.urlPath,
    description: product.description,
    descriptionShort: product.descriptionShort,
    price,
    salePrice,
    costPrice: product.costPrice ? parseFloat(product.costPrice) : null,
    brandId: product.brandId,
    brandName,
    categoryIds: catRows.map((c) => c.id),
    categoryNames: catRows.map((c) => c.name),
    searchKeywords: product.searchKeywords,
    isFeatured: product.isFeatured ?? false,
    isOnSale: salePrice !== null && salePrice > 0 && salePrice < price,
    thumbnailUrl: thumbnail?.urlThumbnail || thumbnail?.urlStandard || null,
    createdAt: product.createdAt ? Math.floor(new Date(product.createdAt).getTime() / 1000) : 0,
  };
}

/**
 * Build documents in batch — more efficient than one-by-one.
 * Returns a map of productId -> document.
 */
export async function buildProductDocumentsBatch(
  productIds: number[]
): Promise<Map<number, MeilisearchProductDocument>> {
  if (productIds.length === 0) return new Map();

  const db = getCommerceDb();

  // Fetch products
  const productRows = await db
    .select()
    .from(products)
    .where(and(inArray(products.id, productIds), eq(products.isDeleted, false)));

  if (productRows.length === 0) return new Map();

  // Fetch brands
  const brandIds = [...new Set(productRows.map((p) => p.brandId).filter(Boolean))] as number[];
  const brandMap = new Map<number, string>();
  if (brandIds.length > 0) {
    const brandRows = await db
      .select({ id: brands.id, name: brands.name })
      .from(brands)
      .where(inArray(brands.id, brandIds));
    for (const b of brandRows) brandMap.set(b.id, b.name);
  }

  // Fetch categories
  const catRows = await db
    .selectDistinct({
      productId: productCategories.productId,
      categoryId: categories.id,
      categoryName: categories.name,
    })
    .from(productCategories)
    .innerJoin(categories, eq(categories.id, productCategories.categoryId))
    .where(inArray(productCategories.productId, productIds));

  const catMap = new Map<number, { ids: number[]; names: string[] }>();
  for (const row of catRows) {
    const existing = catMap.get(row.productId) || { ids: [], names: [] };
    existing.ids.push(row.categoryId);
    existing.names.push(row.categoryName);
    catMap.set(row.productId, existing);
  }

  // Fetch thumbnails
  const thumbnailRows = await db
    .select({
      productId: productImages.productId,
      urlThumbnail: productImages.urlThumbnail,
      urlStandard: productImages.urlStandard,
    })
    .from(productImages)
    .where(
      and(
        inArray(productImages.productId, productIds),
        eq(productImages.isThumbnail, true)
      )
    );

  const thumbnailMap = new Map(
    thumbnailRows.map((t) => [t.productId, t.urlThumbnail || t.urlStandard])
  );

  // Fetch min variant prices for $0-price products
  const zeroPriceIds = productRows.filter((p) => !parseFloat(p.price)).map((p) => p.id);
  const minVariantPriceMap = new Map<number, number>();
  if (zeroPriceIds.length > 0) {
    const minRows = await db
      .select({
        productId: productVariants.productId,
        minPrice: sql<string>`MIN(${productVariants.price})`,
      })
      .from(productVariants)
      .where(and(inArray(productVariants.productId, zeroPriceIds), gt(productVariants.price, "0")))
      .groupBy(productVariants.productId);
    for (const row of minRows) {
      minVariantPriceMap.set(row.productId, parseFloat(row.minPrice));
    }
  }

  // Build documents
  const docs = new Map<number, MeilisearchProductDocument>();
  for (const product of productRows) {
    let price = parseFloat(product.price) || 0;
    if (price === 0) price = minVariantPriceMap.get(product.id) ?? 0;
    const salePrice = product.salePrice ? parseFloat(product.salePrice) : null;
    const cats = catMap.get(product.id) || { ids: [], names: [] };

    docs.set(product.id, {
      id: product.id,
      name: product.name,
      sku: product.sku,
      urlPath: product.urlPath,
      description: product.description,
      descriptionShort: product.descriptionShort,
      price,
      salePrice,
      costPrice: product.costPrice ? parseFloat(product.costPrice) : null,
      brandId: product.brandId,
      brandName: product.brandId ? brandMap.get(product.brandId) ?? null : null,
      categoryIds: cats.ids,
      categoryNames: cats.names,
      searchKeywords: product.searchKeywords,
      isFeatured: product.isFeatured ?? false,
      isOnSale: salePrice !== null && salePrice > 0 && salePrice < price,
      thumbnailUrl: thumbnailMap.get(product.id) || null,
      createdAt: product.createdAt ? Math.floor(new Date(product.createdAt).getTime() / 1000) : 0,
    });
  }

  return docs;
}

// ── Indexing ───────────────────────────────────────────────────────────

/**
 * Index a single product into a channel's Meilisearch index.
 */
export async function indexProduct(
  channelId: number,
  doc: MeilisearchProductDocument
): Promise<boolean> {
  const meili = getClient();
  if (!meili) return false;

  try {
    const index = meili.index(getIndexName(channelId));
    await index.addDocuments([doc]);
    return true;
  } catch (err) {
    console.error(`[meilisearch] Failed to index product ${doc.id} for channel ${channelId}:`, (err as Error).message);
    return false;
  }
}

/**
 * Index a batch of products into a channel's Meilisearch index.
 */
export async function indexProductsBatch(
  channelId: number,
  docs: MeilisearchProductDocument[]
): Promise<boolean> {
  if (docs.length === 0) return true;

  const meili = getClient();
  if (!meili) return false;

  try {
    const index = meili.index(getIndexName(channelId));
    await index.addDocuments(docs);
    return true;
  } catch (err) {
    console.error(`[meilisearch] Failed to batch index ${docs.length} products for channel ${channelId}:`, (err as Error).message);
    return false;
  }
}

/**
 * Remove a product from a channel's Meilisearch index.
 */
export async function removeProduct(
  channelId: number,
  productId: number
): Promise<boolean> {
  const meili = getClient();
  if (!meili) return false;

  try {
    const index = meili.index(getIndexName(channelId));
    await index.deleteDocument(productId);
    return true;
  } catch (err) {
    console.error(`[meilisearch] Failed to remove product ${productId} from channel ${channelId}:`, (err as Error).message);
    return false;
  }
}

/**
 * Remove a product from ALL channel indexes it was assigned to.
 */
export async function removeProductFromAllChannels(productId: number): Promise<void> {
  const db = getCommerceDb();

  const assignments = await db
    .select({ channelId: productChannelAssignments.channelId })
    .from(productChannelAssignments)
    .where(eq(productChannelAssignments.productId, productId));

  await Promise.allSettled(
    assignments.map((a) => removeProduct(a.channelId, productId))
  );
}

// ── Search ─────────────────────────────────────────────────────────────

export interface SearchOptions {
  limit?: number;
  offset?: number;
  filter?: string | string[];
  sort?: string[];
  facets?: string[];
  attributesToHighlight?: string[];
  highlightPreTag?: string;
  highlightPostTag?: string;
}

/**
 * Search products in a channel's Meilisearch index.
 */
export async function searchProducts(
  channelId: number,
  query: string,
  options: SearchOptions = {}
): Promise<MeilisearchSearchResult> {
  const meili = getClient();
  if (!meili) {
    throw new Error("Meilisearch is not configured");
  }

  const {
    limit = 20,
    offset = 0,
    filter,
    sort,
    facets,
    attributesToHighlight = ["name"],
    highlightPreTag = "<mark>",
    highlightPostTag = "</mark>",
  } = options;

  const searchParams: SearchParams = {
    limit,
    offset,
    attributesToHighlight,
    highlightPreTag,
    highlightPostTag,
  };

  if (filter) searchParams.filter = filter;
  if (sort) searchParams.sort = sort;
  if (facets) searchParams.facets = facets;

  await ensureProductIndex(channelId);
  const index = meili.index(getIndexName(channelId));
  const result: SearchResponse<MeilisearchProductDocument> = await index.search(query, searchParams);

  return {
    hits: result.hits,
    query: result.query,
    processingTimeMs: result.processingTimeMs,
    estimatedTotalHits: result.estimatedTotalHits ?? result.hits.length,
    facetDistribution: result.facetDistribution,
  };
}

/**
 * Get the channel IDs a product is assigned to.
 */
export async function getProductChannelIds(productId: number): Promise<number[]> {
  const db = getCommerceDb();
  const assignments = await db
    .select({ channelId: productChannelAssignments.channelId })
    .from(productChannelAssignments)
    .where(eq(productChannelAssignments.productId, productId));

  return assignments.map((a) => a.channelId);
}

/**
 * Sync a product to all its assigned channel indexes.
 * Used by ProductService hooks.
 */
export async function syncProductToMeilisearch(productId: number): Promise<void> {
  const doc = await buildProductDocument(productId);
  if (!doc) return;

  const channelIds = await getProductChannelIds(productId);

  await Promise.allSettled(
    channelIds.map(async (channelId) => {
      await ensureProductIndex(channelId);
      await indexProduct(channelId, doc);
    })
  );
}
