import { eq, and } from "drizzle-orm";
import { PgColumn } from "drizzle-orm/pg-core";
import { draws, drawEntries, subscriptions, customers } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { ForeignKeyValidation, UniqueConstraint } from "../../base/types";

/**
 * Service for managing draw entries (nested under draws).
 */
class DrawEntryServiceClass extends NestedService<typeof draws, typeof drawEntries> {
  constructor() {
    super(draws, drawEntries, {
      resourceName: "Draw Entry",
      parentResourceName: "Draw",
      defaultSort: "id",
      sortColumns: {
        id: drawEntries.id,
        created_at: drawEntries.createdAt,
        entry_count: drawEntries.entryCount,
      },
      filterColumns: {
        customer_id: drawEntries.customerId,
        subscription_id: drawEntries.subscriptionId,
        source: drawEntries.source,
        status: drawEntries.status,
      },
      allowedFilters: ["customer_id", "subscription_id", "source", "status"],
      timestamps: {
        created: "createdAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return draws.id;
  }

  protected getParentForeignKey(): PgColumn {
    return drawEntries.drawId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "drawId";
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: customers,
        column: customers.id,
        resourceName: "Customer",
        fieldName: "customerId",
      },
      {
        table: subscriptions,
        column: subscriptions.id,
        resourceName: "Subscription",
        fieldName: "subscriptionId",
        optional: true,
      },
    ];
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [
          { column: drawEntries.drawId, fieldName: "drawId" },
          { column: drawEntries.subscriptionId, fieldName: "subscriptionId" },
          { column: drawEntries.source, fieldName: "source" },
        ],
        message: "This subscription already has an entry from this source in this draw.",
        composite: true,
      },
    ];
  }

  /**
   * Get all entries for a customer across all draws in a channel.
   */
  async getEntriesForCustomer(customerId: number, channelId: number) {
    return this.db
      .select({
        entry: drawEntries,
        drawName: draws.name,
        drawStatus: draws.status,
      })
      .from(drawEntries)
      .innerJoin(draws, eq(drawEntries.drawId, draws.id))
      .where(
        and(
          eq(drawEntries.customerId, customerId),
          eq(draws.channelId, channelId)
        )
      );
  }

  /**
   * Forfeit all active entries for a subscription (when subscription ends).
   */
  async forfeitForSubscription(subscriptionId: number) {
    return this.db
      .update(drawEntries)
      .set({
        status: "forfeited",
        forfeitedAt: new Date(),
      })
      .where(
        and(
          eq(drawEntries.subscriptionId, subscriptionId),
          eq(drawEntries.status, "active")
        )
      );
  }

  /**
   * Accumulate entries for a draw (upsert: increment if exists, create if not).
   */
  async accumulateEntries(
    drawId: number,
    subscriptionId: number,
    customerId: number,
    entryCount: number
  ) {
    // Check if entry already exists
    const [existing] = await this.db
      .select()
      .from(drawEntries)
      .where(
        and(
          eq(drawEntries.drawId, drawId),
          eq(drawEntries.subscriptionId, subscriptionId),
          eq(drawEntries.source, "subscription")
        )
      )
      .limit(1);

    if (existing) {
      // Increment entry count
      const newCount = (existing.entryCount ?? 1) + entryCount;
      const [updated] = await this.db
        .update(drawEntries)
        .set({ entryCount: newCount })
        .where(eq(drawEntries.id, existing.id))
        .returning();
      return updated;
    }

    // Create new entry
    const [created] = await this.db
      .insert(drawEntries)
      .values({
        drawId,
        subscriptionId,
        customerId,
        entryCount,
        source: "subscription",
        status: "active",
      })
      .returning();
    return created;
  }
}

export const drawEntryService = new DrawEntryServiceClass();
