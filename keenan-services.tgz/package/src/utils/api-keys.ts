import { createHash, randomBytes } from "crypto";

// Key format: ck_<32 random bytes in hex> = ck_ + 64 chars = 67 chars total
const KEY_PREFIX = "ck_";

/**
 * Generate a new API key
 * Returns both the full key (to show once) and the hash (to store)
 */
export function generateApiKey(): {
  fullKey: string;
  keyPrefix: string;
  keyHash: string;
} {
  // Generate 32 cryptographically secure random bytes
  const randomPart = randomBytes(32).toString("hex");
  const fullKey = `${KEY_PREFIX}${randomPart}`;

  // Key prefix for display (first 12 chars after ck_)
  const keyPrefix = `${KEY_PREFIX}${randomPart.substring(0, 12)}`;

  // Hash the full key with SHA-256
  const keyHash = hashApiKey(fullKey);

  return {
    fullKey,
    keyPrefix,
    keyHash,
  };
}

/**
 * Hash an API key using SHA-256
 */
export function hashApiKey(key: string): string {
  return createHash("sha256").update(key).digest("hex");
}

/**
 * Verify an API key against a stored hash
 */
export function verifyApiKey(key: string, storedHash: string): boolean {
  const keyHash = hashApiKey(key);
  // Use timing-safe comparison to prevent timing attacks
  if (keyHash.length !== storedHash.length) return false;

  let result = 0;
  for (let i = 0; i < keyHash.length; i++) {
    result |= keyHash.charCodeAt(i) ^ storedHash.charCodeAt(i);
  }
  return result === 0;
}

/**
 * Mask an API key for display (shows prefix only)
 */
export function maskApiKey(keyPrefix: string): string {
  return `${keyPrefix}${"•".repeat(20)}`;
}

/**
 * Available API key scopes with descriptions
 */
export const API_KEY_SCOPES = [
  {
    value: "full_access",
    label: "Full Access",
    description: "Complete read and write access to all resources",
    category: "all",
  },
  {
    value: "read_products",
    label: "Read Products",
    description: "View products, variants, and options",
    category: "products",
  },
  {
    value: "write_products",
    label: "Write Products",
    description: "Create, update, and delete products",
    category: "products",
  },
  {
    value: "read_orders",
    label: "Read Orders",
    description: "View orders, shipments, and transactions",
    category: "orders",
  },
  {
    value: "write_orders",
    label: "Write Orders",
    description: "Create and update orders",
    category: "orders",
  },
  {
    value: "read_customers",
    label: "Read Customers",
    description: "View customer profiles and addresses",
    category: "customers",
  },
  {
    value: "write_customers",
    label: "Write Customers",
    description: "Create and update customer records",
    category: "customers",
  },
  {
    value: "read_inventory",
    label: "Read Inventory",
    description: "View stock levels and locations",
    category: "inventory",
  },
  {
    value: "write_inventory",
    label: "Write Inventory",
    description: "Update stock levels",
    category: "inventory",
  },
  {
    value: "read_pricing",
    label: "Read Pricing",
    description: "View price lists and promotions",
    category: "pricing",
  },
  {
    value: "write_pricing",
    label: "Write Pricing",
    description: "Manage price lists and promotions",
    category: "pricing",
  },
  {
    value: "read_accounts",
    label: "Read Accounts",
    description: "View accounts, contacts, locations, addresses, and sales reps",
    category: "accounts",
  },
  {
    value: "write_accounts",
    label: "Write Accounts",
    description: "Create and update accounts, contacts, locations, and addresses",
    category: "accounts",
  },
  {
    value: "read_content",
    label: "Read Content",
    description: "View categories, brands, and content",
    category: "content",
  },
  {
    value: "write_content",
    label: "Write Content",
    description: "Manage categories, brands, and content",
    category: "content",
  },
] as const;

/**
 * Check if a key has a specific scope
 */
export function hasScope(keyScopes: string[], requiredScope: string): boolean {
  // Full access grants all permissions
  if (keyScopes.includes("full_access")) return true;
  return keyScopes.includes(requiredScope);
}

/**
 * Check if a key has read access to a resource
 */
export function hasReadAccess(keyScopes: string[], resource: string): boolean {
  return hasScope(keyScopes, `read_${resource}`);
}

/**
 * Check if a key has write access to a resource
 */
export function hasWriteAccess(keyScopes: string[], resource: string): boolean {
  return hasScope(keyScopes, `write_${resource}`);
}
