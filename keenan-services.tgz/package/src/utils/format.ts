/**
 * Shared utility functions for formatting across the application
 */

/**
 * Format a price value as currency
 * @param price - The price value as a string (e.g., "99.99")
 * @param currency - The currency code (defaults to "AUD")
 * @returns Formatted price string (e.g., "$99.99")
 */
export function formatPrice(price: string | null, currency: string = "AUD"): string {
  if (!price) return "$0.00";
  return new Intl.NumberFormat("en-AU", {
    style: "currency",
    currency: currency,
  }).format(parseFloat(price));
}

/**
 * Format a date string for display (short format without time)
 * @param dateStr - ISO date string or null
 * @returns Formatted date string (e.g., "15 Jan 2025") or "-" if null
 */
export function formatDate(dateStr: string | null): string {
  if (!dateStr) return "-";
  return new Date(dateStr).toLocaleDateString("en-AU", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

/**
 * Format a date string with time
 * @param dateStr - ISO date string or null
 * @returns Formatted date-time string (e.g., "15 Jan 2025, 2:30 PM") or "-" if null
 */
export function formatDateTime(dateStr: string | null): string {
  if (!dateStr) return "-";
  return new Date(dateStr).toLocaleDateString("en-AU", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/**
 * Format store credit as currency, returns "-" if zero or null
 * @param credit - Store credit value as string
 * @returns Formatted credit string or "-"
 */
export function formatStoreCredit(credit: string | null): string {
  if (!credit || parseFloat(credit) === 0) return "-";
  return formatPrice(credit);
}

/**
 * Address interface for formatting
 */
export interface FormattableAddress {
  firstName?: string | null;
  lastName?: string | null;
  company?: string | null;
  address1?: string | null;
  address2?: string | null;
  city?: string | null;
  state?: string | null;
  postalCode?: string | null;
  country?: string | null;
}

/**
 * Format an address into an array of display lines
 * @param addr - Address object
 * @returns Array of non-empty address lines
 */
export function formatAddressLines(addr: FormattableAddress | null): string[] {
  if (!addr) return [];
  return [
    [addr.firstName, addr.lastName].filter(Boolean).join(" "),
    addr.company,
    addr.address1,
    addr.address2,
    [addr.city, addr.state, addr.postalCode].filter(Boolean).join(", "),
    addr.country,
  ].filter((line): line is string => Boolean(line));
}

/**
 * Get display name from first/last name or fallback
 * @param firstName - First name
 * @param lastName - Last name
 * @param fallback - Fallback value if no name (defaults to "-")
 * @returns Display name string
 */
export function getDisplayName(
  firstName: string | null | undefined,
  lastName: string | null | undefined,
  fallback: string = "-"
): string {
  const name = [firstName, lastName].filter(Boolean).join(" ");
  return name || fallback;
}

/**
 * Format a number for display with locale-specific formatting
 * @param value - The numeric value
 * @param options - Intl.NumberFormat options
 * @returns Formatted number string
 */
export function formatNumber(
  value: number,
  options?: Intl.NumberFormatOptions
): string {
  return new Intl.NumberFormat("en-AU", options).format(value);
}

/**
 * Truncate text with ellipsis
 * @param text - Text to truncate
 * @param maxLength - Maximum length before truncation
 * @returns Truncated text with ellipsis or original text
 */
export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength - 1) + "\u2026";
}
