import { eq, and } from "drizzle-orm";
import { partnerOffers, partnerDiscountCodes, channels } from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation, DependencyCheck, IncludeConfig } from "../../base/types";

/**
 * Service for managing partner discount offers per channel.
 */
class PartnerOfferServiceClass extends BaseService<typeof partnerOffers> {
  constructor() {
    super(partnerOffers, {
      resourceName: "Partner Offer",
      defaultSort: "id",
      sortColumns: {
        id: partnerOffers.id,
        partner_name: partnerOffers.partnerName,
        title: partnerOffers.title,
        category: partnerOffers.category,
        created_at: partnerOffers.createdAt,
      },
      filterColumns: {
        channel_id: partnerOffers.channelId,
        is_active: partnerOffers.isActive,
        category: partnerOffers.category,
        discount_type: partnerOffers.discountType,
      },
      allowedFilters: ["channel_id", "is_active", "category", "discount_type"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: channels,
        column: channels.id,
        resourceName: "Channel",
        fieldName: "channelId",
      },
    ];
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: partnerDiscountCodes,
        foreignKeyColumn: partnerDiscountCodes.partnerOfferId,
        resourceName: "discount code",
        message:
          "Cannot delete partner offer because it has {count} generated discount code(s).",
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "codes",
        table: partnerDiscountCodes,
        foreignKey: partnerDiscountCodes.partnerOfferId,
      },
    ];
  }

  /**
   * List active partner offers for a channel.
   */
  async listActiveForChannel(channelId: number, category?: string) {
    const conditions = [
      eq(partnerOffers.channelId, channelId),
      eq(partnerOffers.isActive, true),
    ];
    if (category) {
      conditions.push(eq(partnerOffers.category, category));
    }

    return this.db
      .select()
      .from(partnerOffers)
      .where(and(...conditions))
      .orderBy(partnerOffers.partnerName);
  }
}

export const partnerOfferService = new PartnerOfferServiceClass();
