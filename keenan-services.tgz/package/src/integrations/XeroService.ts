import { XeroClient } from "xero-node";
import { storeSettingsService } from "../services/settings/StoreSettingsService";

// ============================================================================
// Types
// ============================================================================

export interface XeroConfig {
  client_id: string;
  client_secret: string;
  redirect_uri: string;
  access_token?: string;
  refresh_token?: string;
  token_expiry?: string;
  tenant_id?: string;
}

export interface XeroConnectionStatus {
  connected: boolean;
  tenant_name?: string;
  token_expiry?: string;
  error?: string;
}

// ============================================================================
// XeroService
// ============================================================================

class XeroServiceClass {
  private readonly MASTER_KEY = "xero_integration";
  private readonly OVERRIDES_KEY = "xero_channel_overrides";
  private readonly SCOPES = [
    "openid",
    "profile",
    "email",
    "accounting.transactions",
    "accounting.contacts",
    "accounting.settings.read",
    "offline_access",
  ];

  // --------------------------------------------------------------------------
  // Config Resolution (per-channel with master fallback)
  // --------------------------------------------------------------------------

  async getMasterConfig(): Promise<XeroConfig | null> {
    try {
      const setting = await storeSettingsService.getByKey(this.MASTER_KEY);
      return (setting.setting_value as XeroConfig) || null;
    } catch {
      return null;
    }
  }

  async getChannelOverrides(): Promise<Record<string, XeroConfig>> {
    try {
      const setting = await storeSettingsService.getByKey(this.OVERRIDES_KEY);
      return (setting.setting_value as Record<string, XeroConfig>) || {};
    } catch {
      return {};
    }
  }

  async getConfigForChannel(channelId: number): Promise<XeroConfig> {
    const overrides = await this.getChannelOverrides();
    const override = overrides[String(channelId)];
    if (override?.access_token) return override;

    const master = await this.getMasterConfig();
    if (!master) throw new Error("Xero is not configured. Connect to Xero first.");
    if (!master.access_token) throw new Error("Xero is not connected. Complete the OAuth flow.");
    return master;
  }

  // --------------------------------------------------------------------------
  // OAuth2 Flow
  // --------------------------------------------------------------------------

  async getAuthorizationUrl(redirectUri: string, state?: string): Promise<string> {
    const config = await this.getMasterConfig();
    if (!config?.client_id) {
      throw new Error("Xero client_id not configured.");
    }

    const params = new URLSearchParams({
      response_type: "code",
      client_id: config.client_id,
      redirect_uri: redirectUri,
      scope: this.SCOPES.join(" "),
      ...(state ? { state } : {}),
    });

    return `https://login.xero.com/identity/connect/authorize?${params.toString()}`;
  }

  async handleCallback(
    code: string,
    redirectUri: string
  ): Promise<{ success: boolean; error?: string }> {
    const config = await this.getMasterConfig();
    if (!config?.client_id || !config?.client_secret) {
      return { success: false, error: "Xero credentials not configured." };
    }

    try {
      // Exchange code for tokens
      const tokenResponse = await fetch(
        "https://identity.xero.com/connect/token",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            Authorization: `Basic ${Buffer.from(`${config.client_id}:${config.client_secret}`).toString("base64")}`,
          },
          body: new URLSearchParams({
            grant_type: "authorization_code",
            code,
            redirect_uri: redirectUri,
          }),
        }
      );

      if (!tokenResponse.ok) {
        const err = await tokenResponse.text();
        return { success: false, error: `Token exchange failed: ${err}` };
      }

      const tokens = await tokenResponse.json() as {
        access_token: string;
        refresh_token: string;
        expires_in: number;
      };

      // Get tenant info
      const connectionsResponse = await fetch(
        "https://api.xero.com/connections",
        {
          headers: { Authorization: `Bearer ${tokens.access_token}` },
        }
      );

      let tenantId = config.tenant_id;
      if (connectionsResponse.ok) {
        const connections = await connectionsResponse.json() as Array<{ tenantId: string }>;
        if (connections.length > 0) {
          tenantId = connections[0].tenantId;
        }
      }

      // Save tokens
      const updatedConfig: XeroConfig = {
        ...config,
        access_token: tokens.access_token,
        refresh_token: tokens.refresh_token,
        token_expiry: new Date(
          Date.now() + tokens.expires_in * 1000
        ).toISOString(),
        tenant_id: tenantId,
      };

      await storeSettingsService.upsert(this.MASTER_KEY, updatedConfig, {
        description: "Xero integration configuration",
        isSensitive: true,
      });

      return { success: true };
    } catch (err) {
      return {
        success: false,
        error: err instanceof Error ? err.message : "OAuth callback failed",
      };
    }
  }

  async refreshToken(config: XeroConfig): Promise<XeroConfig> {
    if (!config.refresh_token || !config.client_id || !config.client_secret) {
      throw new Error("Cannot refresh: missing credentials.");
    }

    const response = await fetch("https://identity.xero.com/connect/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: `Basic ${Buffer.from(`${config.client_id}:${config.client_secret}`).toString("base64")}`,
      },
      body: new URLSearchParams({
        grant_type: "refresh_token",
        refresh_token: config.refresh_token,
      }),
    });

    if (!response.ok) {
      throw new Error("Token refresh failed. Re-connect to Xero.");
    }

    const tokens = await response.json() as {
      access_token: string;
      refresh_token: string;
      expires_in: number;
    };

    const updated: XeroConfig = {
      ...config,
      access_token: tokens.access_token,
      refresh_token: tokens.refresh_token,
      token_expiry: new Date(
        Date.now() + tokens.expires_in * 1000
      ).toISOString(),
    };

    return updated;
  }

  private async getClient(channelId?: number): Promise<{
    client: XeroClient;
    tenantId: string;
    config: XeroConfig;
  }> {
    let config = channelId
      ? await this.getConfigForChannel(channelId)
      : await this.getMasterConfig();

    if (!config?.access_token) {
      throw new Error("Xero is not connected.");
    }

    // Auto-refresh if expired
    if (config.token_expiry && new Date(config.token_expiry) < new Date()) {
      config = await this.refreshToken(config);
      // Save refreshed master config
      await storeSettingsService.upsert(this.MASTER_KEY, config, {
        description: "Xero integration configuration",
        isSensitive: true,
      });
    }

    const client = new XeroClient({
      clientId: config.client_id,
      clientSecret: config.client_secret,
      redirectUris: [config.redirect_uri],
      scopes: this.SCOPES,
    });

    // Set the access token directly
    client.setTokenSet({
      access_token: config.access_token!,
      refresh_token: config.refresh_token,
      token_type: "Bearer",
    });

    return {
      client,
      tenantId: config.tenant_id || "",
      config,
    };
  }

  // --------------------------------------------------------------------------
  // Disconnect
  // --------------------------------------------------------------------------

  async disconnect(): Promise<void> {
    const config = await this.getMasterConfig();
    if (!config) return;

    // Revoke token if we have one
    if (config.access_token && config.client_id && config.client_secret) {
      try {
        await fetch("https://identity.xero.com/connect/revocation", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            Authorization: `Basic ${Buffer.from(`${config.client_id}:${config.client_secret}`).toString("base64")}`,
          },
          body: new URLSearchParams({
            token: config.access_token,
          }),
        });
      } catch {
        // Best-effort revocation
      }
    }

    // Clear tokens but keep client_id/client_secret
    const cleared: XeroConfig = {
      client_id: config.client_id,
      client_secret: config.client_secret,
      redirect_uri: config.redirect_uri,
    };

    await storeSettingsService.upsert(this.MASTER_KEY, cleared, {
      description: "Xero integration configuration",
      isSensitive: true,
    });
  }

  // --------------------------------------------------------------------------
  // Connection Status
  // --------------------------------------------------------------------------

  async getConnectionStatus(): Promise<XeroConnectionStatus> {
    const config = await this.getMasterConfig();
    if (!config?.access_token) {
      return { connected: false };
    }

    try {
      const { client, tenantId } = await this.getClient();
      const response = await client.accountingApi.getOrganisations(tenantId);
      const org = response.body.organisations?.[0];

      return {
        connected: true,
        tenant_name: org?.name || "Unknown",
        token_expiry: config.token_expiry,
      };
    } catch (err) {
      return {
        connected: false,
        error: err instanceof Error ? err.message : "Connection check failed",
      };
    }
  }

  // --------------------------------------------------------------------------
  // Invoice Operations
  // --------------------------------------------------------------------------

  async createInvoice(
    channelId: number,
    data: {
      contact_name: string;
      contact_email?: string;
      line_items: Array<{
        description: string;
        quantity: number;
        unit_amount: string;
        account_code?: string;
      }>;
      reference?: string;
      due_date?: string;
      currency_code?: string;
    }
  ): Promise<{ invoice_id: string; invoice_number: string }> {
    const { client, tenantId } = await this.getClient(channelId);

    const { Invoice } = await import("xero-node");

    const invoice: InstanceType<typeof Invoice> = {
      type: Invoice.TypeEnum.ACCREC,
      contact: {
        name: data.contact_name,
        emailAddress: data.contact_email,
      },
      lineItems: data.line_items.map((item) => ({
        description: item.description,
        quantity: item.quantity,
        unitAmount: parseFloat(item.unit_amount),
        accountCode: item.account_code || "200",
      })),
      reference: data.reference,
      dueDate: data.due_date,
      currencyCode: data.currency_code as unknown as undefined,
      status: Invoice.StatusEnum.AUTHORISED,
    };

    const response = await client.accountingApi.createInvoices(tenantId, {
      invoices: [invoice],
    });

    const created = response.body.invoices?.[0];
    if (!created?.invoiceID) {
      throw new Error("Failed to create Xero invoice");
    }

    return {
      invoice_id: created.invoiceID,
      invoice_number: created.invoiceNumber || "",
    };
  }

  async syncPayment(
    channelId: number,
    data: {
      invoice_id: string;
      amount: string;
      date?: string;
      reference?: string;
      account_code?: string;
    }
  ): Promise<{ payment_id: string }> {
    const { client, tenantId } = await this.getClient(channelId);

    const payment = {
      invoice: { invoiceID: data.invoice_id },
      account: { code: data.account_code || "090" },
      amount: parseFloat(data.amount),
      date: data.date || new Date().toISOString().split("T")[0],
      reference: data.reference,
    };

    const response = await client.accountingApi.createPayment(
      tenantId,
      payment
    );

    const created = response.body.payments?.[0];
    if (!created?.paymentID) {
      throw new Error("Failed to sync payment to Xero");
    }

    return { payment_id: created.paymentID };
  }

  // --------------------------------------------------------------------------
  // Config Management
  // --------------------------------------------------------------------------

  async saveConfig(config: Partial<XeroConfig>): Promise<void> {
    const existing = await this.getMasterConfig();
    const updated = { ...existing, ...config };
    await storeSettingsService.upsert(this.MASTER_KEY, updated, {
      description: "Xero integration configuration",
      isSensitive: true,
    });
  }

  async saveChannelOverride(
    channelId: number,
    config: Partial<XeroConfig>
  ): Promise<void> {
    const overrides = await this.getChannelOverrides();
    overrides[String(channelId)] = {
      ...overrides[String(channelId)],
      ...config,
    } as XeroConfig;
    await storeSettingsService.upsert(this.OVERRIDES_KEY, overrides, {
      description: "Per-channel Xero configuration overrides",
      isSensitive: true,
    });
  }

  async removeChannelOverride(channelId: number): Promise<void> {
    const overrides = await this.getChannelOverrides();
    delete overrides[String(channelId)];
    await storeSettingsService.upsert(this.OVERRIDES_KEY, overrides, {
      description: "Per-channel Xero configuration overrides",
      isSensitive: true,
    });
  }
}

export const xeroService = new XeroServiceClass();
