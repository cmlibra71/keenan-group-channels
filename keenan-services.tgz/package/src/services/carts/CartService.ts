import { eq, and } from "drizzle-orm";
import {
  carts,
  channels,
  customers,
  accounts,
  contacts,
  cartItems,
  products,
  productVariants,
} from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation, DependencyCheck, IncludeConfig } from "../../base/types";

/**
 * Service for managing shopping carts.
 */
class CartServiceClass extends BaseService<typeof carts> {
  constructor() {
    super(carts, {
      resourceName: "Cart",
      defaultSort: "id",
      sortColumns: {
        id: carts.id,
        created_at: carts.createdAt,
        updated_at: carts.updatedAt,
      },
      filterColumns: {
        channel_id: carts.channelId,
        customer_id: carts.customerId,
        account_id: carts.accountId,
        contact_id: carts.contactId,
        status: carts.status,
      },
      allowedFilters: ["channel_id", "customer_id", "account_id", "contact_id", "status"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: channels,
        column: channels.id,
        resourceName: "Channel",
        fieldName: "channelId",
      },
      {
        table: customers,
        column: customers.id,
        resourceName: "Customer",
        fieldName: "customerId",
        optional: true,
      },
      {
        table: accounts,
        column: accounts.id,
        resourceName: "Account",
        fieldName: "accountId",
        optional: true,
      },
      {
        table: contacts,
        column: contacts.id,
        resourceName: "Contact",
        fieldName: "contactId",
        optional: true,
      },
    ];
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: cartItems,
        foreignKeyColumn: cartItems.cartId,
        resourceName: "cart item",
        message: "Cannot delete cart because it has {count} item(s). Remove items first or delete the cart with its items.",
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "items",
        table: cartItems,
        foreignKey: cartItems.cartId,
      },
    ];
  }

  // ── Storefront convenience methods ──────────────────────────────────

  /**
   * Find an active cart by its UUID (from cookie).
   */
  async getByUuid(uuid: string) {
    const [cart] = await this.db
      .select()
      .from(carts)
      .where(and(eq(carts.uuid, uuid), eq(carts.status, "active")))
      .limit(1);
    return cart || null;
  }

  /**
   * Get cart with items joined to product/variant display info.
   */
  async getWithItems(cartId: number) {
    const [cart] = await this.db
      .select()
      .from(carts)
      .where(eq(carts.id, cartId))
      .limit(1);
    if (!cart) return null;

    const items = await this.db
      .select({
        id: cartItems.id,
        productId: cartItems.productId,
        variantId: cartItems.variantId,
        quantity: cartItems.quantity,
        listPrice: cartItems.listPrice,
        salePrice: cartItems.salePrice,
        extendedListPrice: cartItems.extendedListPrice,
        extendedSalePrice: cartItems.extendedSalePrice,
        productName: products.name,
        productSlug: products.urlPath,
        productSku: products.sku,
        variantSku: productVariants.sku,
        variantOptionName: productVariants.optionDisplayName,
      })
      .from(cartItems)
      .innerJoin(products, eq(cartItems.productId, products.id))
      .leftJoin(productVariants, eq(cartItems.variantId, productVariants.id))
      .where(eq(cartItems.cartId, cartId));

    return { ...cart, items };
  }

  /**
   * Transition cart to completed status.
   */
  async markCompleted(cartId: number) {
    const [updated] = await this.db
      .update(carts)
      .set({ status: "completed", updatedAt: new Date() })
      .where(eq(carts.id, cartId))
      .returning();
    return updated || null;
  }

  protected async beforeCreate(data: Record<string, unknown>): Promise<Record<string, unknown>> {
    // Set default status
    if (!data.status) {
      data.status = "active";
    }

    // Set default amounts
    if (!data.baseAmount) {
      data.baseAmount = "0";
    }
    if (!data.discountAmount) {
      data.discountAmount = "0";
    }
    if (!data.taxAmount) {
      data.taxAmount = "0";
    }
    if (!data.cartAmount) {
      data.cartAmount = "0";
    }

    // Set default arrays
    if (!data.couponCodes) {
      data.couponCodes = [];
    }
    if (!data.giftCertificateCodes) {
      data.giftCertificateCodes = [];
    }

    // Set expiry date (30 days from now)
    if (!data.expiresAt) {
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 30);
      data.expiresAt = expiresAt;
    }

    // Get channel's default currency if not specified
    if (!data.currencyCode && data.channelId) {
      const [channel] = await this.db
        .select({ defaultCurrencyCode: channels.defaultCurrencyCode })
        .from(channels)
        .where(eq(channels.id, data.channelId as number))
        .limit(1);

      if (channel?.defaultCurrencyCode) {
        data.currencyCode = channel.defaultCurrencyCode;
      } else {
        data.currencyCode = "USD";
      }
    }

    return data;
  }
}

export const cartService = new CartServiceClass();
