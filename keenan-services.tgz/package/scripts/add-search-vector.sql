-- Generated tsvector column with weighted fields (auto-updates on row changes)
ALTER TABLE products ADD COLUMN IF NOT EXISTS search_vector tsvector
  GENERATED ALWAYS AS (
    setweight(to_tsvector('english', coalesce(name, '')), 'A') ||
    setweight(to_tsvector('english', coalesce(sku, '')), 'B') ||
    setweight(to_tsvector('english', coalesce(search_keywords, '')), 'B') ||
    setweight(to_tsvector('english', coalesce(description_short, '')), 'C') ||
    setweight(to_tsvector('english', coalesce(description, '')), 'C') ||
    setweight(to_tsvector('english', coalesce(meta_keywords, '')), 'D')
  ) STORED;

-- GIN index on tsvector for full-text search
CREATE INDEX IF NOT EXISTS idx_products_search_vector
  ON products USING gin(search_vector);

-- GIN trigram index on name for fuzzy matching
CREATE INDEX IF NOT EXISTS idx_products_name_trgm
  ON products USING gin(name gin_trgm_ops);

-- GIN trigram index on SKU for fuzzy SKU lookups
CREATE INDEX IF NOT EXISTS idx_products_sku_trgm
  ON products USING gin(sku gin_trgm_ops);
