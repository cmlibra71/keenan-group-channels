import { sql } from "drizzle-orm";
import { getCommerceDb } from "../../db";

const EXCLUDED_STATUSES = ["canceled", "cancelled", "declined", "refunded", "closed"];

export interface DashboardStats {
  channelCount: number;
  totalProducts: number;
  activeProducts: number;
  thisYearRevenue: string;
  lastYearRevenueToDate: string;
  thisMonthRevenue: string;
  sameMonthLastYearRevenue: string;
  thisMonthOrders: number;
  sameMonthLastYearOrders: number;
  thisYearAccounts: number;
  lastYearAccountsToDate: number;
}

/**
 * Get all dashboard stats in a single call.
 * Uses efficient aggregate queries — no raw drizzle-orm needed by consumers.
 */
export async function getDashboardStats(): Promise<DashboardStats> {
  const db = getCommerceDb();
  const now = new Date();
  const thisYearStart = new Date(now.getFullYear(), 0, 1);
  const lastYearStart = new Date(now.getFullYear() - 1, 0, 1);
  const lastYearSamePoint = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate(), now.getHours());
  const currentMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const sameMonthLastYearStart = new Date(now.getFullYear() - 1, now.getMonth(), 1);
  const sameMonthLastYearSameDay = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate(), now.getHours());

  const statusExclusion = sql`status NOT IN (${sql.join(
    EXCLUDED_STATUSES.map((s) => sql`${s}`),
    sql`, `
  )})`;

  const [result] = await db.execute(sql`
    SELECT
      (SELECT COUNT(*)::int FROM channels) AS channel_count,
      (SELECT COUNT(*)::int FROM products) AS total_products,
      (SELECT COUNT(*)::int FROM products WHERE is_visible = true) AS active_products,

      COALESCE((SELECT SUM(total_inc_tax::numeric) FROM orders
        WHERE created_at >= ${thisYearStart.toISOString()} AND ${statusExclusion}), 0)::text AS this_year_revenue,

      COALESCE((SELECT SUM(total_inc_tax::numeric) FROM orders
        WHERE created_at >= ${lastYearStart.toISOString()} AND created_at < ${lastYearSamePoint.toISOString()} AND ${statusExclusion}), 0)::text AS last_year_revenue_to_date,

      COALESCE((SELECT SUM(total_inc_tax::numeric) FROM orders
        WHERE created_at >= ${currentMonthStart.toISOString()} AND ${statusExclusion}), 0)::text AS this_month_revenue,

      COALESCE((SELECT SUM(total_inc_tax::numeric) FROM orders
        WHERE created_at >= ${sameMonthLastYearStart.toISOString()} AND created_at < ${sameMonthLastYearSameDay.toISOString()} AND ${statusExclusion}), 0)::text AS same_month_last_year_revenue,

      (SELECT COUNT(*)::int FROM orders
        WHERE created_at >= ${currentMonthStart.toISOString()} AND ${statusExclusion}) AS this_month_orders,

      (SELECT COUNT(*)::int FROM orders
        WHERE created_at >= ${sameMonthLastYearStart.toISOString()} AND created_at < ${sameMonthLastYearSameDay.toISOString()} AND ${statusExclusion}) AS same_month_last_year_orders,

      (SELECT COUNT(*)::int FROM accounts
        WHERE created_at >= ${thisYearStart.toISOString()}) AS this_year_accounts,

      (SELECT COUNT(*)::int FROM accounts
        WHERE created_at >= ${lastYearStart.toISOString()} AND created_at < ${lastYearSamePoint.toISOString()}) AS last_year_accounts_to_date
  `);

  const row = result as unknown as Record<string, unknown>;
  return {
    channelCount: Number(row.channel_count),
    totalProducts: Number(row.total_products),
    activeProducts: Number(row.active_products),
    thisYearRevenue: String(row.this_year_revenue),
    lastYearRevenueToDate: String(row.last_year_revenue_to_date),
    thisMonthRevenue: String(row.this_month_revenue),
    sameMonthLastYearRevenue: String(row.same_month_last_year_revenue),
    thisMonthOrders: Number(row.this_month_orders),
    sameMonthLastYearOrders: Number(row.same_month_last_year_orders),
    thisYearAccounts: Number(row.this_year_accounts),
    lastYearAccountsToDate: Number(row.last_year_accounts_to_date),
  };
}
