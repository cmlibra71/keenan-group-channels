import { PgColumn } from "drizzle-orm/pg-core";
import { orders, orderShippingAddresses, shipments } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { DependencyCheck, IncludeConfig } from "../../base/types";

/**
 * Service for managing order shipping addresses.
 */
class OrderShippingAddressServiceClass extends NestedService<typeof orders, typeof orderShippingAddresses> {
  constructor() {
    super(orders, orderShippingAddresses, {
      resourceName: "Shipping Address",
      parentResourceName: "Order",
      defaultSort: "id",
      sortColumns: {
        id: orderShippingAddresses.id,
        city: orderShippingAddresses.city,
        country: orderShippingAddresses.country,
        created_at: orderShippingAddresses.createdAt,
      },
      filterColumns: {
        country: orderShippingAddresses.country,
        city: orderShippingAddresses.city,
        shipping_method: orderShippingAddresses.shippingMethod,
        shipping_zone_id: orderShippingAddresses.shippingZoneId,
      },
      allowedFilters: ["country", "city", "shipping_method", "shipping_zone_id"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return orders.id;
  }

  protected getParentForeignKey(): PgColumn {
    return orderShippingAddresses.orderId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "orderId";
  }

  protected getDependencyChecks(): DependencyCheck[] {
    return [
      {
        table: shipments,
        foreignKeyColumn: shipments.orderShippingAddressId,
        resourceName: "shipment",
        message: "Cannot delete Shipping Address because it has {count} shipment(s) associated with it.",
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "shipments",
        table: shipments,
        foreignKey: shipments.orderShippingAddressId,
      },
    ];
  }
}

export const orderShippingAddressService = new OrderShippingAddressServiceClass();
