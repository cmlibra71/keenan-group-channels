import { eq, and, sql, asc, desc } from "drizzle-orm";
import { channels, channelSettings } from "../../schema";
import { getCommerceDb } from "../../db";
import { NotFoundError, BadRequestError } from "../../errors";
import { transformRow, transformRows } from "../../transforms";
import { ListOptions, PaginatedResult } from "../../base/types";

/**
 * Service for managing channel settings (key-value store per channel).
 *
 * This is a specialized service that doesn't extend BaseService because
 * settings use a key-based lookup instead of numeric ID.
 */
class ChannelSettingsServiceClass {
  protected get db() {
    return getCommerceDb();
  }

  /**
   * List all settings for a channel
   */
  async listForChannel(
    channelId: number,
    options: ListOptions
  ): Promise<PaginatedResult<Record<string, unknown>>> {
    const { page, limit, direction } = options;

    // Validate channel exists
    await this.validateChannel(channelId);

    // Get total count
    const [countResult] = await this.db
      .select({ count: sql<number>`count(*)::int` })
      .from(channelSettings)
      .where(eq(channelSettings.channelId, channelId));

    const total = countResult?.count ?? 0;

    // Get paginated results (sorted by key)
    const results = await this.db
      .select()
      .from(channelSettings)
      .where(eq(channelSettings.channelId, channelId))
      .orderBy(direction === "desc" ? desc(channelSettings.settingKey) : asc(channelSettings.settingKey))
      .limit(limit)
      .offset((page - 1) * limit);

    const data = transformRows(results as Record<string, unknown>[]);

    return {
      data,
      pagination: { page, limit, total },
    };
  }

  /**
   * Get a single setting by key
   */
  async getByKey(channelId: number, key: string): Promise<Record<string, unknown>> {
    if (!key) {
      throw new BadRequestError("Setting key is required.");
    }

    // Validate channel exists
    await this.validateChannel(channelId);

    const [result] = await this.db
      .select()
      .from(channelSettings)
      .where(
        and(eq(channelSettings.channelId, channelId), eq(channelSettings.settingKey, key))
      )
      .limit(1);

    if (!result) {
      throw new NotFoundError("Channel Setting", key);
    }

    return transformRow(result as Record<string, unknown>);
  }

  /**
   * Create or update a setting (upsert)
   */
  async upsert(
    channelId: number,
    key: string,
    value: unknown
  ): Promise<Record<string, unknown>> {
    if (!key) {
      throw new BadRequestError("Setting key is required.");
    }

    // Validate channel exists
    await this.validateChannel(channelId);

    // Check if setting exists
    const [existing] = await this.db
      .select({ id: channelSettings.id })
      .from(channelSettings)
      .where(
        and(eq(channelSettings.channelId, channelId), eq(channelSettings.settingKey, key))
      )
      .limit(1);

    let result;

    if (existing) {
      // Update existing setting
      [result] = await this.db
        .update(channelSettings)
        .set({
          settingValue: value,
          updatedAt: new Date(),
        })
        .where(eq(channelSettings.id, existing.id))
        .returning();
    } else {
      // Insert new setting
      [result] = await this.db
        .insert(channelSettings)
        .values({
          channelId,
          settingKey: key,
          settingValue: value,
        })
        .returning();
    }

    return transformRow(result as Record<string, unknown>);
  }

  /**
   * Delete a setting by key
   */
  async deleteByKey(channelId: number, key: string): Promise<void> {
    if (!key) {
      throw new BadRequestError("Setting key is required.");
    }

    // Check setting exists
    const [setting] = await this.db
      .select({ id: channelSettings.id })
      .from(channelSettings)
      .where(
        and(eq(channelSettings.channelId, channelId), eq(channelSettings.settingKey, key))
      )
      .limit(1);

    if (!setting) {
      throw new NotFoundError("Channel Setting", key);
    }

    await this.db.delete(channelSettings).where(eq(channelSettings.id, setting.id));
  }

  /**
   * Get a specific setting across all channels.
   * Returns a map of channelId → settingValue.
   */
  async getSettingAcrossChannels(key: string): Promise<Record<number, unknown>> {
    if (!key) {
      throw new BadRequestError("Setting key is required.");
    }

    const rows = await this.db
      .select({
        channelId: channelSettings.channelId,
        settingValue: channelSettings.settingValue,
      })
      .from(channelSettings)
      .where(eq(channelSettings.settingKey, key));

    const result: Record<number, unknown> = {};
    for (const row of rows) {
      result[row.channelId] = row.settingValue;
    }
    return result;
  }

  /**
   * Get active channels with their settings and sites for infrastructure use (e.g., Caddy config).
   */
  async getActiveChannelsWithSitesAndSettings(): Promise<{
    channels: Record<string, unknown>[];
    settings: { channelId: number; settingKey: string; settingValue: unknown }[];
    sites: Record<string, unknown>[];
  }> {
    const { sites } = await import("../../schema");

    const [allChannels, allSettings, allSites] = await Promise.all([
      this.db.select().from(channels).where(eq(channels.status, "active")),
      this.db.select().from(channelSettings),
      this.db.select().from(sites),
    ]);

    return {
      channels: allChannels as unknown as Record<string, unknown>[],
      settings: allSettings.map((s) => ({
        channelId: s.channelId,
        settingKey: s.settingKey,
        settingValue: s.settingValue,
      })),
      sites: allSites as unknown as Record<string, unknown>[],
    };
  }

  /**
   * Validate that the channel exists
   */
  private async validateChannel(channelId: number): Promise<void> {
    const [channel] = await this.db
      .select({ id: channels.id })
      .from(channels)
      .where(eq(channels.id, channelId))
      .limit(1);

    if (!channel) {
      throw new NotFoundError("Channel", channelId);
    }
  }
}

export const channelSettingsService = new ChannelSettingsServiceClass();
