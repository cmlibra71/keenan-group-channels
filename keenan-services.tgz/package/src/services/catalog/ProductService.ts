import { and, eq, inArray, ilike, or, isNotNull, gt, sql, getTableColumns } from "drizzle-orm";
import {
  products,
  brands,
  productVariants,
  productImages,
  productChannelAssignments,
  productCategories,
  categories,
  orderItems,
  cartItems,
  wishlistItems,
  productOptions,
  productOptionValues,
  productVariantOptions,
  bulkPricingRules,
} from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation, UniqueConstraint, IncludeConfig } from "../../base/types";
import { generateEmbedding, composeProductEmbeddingText } from "../../utils/embeddings";
import { syncProductToMeilisearch, removeProductFromAllChannels } from "../../search";

/**
 * Service for managing products.
 */
class ProductServiceClass extends BaseService<typeof products> {
  constructor() {
    super(products, {
      resourceName: "Product",
      defaultSort: "id",
      sortColumns: {
        id: products.id,
        name: products.name,
        price: products.price,
        sku: products.sku,
        created_at: products.createdAt,
        updated_at: products.updatedAt,
      },
      filterColumns: {
        sku: products.sku,
        brand_id: products.brandId,
        type: products.type,
        is_visible: products.isVisible,
        is_featured: products.isFeatured,
        name: products.name,
        price: products.price,
        inventory_level: products.inventoryLevel,
      },
      allowedFilters: [
        "sku",
        "brand_id",
        "type",
        "is_visible",
        "is_featured",
        "name",
        "price",
        "inventory_level",
      ],
      softDelete: {
        column: products.isDeleted,
        fieldName: "isDeleted",
        deletedValue: true,
        deletedAtColumn: products.deletedAt,
        deletedAtFieldName: "deletedAt",
      },
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: brands,
        column: brands.id,
        resourceName: "Brand",
        fieldName: "brandId",
        optional: true,
      },
    ];
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [{ column: products.sku, fieldName: "sku" }],
        message: "SKU is already in use.",
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "variants",
        table: productVariants,
        foreignKey: productVariants.productId,
      },
      {
        name: "images",
        table: productImages,
        foreignKey: productImages.productId,
      },
    ];
  }

  // ── Embedding hooks ─────────────────────────────────────────────

  /**
   * Fire-and-forget: generate and store embedding for a product.
   * Fetches brand name + category names for richer context.
   */
  private async embedProduct(productId: number, product: Record<string, unknown>): Promise<void> {
    try {
      // Fetch brand name
      let brandName: string | null = null;
      const brandId = product.brandId ?? product.brand_id;
      if (brandId) {
        const [brand] = await this.db
          .select({ name: brands.name })
          .from(brands)
          .where(eq(brands.id, brandId as number))
          .limit(1);
        if (brand) brandName = brand.name;
      }

      // Fetch category names
      const catRows = await this.db
        .selectDistinct({ name: categories.name })
        .from(productCategories)
        .innerJoin(categories, eq(categories.id, productCategories.categoryId))
        .where(eq(productCategories.productId, productId));
      const categoryNames = catRows.map((r) => r.name);

      const text = composeProductEmbeddingText({
        name: product.name as string,
        sku: product.sku as string | null,
        brandName,
        categoryNames,
      });
      const embedding = await generateEmbedding(text);
      if (embedding) {
        await this.db
          .update(products)
          .set({ embedding })
          .where(eq(products.id, productId));
      }
    } catch (err) {
      console.error(`[ProductService] Failed to embed product ${productId}:`, (err as Error).message);
    }
  }

  protected async afterCreate(result: Record<string, unknown>): Promise<void> {
    // Fire-and-forget — don't block the create response
    this.embedProduct(result.id as number, result).catch(() => {});
    syncProductToMeilisearch(result.id as number).catch(() => {});
  }

  protected async afterUpdate(result: Record<string, unknown>, previous: Record<string, unknown>): Promise<void> {
    // Re-embed if text fields that affect the embedding changed
    const textFields = ["name", "sku", "brandId", "brand_id"];
    const changed = textFields.some((f) => result[f] !== previous[f]);
    if (changed) {
      this.embedProduct(result.id as number, result).catch(() => {});
    }
    // Always re-sync to Meilisearch (price, description, etc. may have changed)
    syncProductToMeilisearch(result.id as number).catch(() => {});
  }

  protected async afterDelete(id: number, _deleted: Record<string, unknown>): Promise<void> {
    removeProductFromAllChannels(id).catch(() => {});
  }

  // ── Storefront methods ────────────────────────────────────────────

  /**
   * Channel-scoped paginated product list with filtering + thumbnails.
   */
  async listForChannel(
    channelId: number,
    opts?: {
      page?: number;
      limit?: number;
      categoryId?: number;
      featured?: boolean;
      onSale?: boolean;
      search?: string;
    }
  ) {
    const { page = 1, limit = 20, categoryId, featured, onSale, search } = opts || {};

    // Get product IDs visible on this channel (with channel-level featured override)
    const assignments = await this.db
      .select({
        productId: productChannelAssignments.productId,
        isFeatured: productChannelAssignments.isFeatured,
      })
      .from(productChannelAssignments)
      .where(
        and(
          eq(productChannelAssignments.channelId, channelId),
          eq(productChannelAssignments.isVisible, true)
        )
      );

    const visibleIds = assignments.map((a) => a.productId);
    if (visibleIds.length === 0) return { products: [], total: 0 };

    // Generate query embedding for semantic search (3+ char queries only)
    let queryEmbedding: number[] | null = null;
    if (search && search.trim().length > 2) {
      queryEmbedding = await generateEmbedding(search.trim());
    }

    // Build conditions
    let conditions = and(
      inArray(products.id, visibleIds),
      eq(products.isVisible, true),
      eq(products.isDeleted, false)
    );

    if (featured) {
      // Channel-level is_featured overrides global; null falls back to products.is_featured
      const channelFeaturedIds = assignments
        .filter((a) => a.isFeatured === true)
        .map((a) => a.productId);
      const channelUnsetIds = assignments
        .filter((a) => a.isFeatured === null)
        .map((a) => a.productId);

      const featuredConditions = [];
      if (channelFeaturedIds.length > 0) {
        featuredConditions.push(inArray(products.id, channelFeaturedIds));
      }
      if (channelUnsetIds.length > 0) {
        featuredConditions.push(
          and(inArray(products.id, channelUnsetIds), eq(products.isFeatured, true))
        );
      }

      if (featuredConditions.length === 0) {
        return { products: [], total: 0 };
      }

      conditions = and(
        conditions,
        featuredConditions.length === 1
          ? featuredConditions[0]
          : or(...featuredConditions)
      );
    }

    if (onSale) {
      conditions = and(
        conditions,
        isNotNull(products.salePrice),
        gt(products.salePrice, "0")
      );
    }

    if (search) {
      const trimmed = search.trim();

      if (trimmed.length <= 2) {
        // Short queries: prefix ILIKE
        const pattern = `%${trimmed}%`;
        conditions = and(
          conditions,
          or(ilike(products.name, pattern), ilike(products.sku, pattern))
        );
      } else if (queryEmbedding) {
        // Pure semantic: cosine distance < 0.65
        conditions = and(
          conditions,
          sql`${products.embedding} IS NOT NULL AND (${products.embedding} <=> ${JSON.stringify(queryEmbedding)}::vector) < 0.65`
        );
      } else {
        // Fallback (no API key): ILIKE — all words must match in name or SKU
        const words = trimmed.split(/\s+/).filter((w) => w.length > 0);
        conditions = and(
          conditions,
          ...words.map((w) =>
            or(ilike(products.name, `%${w}%`), ilike(products.sku, `%${w}%`))
          )
        );
      }
    }

    // Category filter
    if (categoryId) {
      const catAssignments = await this.db
        .select({ productId: productCategories.productId })
        .from(productCategories)
        .where(eq(productCategories.categoryId, categoryId));

      const catProductIds = catAssignments.map((p) => p.productId);
      if (catProductIds.length === 0) return { products: [], total: 0 };
      conditions = and(conditions, inArray(products.id, catProductIds));
    }

    // Get filtered total count
    const [countResult] = await this.db
      .select({ count: sql<number>`count(*)::int` })
      .from(products)
      .where(conditions);
    const total = countResult?.count ?? 0;

    let results;
    if (search && search.trim().length > 2 && queryEmbedding) {
      // Pure semantic ranking: order by cosine distance ascending (closest first)
      results = await this.db
        .select({
          ...getTableColumns(products),
        })
        .from(products)
        .where(conditions)
        .orderBy(sql`${products.embedding} <=> ${JSON.stringify(queryEmbedding)}::vector ASC`)
        .limit(limit)
        .offset((page - 1) * limit);
    } else {
      results = await this.db
        .select()
        .from(products)
        .where(conditions)
        .limit(limit)
        .offset((page - 1) * limit)
        .orderBy(products.name);
    }

    // Get thumbnails for results
    const productIds = results.map((p) => p.id);
    const images = productIds.length > 0
      ? await this.db
          .select()
          .from(productImages)
          .where(
            and(
              inArray(productImages.productId, productIds),
              eq(productImages.isThumbnail, true)
            )
          )
      : [];

    const imageMap = new Map(images.map((img) => [img.productId, img]));

    const productsWithImages = results.map((product) => ({
      ...product,
      thumbnailImage: imageMap.get(product.id) || null,
    }));

    return { products: productsWithImages, total };
  }

  /**
   * Product detail by slug with channel assignment check, ordered images and variants.
   */
  async getBySlug(slug: string, channelId: number) {
    const [product] = await this.db
      .select()
      .from(products)
      .where(
        and(
          eq(products.urlPath, slug),
          eq(products.isVisible, true),
          eq(products.isDeleted, false)
        )
      )
      .limit(1);

    if (!product) return null;

    // Verify channel assignment
    const [assignment] = await this.db
      .select()
      .from(productChannelAssignments)
      .where(
        and(
          eq(productChannelAssignments.productId, product.id),
          eq(productChannelAssignments.channelId, channelId),
          eq(productChannelAssignments.isVisible, true)
        )
      )
      .limit(1);

    if (!assignment) return null;

    // Get images, variants, options, bulk pricing, and category assignments
    const [images, variants, options, bulkPricing, categoryAssignments] = await Promise.all([
      this.db.select().from(productImages).where(eq(productImages.productId, product.id)).orderBy(productImages.sortOrder),
      this.db.select().from(productVariants).where(eq(productVariants.productId, product.id)).orderBy(productVariants.sortOrder),
      this.db.select().from(productOptions).where(eq(productOptions.productId, product.id)).orderBy(productOptions.sortOrder),
      this.db.select().from(bulkPricingRules).where(eq(bulkPricingRules.productId, product.id)).orderBy(bulkPricingRules.quantityMin),
      this.db.select({ categoryId: productCategories.categoryId, depth: categories.depth }).from(productCategories).innerJoin(categories, eq(categories.id, productCategories.categoryId)).where(eq(productCategories.productId, product.id)),
    ]);

    // If options exist, fetch option values and variant-option mappings
    let optionValues: (typeof productOptionValues.$inferSelect)[] = [];
    let variantOptionMappings: (typeof productVariantOptions.$inferSelect)[] = [];

    if (options.length > 0 && variants.length > 0) {
      const optionIds = options.map((o) => o.id);
      const variantIds = variants.map((v) => v.id);

      [optionValues, variantOptionMappings] = await Promise.all([
        this.db.select().from(productOptionValues).where(inArray(productOptionValues.optionId, optionIds)).orderBy(productOptionValues.sortOrder),
        this.db.select().from(productVariantOptions).where(inArray(productVariantOptions.variantId, variantIds)),
      ]);
    }

    // Sort categories: deepest first (highest depth number = most specific)
    const categoryIds = categoryAssignments
      .sort((a, b) => (b.depth ?? 0) - (a.depth ?? 0))
      .map((c) => c.categoryId);

    return { ...product, images, variants, options, optionValues, variantOptionMappings, bulkPricing, categoryIds };
  }
}

export const productService = new ProductServiceClass();
