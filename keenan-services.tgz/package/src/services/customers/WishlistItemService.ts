import { PgColumn } from "drizzle-orm/pg-core";
import { wishlists, wishlistItems, products, productVariants } from "../../schema";
import { NestedService } from "../../base/NestedService";
import { ForeignKeyValidation, UniqueConstraint } from "../../base/types";

/**
 * Service for managing wishlist items.
 */
class WishlistItemServiceClass extends NestedService<typeof wishlists, typeof wishlistItems> {
  constructor() {
    super(wishlists, wishlistItems, {
      resourceName: "Wishlist Item",
      parentResourceName: "Wishlist",
      defaultSort: "id",
      sortColumns: {
        id: wishlistItems.id,
        created_at: wishlistItems.createdAt,
      },
      filterColumns: {
        product_id: wishlistItems.productId,
        variant_id: wishlistItems.variantId,
      },
      allowedFilters: ["product_id", "variant_id"],
      timestamps: {
        created: "createdAt",
      },
    });
  }

  protected getParentIdColumn(): PgColumn {
    return wishlists.id;
  }

  protected getParentForeignKey(): PgColumn {
    return wishlistItems.wishlistId;
  }

  protected getParentForeignKeyFieldName(): string {
    return "wishlistId";
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: products,
        column: products.id,
        resourceName: "Product",
        fieldName: "productId",
      },
      {
        table: productVariants,
        column: productVariants.id,
        resourceName: "Variant",
        fieldName: "variantId",
        optional: true,
      },
    ];
  }

  protected getUniqueConstraints(): UniqueConstraint[] {
    return [
      {
        columns: [
          { column: wishlistItems.wishlistId, fieldName: "wishlistId" },
          { column: wishlistItems.productId, fieldName: "productId" },
          { column: wishlistItems.variantId, fieldName: "variantId" },
        ],
        message: "This product/variant is already in the wishlist.",
        composite: true,
      },
    ];
  }
}

export const wishlistItemService = new WishlistItemServiceClass();
