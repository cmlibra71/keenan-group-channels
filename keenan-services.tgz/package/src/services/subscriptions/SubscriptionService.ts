import { eq, and, desc } from "drizzle-orm";
import {
  subscriptions,
  subscriptionPlans,
  subscriptionEvents,
  drawEntries,
  channels,
  customers,
} from "../../schema";
import { BaseService } from "../../base/BaseService";
import { ForeignKeyValidation, IncludeConfig } from "../../base/types";

/**
 * Service for managing customer subscription instances.
 */
class SubscriptionServiceClass extends BaseService<typeof subscriptions> {
  constructor() {
    super(subscriptions, {
      resourceName: "Subscription",
      defaultSort: "id",
      sortColumns: {
        id: subscriptions.id,
        status: subscriptions.status,
        created_at: subscriptions.createdAt,
        updated_at: subscriptions.updatedAt,
      },
      filterColumns: {
        channel_id: subscriptions.channelId,
        customer_id: subscriptions.customerId,
        plan_id: subscriptions.planId,
        status: subscriptions.status,
        stripe_subscription_id: subscriptions.stripeSubscriptionId,
      },
      allowedFilters: ["channel_id", "customer_id", "plan_id", "status", "stripe_subscription_id"],
      timestamps: {
        created: "createdAt",
        updated: "updatedAt",
      },
    });
  }

  protected getForeignKeyValidations(): ForeignKeyValidation[] {
    return [
      {
        table: channels,
        column: channels.id,
        resourceName: "Channel",
        fieldName: "channelId",
      },
      {
        table: customers,
        column: customers.id,
        resourceName: "Customer",
        fieldName: "customerId",
      },
      {
        table: subscriptionPlans,
        column: subscriptionPlans.id,
        resourceName: "Subscription Plan",
        fieldName: "planId",
      },
    ];
  }

  protected getIncludeConfigs(): IncludeConfig[] {
    return [
      {
        name: "events",
        table: subscriptionEvents,
        foreignKey: subscriptionEvents.subscriptionId,
      },
    ];
  }

  /**
   * Get active subscription for a customer within a channel.
   */
  async getActiveForCustomer(customerId: number, channelId: number) {
    const [sub] = await this.db
      .select()
      .from(subscriptions)
      .where(
        and(
          eq(subscriptions.customerId, customerId),
          eq(subscriptions.channelId, channelId),
          eq(subscriptions.status, "active")
        )
      )
      .limit(1);
    return sub || null;
  }

  /**
   * Get subscription by Stripe subscription ID.
   */
  async getByStripeId(stripeSubId: string) {
    const [sub] = await this.db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.stripeSubscriptionId, stripeSubId))
      .limit(1);
    return sub || null;
  }

  /**
   * Activate a subscription and assign customer to the member group.
   */
  async activate(id: number) {
    const [sub] = await this.db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.id, id))
      .limit(1);
    if (!sub) return null;

    // Get the plan to find the member customer group
    const [plan] = await this.db
      .select()
      .from(subscriptionPlans)
      .where(eq(subscriptionPlans.id, sub.planId))
      .limit(1);

    // Update subscription status
    const [updated] = await this.db
      .update(subscriptions)
      .set({
        status: "active",
        updatedAt: new Date(),
      })
      .where(eq(subscriptions.id, id))
      .returning();

    // Assign customer to member group if plan has one
    if (plan?.memberCustomerGroupId) {
      await this.db
        .update(customers)
        .set({
          customerGroupId: plan.memberCustomerGroupId,
          updatedAt: new Date(),
        })
        .where(eq(customers.id, sub.customerId));
    }

    return updated || null;
  }

  /**
   * Cancel a subscription (optionally at period end).
   */
  async cancel(id: number, atPeriodEnd: boolean = true) {
    const [updated] = await this.db
      .update(subscriptions)
      .set({
        status: atPeriodEnd ? "active" : "cancelled",
        cancelAtPeriodEnd: atPeriodEnd,
        cancelledAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(subscriptions.id, id))
      .returning();
    return updated || null;
  }

  /**
   * Handle subscription ended — remove from member group, forfeit draw entries.
   */
  async handleEnded(id: number) {
    const [sub] = await this.db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.id, id))
      .limit(1);
    if (!sub) return null;

    // Get the plan for the member group
    const [plan] = await this.db
      .select()
      .from(subscriptionPlans)
      .where(eq(subscriptionPlans.id, sub.planId))
      .limit(1);

    // Update subscription status
    const [updated] = await this.db
      .update(subscriptions)
      .set({
        status: "ended",
        updatedAt: new Date(),
      })
      .where(eq(subscriptions.id, id))
      .returning();

    // Remove customer from member group
    if (plan?.memberCustomerGroupId) {
      // Only reset if customer is still in this group
      const [customer] = await this.db
        .select({ customerGroupId: customers.customerGroupId })
        .from(customers)
        .where(eq(customers.id, sub.customerId))
        .limit(1);

      if (customer?.customerGroupId === plan.memberCustomerGroupId) {
        await this.db
          .update(customers)
          .set({
            customerGroupId: null,
            updatedAt: new Date(),
          })
          .where(eq(customers.id, sub.customerId));
      }
    }

    // Forfeit active draw entries for this subscription
    await this.db
      .update(drawEntries)
      .set({
        status: "forfeited",
        forfeitedAt: new Date(),
      })
      .where(
        and(
          eq(drawEntries.subscriptionId, sub.id),
          eq(drawEntries.status, "active")
        )
      );

    return updated || null;
  }

  /**
   * List subscriptions for a customer within a channel.
   */
  async listForCustomer(customerId: number, channelId: number) {
    return this.db
      .select()
      .from(subscriptions)
      .where(
        and(
          eq(subscriptions.customerId, customerId),
          eq(subscriptions.channelId, channelId)
        )
      )
      .orderBy(desc(subscriptions.createdAt));
  }
}

export const subscriptionService = new SubscriptionServiceClass();
