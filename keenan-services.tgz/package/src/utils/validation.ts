import { z, ZodSchema, ZodError } from "zod";
import { ValidationError, BadRequestError } from "../errors";

/**
 * Validate request body against a Zod schema
 * Returns the parsed data or throws a ValidationError
 */
export function validateBody<T>(body: unknown, schema: ZodSchema<T>): T {
  try {
    return schema.parse(body);
  } catch (error) {
    if (error instanceof ZodError) {
      const errors: Record<string, string> = {};

      for (const issue of error.issues) {
        const path = issue.path.join(".");
        errors[path] = issue.message;
      }

      throw new ValidationError(
        "Request validation failed. See errors for details.",
        errors
      );
    }
    throw error;
  }
}

// ============================================================================
// Common Validation Schemas
// ============================================================================

/**
 * Positive integer (for IDs)
 */
export const positiveInt = z.number().int().positive();

/**
 * Non-empty string
 */
export const nonEmptyString = z.string().min(1, "Cannot be empty");

/**
 * Optional non-empty string (empty string becomes undefined)
 */
export const optionalString = z
  .string()
  .optional()
  .transform((val) => (val === "" ? undefined : val));

/**
 * Email address
 */
export const email = z.string().email("Invalid email address");

/**
 * Optional email
 */
export const optionalEmail = z
  .string()
  .email("Invalid email address")
  .optional()
  .or(z.literal(""));

/**
 * URL
 */
export const url = z.string().url("Invalid URL");

/**
 * Optional URL
 */
export const optionalUrl = z.string().url("Invalid URL").optional().or(z.literal(""));

/**
 * UUID
 */
export const uuid = z.string().uuid("Invalid UUID");

/**
 * Slug (URL-friendly string)
 */
export const slug = z
  .string()
  .min(1, "Slug cannot be empty")
  .max(255, "Slug too long")
  .regex(
    /^[a-z0-9]+(?:-[a-z0-9]+)*$/,
    "Slug must be lowercase, contain only letters, numbers, and hyphens, and not start or end with a hyphen"
  );

/**
 * Currency code (3 letters)
 */
export const currencyCode = z
  .string()
  .length(3, "Currency code must be exactly 3 characters")
  .toUpperCase();

/**
 * Country code (2 letters)
 */
export const countryCode = z
  .string()
  .length(2, "Country code must be exactly 2 characters")
  .toUpperCase();

/**
 * Locale (e.g., en-US)
 */
export const locale = z
  .string()
  .regex(/^[a-z]{2}(-[A-Z]{2})?$/, "Invalid locale format (e.g., en-US)");

/**
 * Decimal price (string or number, converted to string)
 */
export const price = z
  .union([z.string(), z.number()])
  .transform((val) => String(val))
  .refine(
    (val) => !isNaN(parseFloat(val)) && parseFloat(val) >= 0,
    "Price must be a non-negative number"
  );

/**
 * Optional decimal price
 */
export const optionalPrice = z
  .union([z.string(), z.number(), z.null()])
  .optional()
  .transform((val) => (val === null || val === undefined ? undefined : String(val)));

/**
 * Integer quantity (non-negative)
 */
export const quantity = z.number().int().nonnegative("Quantity must be non-negative");

/**
 * Optional integer
 */
export const optionalInt = z.number().int().optional();

/**
 * Boolean (also accepts string "true"/"false")
 */
export const boolean = z.union([
  z.boolean(),
  z.string().transform((val) => val.toLowerCase() === "true"),
]);

/**
 * Optional boolean
 */
export const optionalBoolean = z
  .union([
    z.boolean(),
    z.string().transform((val) => val.toLowerCase() === "true"),
  ])
  .optional();

/**
 * Date string (ISO 8601)
 */
export const dateString = z.string().datetime({ message: "Invalid date format. Use ISO 8601." });

/**
 * Optional date string
 */
export const optionalDateString = z
  .string()
  .datetime({ message: "Invalid date format. Use ISO 8601." })
  .optional()
  .or(z.literal(""));

/**
 * JSON object
 */
export const jsonObject = z.record(z.string(), z.unknown()).default({});

/**
 * Array of integers
 */
export const intArray = z.array(z.number().int()).default([]);

/**
 * Array of strings
 */
export const stringArray = z.array(z.string()).default([]);

// ============================================================================
// Entity-Specific Validators
// ============================================================================

/**
 * Validate ID from route params
 */
export function validateId(id: string | undefined, resourceType: string): number {
  if (!id) {
    throw new BadRequestError(`${resourceType} ID is required.`);
  }

  const parsed = parseInt(id, 10);
  if (isNaN(parsed) || parsed < 1) {
    throw new BadRequestError(
      `Invalid ${resourceType} ID: "${id}". ID must be a positive integer.`
    );
  }

  return parsed;
}

/**
 * Validate optional ID from route params
 */
export function validateOptionalId(id: string | undefined): number | undefined {
  if (!id) return undefined;

  const parsed = parseInt(id, 10);
  if (isNaN(parsed) || parsed < 1) return undefined;

  return parsed;
}
